import { useEffect, useRef, useState, useCallback } from 'react';
import { Engine } from '@/game/Engine';
import { W as GAME_W, H as GAME_H, PHASES, CLASSES, MONSTER_SPRITES } from '@/game/config';
import { audio } from '@/game/AudioManager';
import { loadSave, clearAllSave } from '@/game/Save';
import { loadSettings, saveSettings } from '@/game/Settings';
import { loadMemory, addFragment, unlockSkill, resetMemory } from '@/game/MemorySave';
import AltarScreen from '@/components/memory/AltarScreen';
import ConstellationScreen from '@/components/memory/ConstellationScreen';

const ATTRS = [
  { key: 'damage',      ico: '⚔', name: 'FÚRIA',      val: '+15%', desc: 'Dano' },
  { key: 'attackSpeed', ico: '⚡', name: 'FRENESI',    val: '+20%', desc: 'Velocidade de ataque' },
  { key: 'lifesteal',   ico: '✚', name: 'VAMPIRISMO', val: '+10%', desc: 'Roubo de vida' },
  { key: 'defense',     ico: '⛨', name: 'CARNE DURA', val: '+25%', desc: 'Defesa' },
  { key: 'hp',          ico: '♥', name: 'VITALIDADE', val: '+100%', desc: 'Vida máxima' },
];

// ---------------------------------------------------------------------------
// DIÁLOGOS — NENHUMA MECÂNICA FOI ALTERADA AQUI, apenas texto.
// Cada NPC possui 3 variações (poucas / algumas / muitas mortes), usando o
// contador de mortes já persistido em Save.js (totalDeaths, vindo da engine).
// O protagonista nunca fala. Frases curtas. Nenhuma resposta completa.
// ---------------------------------------------------------------------------
// Título da tela de derrota — muda com o número de mortes acumuladas.
// Não altera respawn, dificuldade nem qualquer outra mecânica.
function deathScreenTitle(totalDeaths) {
  if (totalDeaths <= 1) return 'VOCÊ MORREU';
  if (totalDeaths < 3) return 'VOCÊ MORREU... OUTRA VEZ.';
  if (totalDeaths < 8) return 'VOCÊ JÁ CONHECE ESTE CAMINHO';
  return 'ELES AINDA NÃO PERMITEM SEU DESCANSO';
}

function deathTier(totalDeaths) {
  if (totalDeaths < 3) return 0;      // primeiro encontro
  if (totalDeaths < 8) return 1;      // mortes intermediárias
  return 2;                            // muitas mortes
}

// Linha discreta que aparece por alguns segundos sob o nome do andar,
// puramente narrativa (não altera spawn, dificuldade nem UI funcional).
function phaseFlavorLine(totalDeaths, phase = 1) {
  const tier = deathTier(totalDeaths);
  if (tier === 0) return null;
  if (tier === 1) return '...outra vez.';
  return phase % 2 === 0 ? 'Você conhece este lugar.' : 'Por que continua voltando?';
}

// NPC do primeiro corredor (Sobrevivente) — nunca explica nada, só observa.
const NPC_LINES_INTRO = [
  [ // poucas mortes
    "...não.",
    "Isso não deveria acontecer.",
    "Você morreu.",
    "Então...",
    "...quem voltou?",
  ],
  [ // mortes intermediárias
    "Você voltou mais cedo desta vez.",
    "Pensei que demoraria mais.",
    "Você continua esquecendo.",
    "E ainda assim... continua descendo.",
  ],
  [ // muitas mortes
    "Outra vez?",
    "Você nunca desiste.",
    "Pelo menos desta vez chegou mais longe.",
    "Nenhuma morte consegue prender você.",
    "Nunca consegue descansar...",
  ],
];
// NPC do andar 2 (Alma Perdida) — mantém a bênção (buff) já existente.
const NPC_LINES_FLOOR2 = [
  [ // poucas mortes
    "Não... não há volta. Esses corredores devoraram milhares como eu.",
    "O Pesadelo cresce. Cada andar é uma camada dele.",
    "Mas seus olhos... eu já vi esses olhos antes.",
    "Tome o que restou de mim. Que isso prolongue seu fio de vida.",
  ],
  [ // mortes intermediárias
    "Você voltou. Como sempre volta.",
    "O Pesadelo nunca dorme. E você também não.",
    "Cada morte alimenta o que espera lá no fundo.",
    "Aceite isso, viajante. Vai precisar.",
  ],
  [ // muitas mortes
    "Já perdi a conta de quantas vezes te vi passar por aqui.",
    "Eles ainda não permitem seu descanso.",
    "Talvez você nunca descanse.",
    "Tome. É pouco, mas é tudo que ainda tenho.",
  ],
];
const NPC_LINE_TIERS = { intro: NPC_LINES_INTRO, floor2: NPC_LINES_FLOOR2 };
const NPC_SPEAKER_NAMES = { intro: 'SOBREVIVENTE', floor2: 'ALMA PERDIDA' };

// Introdução narrativa exibida depois da revelação da classe e antes do
// primeiro andar. A tela escurece ao final e a caçada começa. Poucas
// palavras, nenhuma explicação — só perguntas.
const INTRO_STORY_LINES = [
  'O Pesadelo cresce.',
  'Cada morte alimenta o que espera lá no fundo.',
  'Você não lembra quem foi.',
  'Talvez seja melhor assim.',
];

// ---------------------------------------------------------------------------
// PRÓLOGO — tela preta com texto, duas imagens, e o título do capítulo.
// Nenhuma resposta é dada aqui; apenas a pergunta central da história.
// ---------------------------------------------------------------------------
const PROLOGUE_BEATS = [
  { type: 'text', text: 'Você caiu...' },
  { type: 'text', text: 'Mais uma vez.' },
  { type: 'text', text: 'Toda morte leva uma lembrança.' },
  { type: 'text', text: 'Toda lembrança esquecida fortalece o Pesadelo.' },
  { type: 'image', src: 'https://i.postimg.cc/vZ6fP4XJ/eksr96f6wik71.gif', duration: 4200 },
  { type: 'image', src: 'https://i.postimg.cc/xCjkS8y8/image-d94cuode878c73b71hq0-1.webp', duration: 5200 },
  { type: 'text', text: 'Um dia...' },
  { type: 'text', text: 'Você sabia quem era.' },
  { type: 'text', text: 'Se desta vez recuperar suas memórias...' },
  { type: 'text', text: '...não cometa o mesmo erro.' },
];

// --- Tela cheia real (Fullscreen API) ---------------------------------------------
// O 100dvh (em App.css/index.js) já evita que a barra do navegador "corte" o jogo,
// mas em navegadores embutidos de apps de edição de código (Quick Edit, Code Studio
// etc.) a barra de navegação/endereço continua visível e ocupando espaço de tela.
// A forma mais confiável e mais usada para eliminar isso de vez é pedir tela cheia
// de verdade via Fullscreen API (com os prefixos das engines mais antigas).
function requestFullscreen() {
  const el = document.documentElement;
  const fn = el.requestFullscreen || el.webkitRequestFullscreen || el.webkitEnterFullscreen
    || el.mozRequestFullScreen || el.msRequestFullscreen;
  if (fn) {
    try {
      const p = fn.call(el);
      if (p && p.catch) p.catch(() => {});
    } catch (e) { /* alguns navegadores lançam se não houver gesto do usuário */ }
  }
}
function exitFullscreen() {
  const fn = document.exitFullscreen || document.webkitExitFullscreen
    || document.mozCancelFullScreen || document.msExitFullscreen;
  if (fn) {
    try {
      const p = fn.call(document);
      if (p && p.catch) p.catch(() => {});
    } catch (e) {}
  }
}
function isFullscreenActive() {
  return !!(document.fullscreenElement || document.webkitFullscreenElement
    || document.mozFullScreenElement || document.msFullscreenElement);
}

// Suporte para PC removido: o jogo roda sempre no modo de controles touch
// (joystick + botões na tela), independente do dispositivo.

export default function InfernoGame() {
  const canvasRef = useRef(null);
  const engineRef = useRef(null);
  const spriteRef = useRef(null);
  const floorTexRef = useRef(null);
  const lavaTexRef = useRef(null);
  const npcIntroSpriteRef = useRef(null);
  const monsterSpritesRef = useRef({}); // { blood: {idle,walk,attack}, demon: {...} }
  const rafRef = useRef(null);
  const lastTRef = useRef(0);
  const joystickRef = useRef({ active: false, id: null, cx: 0, cy: 0, kx: 0, ky: 0, maxR: 60 });

  const [screen, setScreen] = useState('menu');
  const [touch] = useState(true);
  const [selectedClass, setSelectedClass] = useState('vampire');
  const [muted, setMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(isFullscreenActive());

  // Mantém isFullscreen em sincronia (funciona mesmo se o usuário sair com Esc,
  // gesto do sistema, etc., e não só pelo nosso próprio botão)
  useEffect(() => {
    const onFsChange = () => setIsFullscreen(isFullscreenActive());
    document.addEventListener('fullscreenchange', onFsChange);
    document.addEventListener('webkitfullscreenchange', onFsChange);
    document.addEventListener('mozfullscreenchange', onFsChange);
    document.addEventListener('MSFullscreenChange', onFsChange);
    return () => {
      document.removeEventListener('fullscreenchange', onFsChange);
      document.removeEventListener('webkitfullscreenchange', onFsChange);
      document.removeEventListener('mozfullscreenchange', onFsChange);
      document.removeEventListener('MSFullscreenChange', onFsChange);
    };
  }, []);

  // Navegadores só permitem pedir tela cheia em resposta a um gesto do usuário,
  // então não dá para forçar isso já no carregamento da página. Em vez disso,
  // aproveitamos o primeiro toque/clique em qualquer lugar da tela para tentar
  // entrar em tela cheia automaticamente — assim o jogador nem precisa saber
  // que existe um botão específico para isso.
  useEffect(() => {
    const tryAutoFullscreen = () => {
      if (!isFullscreenActive()) requestFullscreen();
    };
    window.addEventListener('pointerdown', tryAutoFullscreen, { once: true });
    return () => window.removeEventListener('pointerdown', tryAutoFullscreen);
  }, []);

  const toggleFullscreen = () => {
    if (isFullscreenActive()) exitFullscreen();
    else requestFullscreen();
  };
  const [ui, setUi] = useState({
    hp: 100, hpMax: 100, damage: 15, attackSpeed: 1, defense: 5, lifesteal: 0.05,
    level: 1, kills: 0, phase: 1,
    invulnCd: 0, invulnTime: 0, attack2Cooldown: 0, dashCd: 0, dashTime: 0,
    flasks: 3, flasksMax: 3,
    enemiesLeft: 0, bossSpawned: false, cleared: false, dead: false,
    classId: 'vampire', className: 'VAMPIRO',
    totalDeaths: 0, mapName: '', portalOpen: false,
  });
  const [npcLineIdx, setNpcLineIdx] = useState(0);
  const [npcBuffed, setNpcBuffed] = useState(false);
  const [npcKind, setNpcKind] = useState('floor2');
  const [npcLines, setNpcLines] = useState(NPC_LINES_FLOOR2[0]);
  const [nearNpc, setNearNpc] = useState(false);
  const [nearPortal, setNearPortal] = useState(false);
  const [savedRun, setSavedRun] = useState(null);
  const [settings, setSettings] = useState(() => loadSettings());
  const [paused, setPaused] = useState(false);
  const [settingsReturnScreen, setSettingsReturnScreen] = useState('menu');
  const [introLineIdx, setIntroLineIdx] = useState(0);
  const [introFadeOut, setIntroFadeOut] = useState(false);
  const [prologueIdx, setPrologueIdx] = useState(0);
  const [prologueFadeOut, setPrologueFadeOut] = useState(false);
  const [phaseFlavorVisible, setPhaseFlavorVisible] = useState(false);
  // ALTAR DAS MEMÓRIAS: fragmentos + habilidades desbloqueadas (progressão
  // permanente, persistida separadamente do save principal — ver MemorySave.js).
  const [memory, setMemory] = useState(() => loadMemory());
  const [memoryTreeReturnScreen, setMemoryTreeReturnScreen] = useState('menu');
  // Aviso rápido "+1 Fragmento" exibido ao vencer um andar (substitui a tela
  // do Altar nesse ponto do fluxo — some sozinho, não bloqueia o jogo).
  const [fragmentToast, setFragmentToast] = useState(null);
  // Atributo escolhido na tela pós-fase, aguardando confirmação pelo botão
  // "IR PARA O ANDAR X" antes de avançar de fato.
  const [selectedAttr, setSelectedAttr] = useState(null);

  useEffect(() => {
    if (fragmentToast === null) return;
    const t = setTimeout(() => setFragmentToast(null), 2000);
    return () => clearTimeout(t);
  }, [fragmentToast]);

  // Detect saved run
  useEffect(() => {
    const s = loadSave();
    setSavedRun(s && s.current ? s : (s && s.best ? s : null));
  }, [screen]);

  // Sprite preload
  useEffect(() => {
    const img = new Image();
    img.src = './assets/character.png';
    img.onload = () => { spriteRef.current = img; if (engineRef.current) engineRef.current.bindSprite(img); };

    const floorImg = new Image();
    floorImg.src = './assets/floor_texture.png';
    floorImg.onload = () => { floorTexRef.current = floorImg; if (engineRef.current) engineRef.current.bindFloorTexture(floorImg); };

    const lavaImg = new Image();
    lavaImg.src = './assets/lava_texture.png';
    lavaImg.onload = () => { lavaTexRef.current = lavaImg; if (engineRef.current) engineRef.current.bindLavaTexture(lavaImg); };

    // NPC introdutório do andar 1 (Garota fofa com franja branca): 6 quadros
    // da animação de "bebendo", virada de frente — dá um visual animado e
    // fluído no lugar do desenho vetorial anterior.
    const npcIntroImg = new Image();
    npcIntroImg.src = './assets/npc_intro.png';
    npcIntroImg.onload = () => { npcIntroSpriteRef.current = npcIntroImg; if (engineRef.current) engineRef.current.bindNpcIntroSprite(npcIntroImg); };

    // Monster sprites: 2 creature packs, recolored per-archetype in Engine.drawEnemySprite
    Object.entries(MONSTER_SPRITES).forEach(([key, anims]) => {
      Object.entries(anims).forEach(([animName, def]) => {
        const mImg = new Image();
        mImg.src = def.src;
        mImg.onload = () => {
          if (!monsterSpritesRef.current[key]) monsterSpritesRef.current[key] = {};
          monsterSpritesRef.current[key][animName] = mImg;
          if (engineRef.current) engineRef.current.bindMonsterSprite(key, animName, mImg);
        };
      });
    });
  }, []);

  // Re-binds every already-loaded texture/sprite onto a (re)created engine instance
  const bindAllVisuals = useCallback((eng) => {
    if (spriteRef.current) eng.bindSprite(spriteRef.current);
    if (floorTexRef.current) eng.bindFloorTexture(floorTexRef.current);
    if (lavaTexRef.current) eng.bindLavaTexture(lavaTexRef.current);
    if (npcIntroSpriteRef.current) eng.bindNpcIntroSprite(npcIntroSpriteRef.current);
    Object.entries(monsterSpritesRef.current).forEach(([key, anims]) => {
      Object.entries(anims).forEach(([animName, img]) => eng.bindMonsterSprite(key, animName, img));
    });
  }, []);

  // Engine init
  useEffect(() => {
    engineRef.current = new Engine({
      onUiUpdate: (data) => setUi(data),
      onPhaseClear: () => { setSelectedAttr(null); setScreen('attr'); },
      onDeath: () => setScreen('dead'),
      onVictory: () => setScreen('victory'),
      onMeetNpc: (npc) => {
        const kind = npc && npc.id === 'intro' ? 'intro' : 'floor2';
        const tier = deathTier(engineRef.current?.totalDeaths || 0);
        setNpcKind(kind);
        setNpcLines(NPC_LINE_TIERS[kind][tier]);
        setNpcLineIdx(0);
        setNpcBuffed(false);
        setScreen('npc');
      },
      settings: { screenShake: settings.screenShake, particles: settings.particles, quality: settings.quality },
    });
    bindAllVisuals(engineRef.current);
    engineRef.current.setMemoryBuild(memory.unlocked);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bindAllVisuals]);

  // Reaplica as configurações de Vídeo na engine sempre que forem alteradas em CONFIGURAÇÕES
  useEffect(() => {
    if (engineRef.current) {
      engineRef.current.updateSettings({
        screenShake: settings.screenShake,
        particles: settings.particles,
        quality: settings.quality,
      });
    }
  }, [settings.screenShake, settings.particles, settings.quality]);

  // Reaplica os volumes de Música/Efeitos sempre que forem alterados em CONFIGURAÇÕES
  useEffect(() => {
    audio.setMusicVolume(settings.musicVol);
    audio.setSfxVolume(settings.sfxVol);
  }, [settings.musicVol, settings.sfxVol]);

  const updateSetting = (key, value) => {
    setSettings((prev) => {
      const next = { ...prev, [key]: value };
      saveSettings({ [key]: value });
      return next;
    });
  };

  // Music scene management
  useEffect(() => {
    if (!audio.ctx) return;
    if (screen === 'playing') {
      if (ui.bossSpawned) {
        if (audio._curScene !== 'boss') { audio.startMusic('boss'); audio._curScene = 'boss'; }
      } else {
        if (audio._curScene !== 'dungeon') { audio.startMusic('dungeon'); audio._curScene = 'dungeon'; }
      }
    } else if (
      screen === 'menu' || screen === 'lore' || screen === 'class' || screen === 'prologue'
      || screen === 'settings' || screen === 'raceReveal' || screen === 'introText'
    ) {
      if (audio._curScene !== 'menu') { audio.startMusic('menu'); audio._curScene = 'menu'; }
    } else if (screen === 'dead' || screen === 'victory') {
      audio.stopMusic();
      audio._curScene = null;
    }
  }, [screen, ui.bossSpawned]);

  // Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    // A causa real das "listras" (linhas finas de interferência/moiré) não
    // era só a resolução do canvas — é o grid de "argamassa" entre os blocos
    // de pedra do chão: uma linha de 1px desenhada a cada 40px (TILE) pra dar
    // aparência de lajota (ver th.mortar em drawFloorTiles). Se a escala
    // final (tamanho físico da tela ÷ 1280) não for um número INTEIRO, essas
    // linhas de 1px caem em posições fracionárias de pixel, o navegador
    // borra/antialiasa cada uma de um jeito levemente diferente, e o
    // resultado visual é um padrão de interferência repetindo por toda a
    // tela — exatamente as listras. A correção definitiva é forçar a escala
    // pra ser sempre inteira (1x, 2x, 3x...): cada linha de grade cai exatamente
    // em cima de um pixel físico, sem sobra nenhuma pro navegador reamostrar.
    // Se sobrar espaço (a tela não é exatamente 16:9), o canvas fica com uma
    // margem preta ao redor (letterbox) em vez de esticar/distorcer.
    const syncCanvasResolution = () => {
      const wrap = canvas.parentElement;
      const dpr = Math.min(window.devicePixelRatio || 1, 3);
      const rect = (wrap || canvas).getBoundingClientRect();
      const availW = (rect.width || GAME_W) * dpr;
      const availH = (rect.height || GAME_H) * dpr;
      // Preenche 100% do espaço disponível (sem faixas pretas): a escala em
      // X e Y pode ser levemente diferente quando a tela não é exatamente
      // 16:9, mas nunca sobra margem preta — a prioridade agora é ocupar a
      // tela inteira em qualquer dispositivo (celular, PC, notebook etc.).
      const pixelW = Math.max(1, Math.round(availW)), pixelH = Math.max(1, Math.round(availH));
      if (canvas.width !== pixelW || canvas.height !== pixelH) {
        canvas.width = pixelW;
        canvas.height = pixelH;
      }
      if (canvas.style.width !== '100%') canvas.style.width = '100%';
      if (canvas.style.height !== '100%') canvas.style.height = '100%';
      const scaleX = pixelW / GAME_W, scaleY = pixelH / GAME_H;
      ctx.setTransform(scaleX, 0, 0, scaleY, 0, 0);
    };
    syncCanvasResolution();

    const loop = (t) => {
      // IMPORTANTE: o requestAnimationFrame(loop) de baixo TEM que rodar sempre,
      // não importa o que aconteça no frame. Antes, se eng.update()/eng.render()
      // lançasse qualquer exceção, a linha de reagendamento nunca era alcançada
      // e o loop parava PARA SEMPRE — o jogo ficava com a última imagem
      // desenhada "congelada" na tela (o sintoma de "jogo travado"), mesmo com
      // o resto da interface (botões de música/tela cheia, que vivem fora
      // desse loop) continuando a responder normalmente. O try/catch +
      // finally garante que um frame ruim vira, no pior caso, UM frame
      // perdido — nunca um travamento permanente.
      try {
        // Reconfere a resolução a cada frame (barato: só reage quando o
        // tamanho exibido realmente muda — rotação de tela, tela cheia
        // ligando/desligando, redimensionamento de janela etc.) em vez de
        // depender de um listener de "resize" que pode não disparar em todos
        // esses casos no celular.
        syncCanvasResolution();
        const dt = Math.min(0.05, (t - lastTRef.current) / 1000 || 0);
        lastTRef.current = t;
        const eng = engineRef.current;
        if (eng) {
          if (screen === 'playing' && !paused) eng.update(dt);
          ctx.clearRect(0, 0, GAME_W, GAME_H);
          eng.render(ctx);
          if (screen === 'playing') {
            const p = eng.player;
            const closeNpc = !!(eng.npcs && eng.npcs.length && eng.npcs.some(n => Math.hypot(n.x - p.x, n.y - p.y) < 70));
            if (closeNpc !== nearNpc) setNearNpc(closeNpc);
            const closePortal = !!(eng.portal && Math.hypot(eng.portal.x - p.x, eng.portal.y - p.y) < 70);
            if (closePortal !== nearPortal) setNearPortal(closePortal);
          } else {
            if (nearNpc) setNearNpc(false);
            if (nearPortal) setNearPortal(false);
          }
        }
      } catch (err) {
        // eslint-disable-next-line no-console
        console.error('[InfernoGame] erro no loop do jogo (frame ignorado, jogo continua rodando):', err);
      } finally {
        rafRef.current = requestAnimationFrame(loop);
      }
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
  }, [screen, nearNpc, nearPortal, paused]);

  // Controles por teclado/mouse (PC) foram removidos — o jogo agora usa
  // exclusivamente os controles touch (joystick + botões na tela).

  // Init audio on first interaction
  const ensureAudio = () => {
    if (!audio.ctx) { audio.init(); }
    audio.resume();
  };

  const startGame = () => {
    ensureAudio(); audio.play('click');
    setPrologueIdx(0);
    setPrologueFadeOut(false);
    setScreen('prologue');
  };

  // Prólogo: avança sozinho, batida por batida (texto ou imagem), e escurece
  // ao final antes de mostrar o título do capítulo. Tocar na tela também avança.
  useEffect(() => {
    if (screen !== 'prologue') return;
    if (prologueIdx >= PROLOGUE_BEATS.length) {
      setPrologueFadeOut(true);
      const t = setTimeout(() => setScreen('lore'), 900);
      return () => clearTimeout(t);
    }
    const beat = PROLOGUE_BEATS[prologueIdx];
    const wait = beat.type === 'image' ? (beat.duration || 4000) : 2600;
    const t = setTimeout(() => setPrologueIdx((i) => i + 1), wait);
    return () => clearTimeout(t);
  }, [screen, prologueIdx]);

  const advancePrologueBeat = () => {
    if (prologueIdx >= PROLOGUE_BEATS.length) return;
    audio.play('click');
    setPrologueIdx((i) => i + 1);
  };
  const skipPrologue = () => {
    audio.play('click');
    setPrologueFadeOut(true);
    setTimeout(() => setScreen('lore'), 500);
  };
  const goClass = () => { ensureAudio(); audio.play('click'); setScreen('class'); };
  const goBack = (s) => { audio.play('click'); setScreen(s); };
  const goSettings = () => {
    ensureAudio(); audio.play('click');
    setSettingsReturnScreen('menu');
    setScreen('settings');
  };

  // ===== Pause (menu de pausa dentro da partida) =====
  const pauseGame = () => { ensureAudio(); audio.play('click'); setPaused(true); };
  const resumeGame = () => { audio.play('click'); setPaused(false); };
  const goSettingsFromPause = () => {
    audio.play('click');
    setSettingsReturnScreen('playing');
    setScreen('settings');
  };
  const exitToMenu = () => {
    audio.play('click');
    // Salva o progresso atual antes de voltar ao menu, como um checkpoint manual.
    try { engineRef.current?.persistSnapshot(); } catch (_e) { /* ignore */ }
    setPaused(false);
    setScreen('menu');
  };

  const beginRun = (classId) => {
    ensureAudio();
    audio.play('click');
    engineRef.current.reset(classId);
    engineRef.current.setMemoryBuild(memory.unlocked);
    bindAllVisuals(engineRef.current);
    setSelectedClass(classId);
    setIntroLineIdx(0);
    setIntroFadeOut(false);
    // Não entra direto no andar 1: primeiro revela a raça escolhida (2s),
    // depois a pequena introdução narrativa, só então a caçada começa.
    setScreen('raceReveal');
  };

  const continueRun = () => {
    ensureAudio();
    audio.play('click');
    const s = loadSave();
    if (!s || !s.current) return;
    const snap = s.current;
    engineRef.current.reset(snap.classId || 'vampire');
    engineRef.current.setMemoryBuild(memory.unlocked);
    bindAllVisuals(engineRef.current);
    engineRef.current.loadFromSave(snap);
    setScreen('playing');
  };

  const wipeSave = () => {
    if (!window.confirm('Isso vai apagar todo o seu progresso salvo. Tem certeza?')) return;
    audio.play('click');
    clearAllSave();
    setSavedRun(null);
  };

  // Revelação da raça (2s) → introdução narrativa automática
  useEffect(() => {
    if (screen !== 'raceReveal') return;
    const t = setTimeout(() => { setScreen('introText'); }, 2000);
    return () => clearTimeout(t);
  }, [screen]);

  // Mostra por alguns segundos o nome do andar + a linha de "reconhecimento"
  // do mundo (tier de mortes) sempre que uma nova fase começa. Puramente
  // textual — não interfere em spawn, câmera ou qualquer outra mecânica.
  useEffect(() => {
    if (screen !== 'playing') return;
    setPhaseFlavorVisible(true);
    const t = setTimeout(() => setPhaseFlavorVisible(false), 3800);
    return () => clearTimeout(t);
  }, [screen, ui.phase]);

  // Introdução narrativa: avança linha a linha sozinha (~3s cada, 10-15s no
  // total) e escurece a tela ao final antes de iniciar o 1º andar. Tocar na
  // tela também avança na hora.
  useEffect(() => {
    if (screen !== 'introText') return;
    if (introLineIdx >= INTRO_STORY_LINES.length) {
      setIntroFadeOut(true);
      const t = setTimeout(() => setScreen('playing'), 900);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => setIntroLineIdx((i) => i + 1), 3000);
    return () => clearTimeout(t);
  }, [screen, introLineIdx]);

  const advanceIntroLine = () => {
    if (introLineIdx >= INTRO_STORY_LINES.length) return;
    audio.play('click');
    setIntroLineIdx((i) => i + 1);
  };
  const skipIntro = () => {
    audio.play('click');
    setIntroFadeOut(true);
    setTimeout(() => setScreen('playing'), 500);
  };

  const pickAttr = (key) => {
    if (selectedAttr === key) return; // já é a escolha atual; nada a fazer
    audio.play('click');
    if (selectedAttr) engineRef.current.revertAttribute(selectedAttr); // desfaz a escolha anterior
    engineRef.current.applyAttribute(key);
    setSelectedAttr(key);
  };

  // Botão "IR PARA O ANDAR X": só aparece depois de escolher a dádiva.
  // ALTAR DAS MEMÓRIAS: 1 fase concluída = 1 Fragmento, sempre (não depende
  // de Boss nem de XP). Mostra um aviso rápido "+1 Fragmento" e aí sim avança
  // pra próxima fase (o Altar/Constelação continua acessível pelo menu).
  const confirmAdvance = () => {
    audio.play('click');
    const nextMemory = addFragment();
    setMemory(nextMemory);
    setFragmentToast(nextMemory.fragments);
    engineRef.current.nextPhase();
    setScreen('playing');
  };

  // Botão CONTINUAR do Altar (mantido apenas para o fluxo acessado pelo menu
  // principal, quando o jogador entra no Altar fora de uma transição de fase).
  const continueFromAltar = () => {
    audio.play('click');
    setScreen(memoryTreeReturnScreen);
  };

  const openMemoryTree = () => {
    audio.play('click');
    setMemoryTreeReturnScreen(screen === 'altar' ? 'altar' : 'menu');
    setScreen('constellation');
  };

  const closeMemoryTree = () => {
    audio.play('click');
    setScreen(memoryTreeReturnScreen);
  };

  const handleUnlockSkill = (skillId) => {
    const next = unlockSkill(skillId);
    setMemory(next);
    engineRef.current?.setMemoryBuild(next.unlocked);
  };

  const handleResetMemory = () => {
    if (!window.confirm('Isso devolve todos os Fragmentos investidos e limpa sua build atual. XP, nível, itens e equipamentos não são afetados. Deseja continuar?')) return;
    audio.play('click');
    const next = resetMemory();
    setMemory(next);
    engineRef.current?.setMemoryBuild(next.unlocked);
  };

  const advanceNpc = () => {
    audio.play('click');
    if (npcLineIdx < npcLines.length - 1) { setNpcLineIdx(npcLineIdx + 1); return; }
    // NPC do andar 1: só ao encerrar a conversa os inimigos daquele andar aparecem.
    if (npcKind === 'intro') engineRef.current?.releaseIntroEnemies();
    setScreen('playing');
  };
  const acceptNpcBuff = () => {
    if (!npcBuffed) {
      audio.play('skill1');
      engineRef.current.applyNpcBuff();
      setNpcBuffed(true);
    }
  };

  // Touch joystick
  const onJoyStart = (e) => {
    e.preventDefault();
    const tch = e.touches[0];
    const rect = e.currentTarget.getBoundingClientRect();
    joystickRef.current = {
      active: true, id: tch.identifier,
      cx: rect.left + rect.width / 2,
      cy: rect.top + rect.height / 2,
      kx: 0, ky: 0,
      maxR: rect.width / 2 - 10,
    };
    updateKnobUI();
  };
  const onJoyMove = (e) => {
    e.preventDefault();
    const j = joystickRef.current;
    if (!j.active) return;
    const tch = Array.from(e.touches).find(tt => tt.identifier === j.id);
    if (!tch) return;
    let dx = tch.clientX - j.cx;
    let dy = tch.clientY - j.cy;
    const d = Math.hypot(dx, dy);
    const max = j.maxR || 60;
    if (d > max) { dx = (dx / d) * max; dy = (dy / d) * max; }
    j.kx = dx; j.ky = dy;
    const eng = engineRef.current;
    if (!eng) return;
    const threshold = 0.25 * max;
    eng.setInput('left', dx < -threshold);
    eng.setInput('right', dx > threshold);
    eng.setInput('up', dy < -threshold);
    eng.setInput('down', dy > threshold);
    updateKnobUI();
  };
  const onJoyEnd = (e) => {
    e.preventDefault();
    const j = joystickRef.current;
    j.active = false; j.kx = 0; j.ky = 0;
    const eng = engineRef.current;
    if (eng) {
      eng.setInput('left', false); eng.setInput('right', false);
      eng.setInput('up', false); eng.setInput('down', false);
    }
    updateKnobUI();
  };
  const updateKnobUI = () => {
    const knob = document.getElementById('joy-knob');
    if (!knob) return;
    const j = joystickRef.current;
    knob.style.transform = `translate(calc(-50% + ${j.kx}px), calc(-50% + ${j.ky}px))`;
  };

  const touchAttackDown = (e) => { e.preventDefault(); engineRef.current?.setInput('attack', true); };
  const touchAttackUp = (e) => { e.preventDefault(); engineRef.current?.setInput('attack', false); };
  const touchAttack2Down = (e) => { e.preventDefault(); engineRef.current?.setInput('attack2', true); };
  const touchAttack2Up = (e) => { e.preventDefault(); engineRef.current?.setInput('attack2', false); };
  const touchInvuln = (e) => { e.preventDefault(); engineRef.current?.useSkill1(); };
  const touchDodge = (e) => { e.preventDefault(); engineRef.current?.dodge(); };
  const touchHeal = (e) => { e.preventDefault(); engineRef.current?.useHealFlask(); };
  const touchInteract = (e) => { e.preventDefault(); engineRef.current?.tryInteract(); };

  const toggleMute = () => { ensureAudio(); const m = audio.toggleMute(); setMuted(m); };

  const hpPct = clamp((ui.hp / ui.hpMax) * 100, 0, 100);
  const xpPct = ((ui.kills % 5) / 5) * 100;

  return (
    <div className={`game-wrap ${touch ? 'touch-on' : ''}`} data-testid="game-wrap">
      <canvas
        ref={canvasRef}
        className="game-canvas"
        data-testid="game-canvas"
      />

      <button
        className="mute-btn"
        data-testid="mute-btn"
        onClick={toggleMute}
        title={muted ? 'Tirar do mudo' : 'Mutar'}
      >
        {muted ? '♪' : '♫'}
      </button>

      <button
        className="fullscreen-btn"
        data-testid="fullscreen-btn"
        onClick={toggleFullscreen}
        title={isFullscreen ? 'Sair da tela cheia' : 'Tela cheia (remove a barra do navegador)'}
      >
        {isFullscreen ? '⤡' : '⤢'}
      </button>

      {screen === 'playing' && !paused && (
        <button
          className="pause-btn"
          data-testid="pause-btn"
          onClick={pauseGame}
          title="Pausar"
        >
          ⏸
        </button>
      )}

      {screen === 'playing' && (
        <div className="hud" data-testid="hud">
          <div className="hud-top">
            <div className="hud-bars">
              <div className="bar hp" data-testid="hp-bar">
                <span style={{ width: `${hpPct}%` }} />
                <div className="bar-label">{Math.ceil(ui.hp)} / {Math.ceil(ui.hpMax)}</div>
              </div>
              <div className="flasks" data-testid="flasks-display">
                {Array.from({ length: ui.flasksMax || 3 }).map((_, i) => (
                  <span key={i} className={`flask-icon ${i < ui.flasks ? 'filled' : 'empty'}`}>⚗</span>
                ))}
              </div>
              <div className="bar xp" data-testid="xp-bar">
                <span style={{ width: `${xpPct}%` }} />
                <div className="bar-label">NV {ui.level}  •  {ui.kills} ABATES  •  {ui.className}</div>
              </div>
            </div>
            <div className="hud-panel" data-testid="phase-label">
              ANDAR {ui.phase} / {PHASES}
              <div style={{ fontSize: 14, color: '#c79262' }}>
                {ui.bossSpawned ? 'BELIAL DESPERTOU' : `${ui.enemiesLeft} DEMÔNIOS`}
              </div>
              {phaseFlavorVisible && (
                <div className="phase-flavor">
                  {ui.mapName}
                  {phaseFlavorLine(ui.totalDeaths) && <><br/>{phaseFlavorLine(ui.totalDeaths, ui.phase)}</>}
                </div>
              )}
              {ui.portalOpen && !ui.bossSpawned && (
                <div className="phase-flavor portal-hint">Um portal se abriu...</div>
              )}
            </div>
            <div className="hud-panel" data-testid="stats-panel">
              ⚔ {Math.round(ui.damage)}<br/>
              ⚡ {ui.attackSpeed.toFixed(2)}/s<br/>
              ⛨ {Math.round(ui.defense)}<br/>
              ✚ {Math.round(ui.lifesteal * 100)}%
            </div>
          </div>

          <div
            className="touch-controls"
            style={{ '--joy-scale': settings.joystickSize / 100, '--btn-scale': settings.buttonSize / 100 }}
          >
            <div
              className="joystick"
              data-testid="joystick"
              onTouchStart={onJoyStart}
              onTouchMove={onJoyMove}
              onTouchEnd={onJoyEnd}
              onTouchCancel={onJoyEnd}
            >
              <div id="joy-knob" className="knob" />
            </div>
            <div className="touch-actions">
              <button className="touch-btn skill" data-testid="touch-skill-1" onTouchStart={touchInvuln}>
                <div className="ico">✸</div>
                <div className="lbl">INVUL</div>
                {ui.invulnCd > 0 && <div className="cd">{ui.invulnCd.toFixed(1)}</div>}
              </button>
              <button
                className="touch-btn skill"
                data-testid="touch-attack-2"
                onTouchStart={touchAttack2Down}
                onTouchEnd={touchAttack2Up}
                onTouchCancel={touchAttack2Up}
              >
                <div className="ico">⚔</div>
                <div className="lbl sm">ATAQUE 2</div>
              </button>
              <button className="touch-btn skill" data-testid="touch-dodge" onTouchStart={touchDodge}>
                <div className="ico">↩</div>
                <div className="lbl sm">ESQUIVA</div>
                {ui.dashCd > 0 && <div className="cd">{ui.dashCd.toFixed(1)}</div>}
              </button>
              <button
                className="touch-btn attack"
                data-testid="touch-attack"
                onTouchStart={touchAttackDown}
                onTouchEnd={touchAttackUp}
                onTouchCancel={touchAttackUp}
              >
                <div className="ico">⚔</div>
                <div className="lbl">ATAQUE 1</div>
              </button>
            </div>
            <button
              className={`touch-heal ${(ui.flasks <= 0 || ui.hp >= ui.hpMax) ? 'disabled' : ''}`}
              data-testid="touch-heal"
              onTouchStart={touchHeal}
            >
              <div className="ico">⚗</div>
              <div className="lbl sm">CURAR</div>
              <div className="flask-count">{ui.flasks}</div>
            </button>
            <button
              className={`touch-interact ${(nearNpc || nearPortal) ? 'visible' : ''} ${nearPortal ? 'portal' : ''}`}
              data-testid="touch-interact"
              onTouchStart={touchInteract}
              onClick={touchInteract}
            >
              {nearPortal ? 'ENTRAR' : 'FALAR'}
            </button>
          </div>

          {ui.bossSpawned && engineRef.current?.bossBannerTime > 0 && (
            <div className="boss-banner">BELIAL</div>
          )}

          {fragmentToast !== null && (
            <div className="fragment-toast" data-testid="fragment-toast">
              <div className="fragment-toast-title">+1 FRAGMENTO</div>
              <div className="fragment-toast-total">TOTAL: {fragmentToast}</div>
            </div>
          )}
        </div>
      )}

      {screen === 'playing' && paused && (
        <div className="screen pause-screen" data-testid="pause-screen">
          <h2 className="title" style={{ fontSize: 'clamp(32px, 6vw, 56px)' }}>PAUSADO</h2>
          <button className="menu-btn" onClick={resumeGame} data-testid="resume-btn">
            CONTINUAR
          </button>
          <button className="menu-btn" onClick={goSettingsFromPause} data-testid="pause-settings-btn">
            CONFIGURAÇÕES
          </button>
          <button className="menu-btn" onClick={exitToMenu} data-testid="pause-exit-btn">
            SAIR
          </button>
        </div>
      )}

      {screen === 'menu' && (
        <>
          <div className="menu-bg" data-testid="menu-bg" aria-hidden="true" />
          <div className="screen menu-screen" data-testid="menu-screen">
            <h1 className="title logo-title">INFERNO</h1>
            <div className="subtitle">O CAÇADOR DESCE</div>
            <div className="lore">
              Sem nome. Sem rosto. Sem emoções.<br/>
              Uma entidade firmada num pacto antigo<br/>
              que persegue os demônios até o último eco.<br/>
              <span style={{ color: '#ff5028' }}>Belial</span> aguarda, dez andares abaixo.
            </div>
            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', justifyContent: 'center' }}>
              <button className="menu-btn" onClick={startGame} data-testid="start-btn">
                {savedRun && savedRun.current ? 'NOVA CAÇADA' : 'INICIAR CAÇADA'}
              </button>
              {savedRun && savedRun.current && (
                <button className="menu-btn" onClick={continueRun} data-testid="continue-btn">
                  CONTINUAR (ANDAR {savedRun.current.phase})
                </button>
              )}
              <button className="menu-btn" onClick={goSettings} data-testid="settings-btn">
                CONFIGURAÇÕES
              </button>
              <button className="menu-btn" onClick={openMemoryTree} data-testid="memory-tree-btn">
                ALTAR DAS MEMÓRIAS
              </button>
            </div>
            {savedRun && savedRun.best && (
              <div style={{ marginTop: 18, fontSize: 16, color: '#8a6040', letterSpacing: 2 }}>
                MELHOR PROFUNDIDADE: ANDAR {savedRun.best.phase}  •  {savedRun.best.kills} ABATES
                <button
                  className="menu-btn"
                  style={{ marginLeft: 14, fontSize: 12, padding: '4px 10px' }}
                  onClick={wipeSave}
                  data-testid="wipe-save-btn"
                >
                  APAGAR SAVE
                </button>
              </div>
            )}
          </div>
        </>
      )}

      {screen === 'settings' && (
        <div className="screen settings-screen" data-testid="settings-screen">
          <h2 className="title" style={{ fontSize: 44 }}>CONFIGURAÇÕES</h2>

          <div className="settings-section">
            <div className="settings-section-title">Áudio</div>
            <label className="settings-row">
              <span>Música</span>
              <input
                type="range" min="0" max="100"
                value={Math.round(settings.musicVol * 100)}
                onChange={(e) => updateSetting('musicVol', Number(e.target.value) / 100)}
                data-testid="music-vol-slider"
              />
              <span className="settings-value">{Math.round(settings.musicVol * 100)}%</span>
            </label>
            <label className="settings-row">
              <span>Efeitos</span>
              <input
                type="range" min="0" max="100"
                value={Math.round(settings.sfxVol * 100)}
                onChange={(e) => updateSetting('sfxVol', Number(e.target.value) / 100)}
                data-testid="sfx-vol-slider"
              />
              <span className="settings-value">{Math.round(settings.sfxVol * 100)}%</span>
            </label>
          </div>

          <div className="settings-section">
            <div className="settings-section-title">Vídeo</div>
            <label className="settings-row checkbox-row">
              <input
                type="checkbox"
                checked={settings.screenShake}
                onChange={(e) => updateSetting('screenShake', e.target.checked)}
                data-testid="screen-shake-toggle"
              />
              <span>Tremor da Tela</span>
            </label>
            <label className="settings-row checkbox-row">
              <input
                type="checkbox"
                checked={settings.particles}
                onChange={(e) => updateSetting('particles', e.target.checked)}
                data-testid="particles-toggle"
              />
              <span>Partículas</span>
            </label>
            <label className="settings-row">
              <span>Qualidade</span>
              <select
                value={settings.quality}
                onChange={(e) => updateSetting('quality', e.target.value)}
                data-testid="quality-select"
              >
                <option value="baixo">Baixo</option>
                <option value="medio">Médio</option>
                <option value="alto">Alto</option>
              </select>
            </label>
          </div>

          <div className="settings-section">
            <div className="settings-section-title">Controles</div>
            <label className="settings-row">
              <span>Tamanho do Joystick</span>
              <input
                type="range" min="60" max="150"
                value={settings.joystickSize}
                onChange={(e) => updateSetting('joystickSize', Number(e.target.value))}
                data-testid="joystick-size-slider"
              />
              <span className="settings-value">{settings.joystickSize}%</span>
            </label>
            <label className="settings-row">
              <span>Tamanho dos Botões</span>
              <input
                type="range" min="60" max="150"
                value={settings.buttonSize}
                onChange={(e) => updateSetting('buttonSize', Number(e.target.value))}
                data-testid="button-size-slider"
              />
              <span className="settings-value">{settings.buttonSize}%</span>
            </label>
          </div>

          <div className="settings-section">
            <div className="settings-section-title">Outros</div>
            <button className="menu-btn danger" onClick={wipeSave} data-testid="wipe-progress-btn">
              APAGAR PROGRESSO
            </button>
          </div>

          <button className="menu-btn" onClick={() => goBack(settingsReturnScreen)} data-testid="settings-back-btn">
            ← VOLTAR
          </button>
        </div>
      )}

      {screen === 'prologue' && (
        <div
          className={`screen prologue-screen ${prologueFadeOut ? 'fade-out' : ''}`}
          data-testid="prologue-screen"
          onClick={advancePrologueBeat}
        >
          <div className="prologue-stage">
            {prologueIdx < PROLOGUE_BEATS.length && PROLOGUE_BEATS[prologueIdx].type === 'text' && (
              <div className="prologue-line" key={prologueIdx}>{PROLOGUE_BEATS[prologueIdx].text}</div>
            )}
            {prologueIdx < PROLOGUE_BEATS.length && PROLOGUE_BEATS[prologueIdx].type === 'image' && (
              <img
                className="prologue-image"
                key={prologueIdx}
                src={PROLOGUE_BEATS[prologueIdx].src}
                alt=""
              />
            )}
          </div>
          <button
            className="menu-btn intro-skip-btn"
            onClick={(e) => { e.stopPropagation(); skipPrologue(); }}
            data-testid="prologue-skip-btn"
          >
            PULAR
          </button>
        </div>
      )}

      {screen === 'raceReveal' && (
        <div className="screen race-reveal-screen" data-testid="race-reveal-screen">
          <div className="race-reveal-name" style={{ color: CLASSES[selectedClass].color }}>
            {CLASSES[selectedClass].icon} {CLASSES[selectedClass].name}
          </div>
          <div className="race-reveal-tagline">"{CLASSES[selectedClass].tagline}"</div>
        </div>
      )}

      {screen === 'introText' && (
        <div
          className={`screen intro-text-screen ${introFadeOut ? 'fade-out' : ''}`}
          data-testid="intro-text-screen"
          onClick={advanceIntroLine}
        >
          <div className="intro-text-lines">
            {INTRO_STORY_LINES.map((line, i) => (
              <div
                key={i}
                className={`intro-text-line ${i === introLineIdx ? 'active' : ''}`}
              >
                {line}
              </div>
            ))}
          </div>
          <button
            className="menu-btn intro-skip-btn"
            onClick={(e) => { e.stopPropagation(); skipIntro(); }}
            data-testid="intro-skip-btn"
          >
            PULAR
          </button>
        </div>
      )}

      {screen === 'lore' && (
        <div className="screen lore-screen chapter-title-screen" data-testid="lore-screen">
          <div className="chapter-title-mark">INFERNO</div>
          <div className="chapter-title-sub">Capítulo I</div>
          <div className="chapter-title-name">O Último Condenado</div>
          <div className="lore-actions">
            <button className="menu-btn" onClick={() => goBack('menu')} data-testid="lore-back-btn">VOLTAR</button>
            <button className="menu-btn" onClick={goClass} data-testid="lore-continue-btn">PROSSEGUIR</button>
          </div>
        </div>
      )}

      {screen === 'class' && (
        <div className="screen class-screen" data-testid="class-screen">
          <h2 className="title" style={{ fontSize: '54px' }}>ESCOLHA SEU CAMINHO</h2>
          <div className="subtitle">QUE FORMA SUA ALMA ASSUMIU?</div>
          <div className="class-grid" data-testid="class-grid">
            {Object.values(CLASSES).map(c => (
              <div
                key={c.id}
                className={`class-card ${selectedClass === c.id ? 'selected' : ''}`}
                data-testid={`class-${c.id}`}
                onClick={() => { audio.play('click'); setSelectedClass(c.id); }}
                onDoubleClick={() => beginRun(c.id)}
              >
                <div className="class-portrait-wrap" style={{ boxShadow: `0 0 16px ${c.color}66` }}>
                  <img
                    src="./assets/character_portrait.png"
                    alt={c.name}
                    className="class-portrait"
                    style={{ filter: c.portraitFilter }}
                  />
                </div>

                <div className="class-name" style={{ color: c.color }}>{c.icon} {c.name}</div>
                <div className="class-style" style={{ borderColor: c.color, color: c.color }}>{c.style}</div>
                <div className="class-tag">"{c.tagline}"</div>

                <div className="class-stat-block">
                  <div className="class-stat-label pos">Vantagens</div>
                  <ul className="class-stat-list pos">
                    {c.advantages.map((a, i) => <li key={i}>{a}</li>)}
                  </ul>
                </div>
                <div className="class-stat-block">
                  <div className="class-stat-label neg">Desvantagens</div>
                  <ul className="class-stat-list neg">
                    {c.disadvantages.map((d, i) => <li key={i}>{d}</li>)}
                  </ul>
                </div>

                <div className="class-passive-box" style={{ borderColor: `${c.color}88` }}>
                  <div className="class-passive-name" style={{ color: c.color }}>✦ {c.passiveName}</div>
                  <div className="class-passive-desc">{c.passiveDesc}</div>
                </div>

                <div className="class-ideal">
                  <span className="class-ideal-label">Ideal para:</span> {c.idealFor.join(' · ')}
                </div>
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 20 }}>
            <button className="menu-btn" onClick={() => goBack('lore')} data-testid="back-btn">VOLTAR</button>
            <button className="menu-btn" onClick={() => beginRun(selectedClass)} data-testid="confirm-class-btn">
              DESCER COMO {CLASSES[selectedClass].name}
            </button>
          </div>
        </div>
      )}

      {screen === 'attr' && (
        <div className="screen" data-testid="attr-screen">
          <h2 className="title" style={{ fontSize: '54px' }}>ANDAR {ui.phase} VENCIDO</h2>
          <div className="subtitle">ESCOLHA UMA DÁDIVA SOMBRIA</div>
          <div className="attr-grid">
            {ATTRS.map(a => (
              <div
                key={a.key}
                className={`attr-card ${selectedAttr === a.key ? 'selected' : ''}`}
                data-testid={`attr-${a.key}`}
                onClick={() => pickAttr(a.key)}
              >
                <div className="ico">{a.ico}</div>
                <div className="name">{a.name}</div>
                <div className="val">{a.val}</div>
                <div className="desc">{a.desc}</div>
              </div>
            ))}
          </div>
          {selectedAttr && (
            <button className="menu-btn" style={{ marginTop: 20 }} onClick={confirmAdvance} data-testid="attr-confirm-btn">
              IR PARA O ANDAR {ui.phase + 1}
            </button>
          )}
        </div>
      )}

      {screen === 'altar' && (
        <AltarScreen
          fragments={memory.fragments}
          onOpenTree={openMemoryTree}
          onContinue={continueFromAltar}
        />
      )}

      {screen === 'constellation' && (
        <ConstellationScreen
          fragments={memory.fragments}
          unlocked={memory.unlocked}
          onUnlock={handleUnlockSkill}
          onReset={handleResetMemory}
          onBack={closeMemoryTree}
        />
      )}

      {screen === 'npc' && (
        <div className="screen" data-testid="npc-screen">
          <div className="dialog-box">
            <div className="speaker">{NPC_SPEAKER_NAMES[npcKind]}</div>
            <div>{npcLines[npcLineIdx]}</div>
          </div>
          {npcKind === 'floor2' && npcLineIdx === npcLines.length - 1 && !npcBuffed && (
            <button className="menu-btn" onClick={acceptNpcBuff} data-testid="npc-accept-btn">ACEITAR BÊNÇÃO (+3% Vamp. e cura total)</button>
          )}
          <button className="menu-btn" onClick={advanceNpc} data-testid="npc-next-btn">
            {npcLineIdx < npcLines.length - 1
              ? 'CONTINUAR'
              : (npcKind === 'floor2' ? (npcBuffed ? 'SEGUIR EM FRENTE' : 'DEIXAR PARA TRÁS') : 'SEGUIR EM FRENTE')}
          </button>
        </div>
      )}

      {screen === 'dead' && (
        <div className="screen" data-testid="dead-screen">
          <h2 className="title" style={{ color: 'transparent', WebkitTextStroke: '1px #ff2020' }}>
            {deathScreenTitle(ui.totalDeaths)}
          </h2>
          <div className="subtitle">No andar {ui.phase}, com {ui.kills} abates.</div>
          <button className="menu-btn" onClick={() => setScreen('class')} data-testid="restart-btn">TENTAR DE NOVO</button>
        </div>
      )}

      {screen === 'victory' && (
        <div className="screen" data-testid="victory-screen">
          <h2 className="title">BELIAL CAIU</h2>
          <div className="subtitle">O PRIMEIRO SELO FOI ROMPIDO</div>
          <div className="lore" style={{ maxWidth: 560, textAlign: 'center', lineHeight: 1.9 }}>
            "Você continua esquecendo..."<br/>
            "Era exatamente isso que Eles desejavam."<br/>
            "Você acredita estar preso no Inferno."<br/>
            "Mas..."<br/>
            "...o Inferno está preso em você."
            <br/><br/>
            <span style={{ opacity: 0.75 }}>
              Belial caiu.<br/>
              O primeiro selo foi rompido.<br/>
              ...restam seis.
            </span>
          </div>
          <button className="menu-btn" onClick={() => setScreen('class')} data-testid="play-again-btn">JOGAR NOVAMENTE</button>
        </div>
      )}
    </div>
  );
}

function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
