// ============================================================================
// ALTAR DAS MEMÓRIAS — persistência
// ----------------------------------------------------------------------------
// Armazenamento PRÓPRIO (chave separada do save principal em Save.js) para não
// interferir em nenhum dado do sistema de save já existente (XP, nível, fase,
// itens, equipamentos etc. continuam sendo geridos exclusivamente por Save.js).
//
// Formato salvo:
//   {
//     fragments: number,     // fragmentos disponíveis (ainda não gastos)
//     unlocked: string[],    // ids das habilidades desbloqueadas (a "build")
//   }
// ============================================================================
import { canUnlock, FRAGMENT_COST, SKILLS_BY_ID } from './MemoryTree.js';

const KEY = 'inferno_memory_v1';

function defaultState() {
  return { fragments: 0, unlocked: [] };
}

export function loadMemory() {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultState();
    const data = JSON.parse(raw);
    if (!data || typeof data !== 'object') return defaultState();
    return {
      fragments: Number.isFinite(data.fragments) ? data.fragments : 0,
      unlocked: Array.isArray(data.unlocked) ? data.unlocked : [],
    };
  } catch (_e) {
    return defaultState();
  }
}

function persist(state) {
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (_e) { /* storage indisponível */ }
  return state;
}

// Chamado sempre que uma fase é concluída: 1 fase = 1 Fragmento, sempre
// (não depende de Boss, nem de XP).
export function addFragment() {
  const state = loadMemory();
  state.fragments += 1;
  return persist(state);
}

export function unlockSkill(skillId) {
  const state = loadMemory();
  const unlockedSet = new Set(state.unlocked);
  const skill = SKILLS_BY_ID[skillId];
  const canBuy = state.fragments >= FRAGMENT_COST && canUnlock(skill, unlockedSet);
  if (!canBuy) return state;
  state.fragments -= FRAGMENT_COST;
  state.unlocked = [...state.unlocked, skillId];
  return persist(state);
}

// REDEFINIR MEMÓRIAS: devolve todos os fragmentos investidos. Não toca em
// XP, nível, itens ou equipamentos (esses vivem exclusivamente em Save.js).
export function resetMemory() {
  const state = loadMemory();
  state.fragments += state.unlocked.length;
  state.unlocked = [];
  return persist(state);
}
