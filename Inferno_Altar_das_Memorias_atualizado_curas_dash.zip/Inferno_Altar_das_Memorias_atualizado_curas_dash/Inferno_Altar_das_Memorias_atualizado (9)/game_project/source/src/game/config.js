// Game engine for "INFERNO" - top-down action roguelite.
// Renders to a canvas. Uses raf loop. Player has 8-direction movement,
// medium-range slash attack, 3 active skills, 10 phases, attribute selection.

// Viewport (what the camera shows)
export const W = 1280;
export const H = 720;

// World size (whole dungeon). Camera follows player and clamps to world bounds.
export const WORLD_W = 2560;
export const WORLD_H = 1600;

// Tile size used by the roguelike dungeon generator
export const TILE = 40;

export const PHASES = 10;

// Player base stats
export const BASE = {
  hp: 100,
  damage: 15,
  attackSpeed: 1.0, // attacks per second
  defense: 5,
  lifesteal: 0.05,
  moveSpeed: 220,
  attackRange: 110, // medium range slash
};

// Per-level multiplier (every 5 kills => +5% all)
export const LEVEL_BONUS = 0.05;

// ===== ESSÊNCIA REMANESCENTE (CURA) =====
// Sistema de cura baseado em identidade: o jogador carrega frascos
// consumíveis que restauram uma fração do HP máximo ao serem usados.
export const FLASK_MAX_START = 3;   // quantidade de frascos ao iniciar a corrida
export const FLASK_HEAL_PCT = 0.20; // cada frasco cura 20% do HP TOTAL (hpMax)

// Character classes - each with passive bonuses applied on game start.
// Each class also carries a unique triggered passive skill (handled in
// Engine.js: damagePlayer/killEnemy/updatePlayer) on top of its static bonuses.
export const CLASSES = {
  undead: {
    id: 'undead',
    name: 'MORTO-VIVO',
    icon: '🟢',
    tagline: 'A carne que se recusa a morrer.',
    style: 'Tanque',
    color: '#7ab84a',
    portraitFilter: 'hue-rotate(33deg) saturate(1.3) contrast(1.05)',
    advantages: [
      '+25% Vida Máxima',
      '+20% Defesa',
      'Regenera 1 HP/s',
    ],
    disadvantages: [
      '-10% Velocidade de movimento',
      '-5% Velocidade de ataque',
    ],
    idealFor: [
      'Iniciantes',
      'Jogadores que preferem sobreviver mais tempo',
    ],
    passiveName: 'Resistência Inabalável',
    passiveDesc: 'Ao cair abaixo de 25% da vida, recebe 30% menos dano por 5s (recarga de 60s).',
    bonuses: {
      hpMul: 1.25,
      defenseMul: 1.20,
      regenPerSec: 1,
      moveSpeedMul: 0.90,
      attackSpeedMul: 0.95,
    },
    // Kept for any legacy code paths that still read a flat passives list.
    passives: [
      '+25% Vida Máxima', '+20% Defesa', 'Regenera 1 HP/s',
      '-10% Velocidade de movimento', '-5% Velocidade de ataque',
    ],
  },
  vampire: {
    id: 'vampire',
    name: 'VAMPIRO',
    icon: '🔴',
    tagline: 'A sede nunca termina.',
    style: 'Guerreiro agressivo',
    color: '#c01030',
    portraitFilter: 'hue-rotate(-87deg) saturate(1.5) brightness(1.05) contrast(1.1)',
    advantages: [
      '+12% Dano',
      '+6% Roubo de Vida',
      '+5% Velocidade de ataque',
    ],
    disadvantages: [
      '-12% Vida Máxima',
      '-5% Defesa',
    ],
    idealFor: [
      'Quem gosta de atacar sem parar',
      'Quanto mais inimigos enfrenta, mais consegue recuperar vida',
    ],
    passiveName: 'Frenesi de Sangue',
    passiveDesc: 'Após eliminar um inimigo, ganha 10% de velocidade de ataque por 4s. O efeito é renovado a cada nova eliminação.',
    bonuses: {
      damageMul: 1.12,
      lifestealAdd: 0.06,
      attackSpeedMul: 1.05,
      hpMul: 0.88,
      defenseMul: 0.95,
    },
    passives: [
      '+12% Dano', '+6% Roubo de Vida', '+5% Velocidade de ataque',
      '-12% Vida Máxima', '-5% Defesa',
    ],
  },
  ghost: {
    id: 'ghost',
    name: 'FANTASMA',
    icon: '🔵',
    tagline: 'Nem toda presença pode ser tocada.',
    style: 'Ágil',
    color: '#80c0ff',
    portraitFilter: 'hue-rotate(164deg) saturate(1.25) brightness(1.15) contrast(0.95)',
    advantages: [
      '20% Chance de Esquiva',
      '+15% Velocidade de movimento',
      '+10% Velocidade de ataque',
    ],
    disadvantages: [
      '-15% Vida Máxima',
      '-15% Defesa',
    ],
    idealFor: [
      'Jogadores experientes',
      'Quem prefere desviar do dano em vez de tanká-lo',
    ],
    passiveName: 'Passo Etéreo',
    passiveDesc: 'Depois de esquivar um ataque, recebe 20% de velocidade de movimento por 2s.',
    bonuses: {
      dodgeChance: 0.20,
      moveSpeedMul: 1.15,
      attackSpeedMul: 1.10,
      hpMul: 0.85,
      defenseMul: 0.85,
    },
    passives: [
      '20% Chance de Esquiva', '+15% Velocidade de movimento', '+10% Velocidade de ataque',
      '-15% Vida Máxima', '-15% Defesa',
    ],
  },
};

// Sprite mapping (from /assets/character.png — Caçadora Cega atlas,
// frame cells 240x128, rendered on-screen at a fixed 48px height, aspect
// ratio preserved so the art never stretches/squashes).
export const SPR = {
  cellW: 113,
  cellH: 48,
  renderSize: 48, // on-screen height in px (drawPlayer scales width to match aspect ratio)
  // Ponto de ancoragem (em px, coordenadas locais da célula) que corresponde
  // ao centro do corpo / contato com o chão do personagem. Como a célula
  // precisa ser larga o bastante para caber o alcance da espada no ataque,
  // o personagem NÃO fica centralizado na célula — por isso não podemos
  // ancorar o desenho pelo centro geométrico da célula (isso causava a
  // sombra desalinhada e o "teleporte" ao virar de direção). Ancorando
  // sempre neste pivô fixo, o espelhamento (flipX) gira exatamente em
  // torno do próprio personagem.
  pivotX: 27.5,
  pivotY: 46,
  idle:    [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 2, y: 0 }, { x: 3, y: 0 }, { x: 4, y: 0 }, { x: 5, y: 0 }, { x: 6, y: 0 }, { x: 7, y: 0 }, { x: 8, y: 0 }, { x: 9, y: 0 }, { x: 10, y: 0 }, { x: 11, y: 0 }],
  walk:    [{ x: 0, y: 1 }, { x: 1, y: 1 }, { x: 2, y: 1 }, { x: 3, y: 1 }, { x: 4, y: 1 }, { x: 5, y: 1 }, { x: 6, y: 1 }, { x: 7, y: 1 }],
  attack1: [{ x: 0, y: 2 }, { x: 1, y: 2 }, { x: 2, y: 2 }],
  attack2: [{ x: 0, y: 3 }, { x: 1, y: 3 }, { x: 2, y: 3 }, { x: 3, y: 3 }, { x: 4, y: 3 }],
  dash:    [{ x: 0, y: 4 }, { x: 1, y: 4 }, { x: 2, y: 4 }, { x: 3, y: 4 }],
};

export function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
export function dist(a, b) {
  const dx = a.x - b.x, dy = a.y - b.y; return Math.hypot(dx, dy);
}
export function angle(a, b) { return Math.atan2(b.y - a.y, b.x - a.x); }
export function rand(min, max) { return Math.random() * (max - min) + min; }

// Monster spritesheets (100x100 frames, horizontal strips).
// Five distinct creature packs, one per enemy archetype below -> each monster
// now uses its own dedicated animation set instead of shared/recolored art.
export const MONSTER_SPRITES = {
  blood: {
    idle:   { src: './assets/blood_idle.png',   frames: 6 },
    walk:   { src: './assets/blood_walk.png',   frames: 8 },
    attack: { src: './assets/blood_attack.png', frames: 8 },
  },
  demon: {
    idle:   { src: './assets/demon_idle.png',   frames: 6 },
    walk:   { src: './assets/demon_walk.png',   frames: 8 },
    attack: { src: './assets/demon_attack.png', frames: 7 },
  },
  orc: {
    idle:   { src: './assets/orc_idle.png',   frames: 6 },
    walk:   { src: './assets/orc_walk.png',   frames: 8 },
    attack: { src: './assets/orc_attack.png', frames: 6 },
  },
  soldier: {
    idle:   { src: './assets/soldier_idle.png',   frames: 6 },
    walk:   { src: './assets/soldier_walk.png',   frames: 8 },
    attack: { src: './assets/soldier_attack.png', frames: 6 },
  },
  slime: {
    idle:   { src: './assets/slime_idle.png',   frames: 6 },
    walk:   { src: './assets/slime_walk.png',   frames: 12 },
    attack: { src: './assets/slime_attack.png', frames: 15 },
  },
};
export const MONSTER_CELL = 100;

// Reference: rendered player size on screen is a fixed 64px square (see
// drawPlayer). Every enemy below is sized (radius * spriteScale) to land
// between ~190% and ~265% of that, so every enemy towers over the hunter.
const PLAYER_RENDER_SIZE = 64;

// Enemy archetypes - one per uploaded monster pack, each with its own
// silhouette, behavior pattern and role in the difficulty curve.
// attackCooldown is intentionally a bit HIGHER than the player's base
// (1 / BASE.attackSpeed = 1.0s) so every physical attacker here swings
// slightly slower/rarer than the main character, as requested.
// hp/damage/defense below are HALF of the previous tuning pass, per request.
export const ENEMY_TYPES = {
  blood: {
    name: 'Aberração de Sangue',
    color: '#8a0e0e',
    eye: '#ff5050',
    radius: 20,
    hp: 35, damage: 7, defense: 3, speed: 140,
    behavior: 'chase',
    attackRange: 36,
    attackCooldown: 1.15, // slightly slower rage than the player
    sprite: 'blood',
    spriteFilter: 'hue-rotate(-6deg) saturate(1.3) brightness(1.05)',
    spriteScale: 6.0, // ~187% of player size
  },
  soldier: {
    // Body from the "Soldier" pack, reskinned dark/crimson to read as the
    // wielder of the cursed blade from Demon_sword.zip (that pack only had
    // a weapon sprite, no character, so its slash/aggressive-duelist theme
    // was applied on top of this humanoid).
    name: 'Portador da Espada Amaldiçoada',
    color: '#4a0a1a',
    eye: '#ff2050',
    radius: 21,
    hp: 43, damage: 9, defense: 4, speed: 135,
    behavior: 'charge', // dashes in for a blade strike
    attackRange: 38,
    attackCooldown: 1.08,
    sprite: 'soldier',
    spriteFilter: 'hue-rotate(300deg) saturate(1.5) brightness(0.8)',
    spriteScale: 6.2, // ~203% of player size
  },
  orc: {
    name: 'Orc Guerreiro Infernal',
    color: '#6a3a0a',
    eye: '#ffa030',
    radius: 23,
    hp: 68, damage: 11, defense: 6, speed: 95,
    behavior: 'chase',
    attackRange: 42,
    attackCooldown: 1.35,
    sprite: 'orc',
    spriteFilter: 'hue-rotate(-70deg) saturate(1.6) brightness(0.85)',
    spriteScale: 6.3, // ~226% of player size
  },
  demon: {
    name: 'Demônio Ancestral',
    color: '#2a0a1a',
    eye: '#ff60ff',
    radius: 24,
    hp: 78, damage: 12, defense: 7, speed: 100,
    behavior: 'teleport',
    attackRange: 44,
    attackCooldown: 1.3,
    sprite: 'demon',
    spriteFilter: 'hue-rotate(10deg) saturate(1.15) brightness(0.85)',
    spriteScale: 6.5, // ~243% of player size
  },
  slime: {
    // The strongest of the five - big, tanky, evasive, hits like a truck.
    name: 'Demon Slime, o Devorador',
    color: '#7a0202',
    eye: '#ff3010',
    radius: 26,
    hp: 115, damage: 15, defense: 9, speed: 85,
    behavior: 'chase',
    attackRange: 48,
    attackCooldown: 1.4,
    dodgeChance: 0.25, // 25% chance to dodge player hits
    sprite: 'slime',
    spriteFilter: 'hue-rotate(0deg) saturate(1.3) brightness(0.92)',
    spriteScale: 6.5, // ~264% of player size
  },
};

// Boss config
export const BOSS = {
  name: 'Belial, o Arquidemônio',
  color: '#2a0202',
  eye: '#ff2000',
  radius: 56,
  hp: 1800,
  damage: 28,
  speed: 70,
};

// Phase composition. Every phase always spawns exactly 3 Demon Slimes (the
// strongest archetype) plus the rest of the count filled by the other four
// archetypes, rotating so the mix stays varied phase to phase.
export const PHASE_SPAWNS = [
  { count: 6,  boss: false },  // 1
  { count: 7,  boss: false },  // 2
  { count: 8,  boss: false },  // 3
  { count: 9,  boss: false },  // 4
  { count: 10, boss: false },  // 5
  { count: 11, boss: false },  // 6
  { count: 12, boss: false },  // 7
  { count: 13, boss: false },  // 8
  { count: 14, boss: false },  // 9
  { count: 0,  boss: true  },  // 10 - boss only
];

// The 4 non-slime archetypes, cycled to fill the rest of each phase's spawns.
export const REGULAR_ENEMY_TYPES = ['blood', 'orc', 'demon', 'soldier'];
export const GUARANTEED_SLIME_COUNT = 3;

// Difficulty scaling per phase: HP, damage AND defense all grow +180% per
// phase level (linear step of 1.8x on top of the base stat), so every new
// floor is dramatically harder than the last, as requested.
export function phaseScale(phase) {
  const step = 1 + (phase - 1) * 1.8;
  return {
    hpMul: step,
    dmgMul: step,
    defMul: step,
  };
}
