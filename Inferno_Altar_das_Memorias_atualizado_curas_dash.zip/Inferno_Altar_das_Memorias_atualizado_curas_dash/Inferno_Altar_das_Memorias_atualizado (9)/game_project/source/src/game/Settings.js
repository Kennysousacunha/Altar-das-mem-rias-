// Settings system - persists audio/video/control preferences to localStorage.
// Mirrors the pattern used in Save.js.

const KEY = 'inferno_settings_v1';

export const DEFAULT_SETTINGS = {
  musicVol: 0.8,       // 0..1
  sfxVol: 0.9,          // 0..1
  screenShake: true,
  particles: true,
  quality: 'medio',     // 'baixo' | 'medio' | 'alto'
  joystickSize: 100,    // %, 60..150
  buttonSize: 100,      // %, 60..150
};

export function loadSettings() {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULT_SETTINGS };
    const data = JSON.parse(raw);
    if (!data || typeof data !== 'object') return { ...DEFAULT_SETTINGS };
    return { ...DEFAULT_SETTINGS, ...data };
  } catch (_e) {
    return { ...DEFAULT_SETTINGS };
  }
}

export function saveSettings(partial) {
  try {
    const existing = loadSettings();
    const merged = { ...existing, ...partial };
    localStorage.setItem(KEY, JSON.stringify(merged));
    return merged;
  } catch (_e) {
    return { ...DEFAULT_SETTINGS, ...partial };
  }
}

export function resetSettings() {
  try { localStorage.removeItem(KEY); } catch (_e) { /* ignore */ }
  return { ...DEFAULT_SETTINGS };
}
