// ============================================================================
// ALTAR DAS MEMÓRIAS (dados + regras)
// ----------------------------------------------------------------------------
// Sistema de progressão PERMANENTE e independente do XP/Nível já existente.
// Este arquivo só descreve a ESTRUTURA do altar (nós, tiers, custos e regras
// de desbloqueio). Os EFEITOS de cada habilidade são aplicados pela Engine
// (ver Engine.js, seção "ALTAR DAS MEMÓRIAS") através do id de cada nó.
//
// Regra de desbloqueio (genérica, igual para os 3 caminhos):
//   - Tier I   -> sempre disponível (custa 1 Fragmento).
//   - Tier II  -> exige 2 habilidades já desbloqueadas no Tier I do MESMO
//                 caminho (custa 1 Fragmento).
//   - Tier III -> exige 2 habilidades já desbloqueadas no Tier II do MESMO
//                 caminho (custa 1 Fragmento).
// ============================================================================

export const FRAGMENT_COST = 1;

// Um símbolo simples por caminho (leve, sem depender de imagens/efeitos pesados).
export const PATHS = {
  guerra: { id: 'guerra', name: 'Caminho da Guerra', symbol: '⚔', color: '#ff5028' },
  vigilia: { id: 'vigilia', name: 'Caminho da Vigília', symbol: '🛡', color: '#5aa9e6' },
  cinzas: { id: 'cinzas', name: 'Caminho das Cinzas', symbol: '🔥', color: '#ff9a3d' },
};

// Nó decorativo no topo da constelação — apenas visual, não custa Fragmento
// e não é "desbloqueável" (representa a origem comum dos três caminhos).
export const ORIGIN_NODE = { id: 'origem', name: 'Origem', symbol: '✦' };

export const SKILLS = [
  // ---------------------------------------------------------------- GUERRA --
  { id: 'impeto', path: 'guerra', tier: 1, name: 'Ímpeto', icon: '⚔',
    desc: 'Após esquivar, o próximo ataque causa +15% de dano.' },
  { id: 'execucao', path: 'guerra', tier: 1, name: 'Execução', icon: '☠',
    desc: 'Inimigos abaixo de 20% de HP recebem +20% de dano.' },
  { id: 'cacada', path: 'guerra', tier: 1, name: 'Caçada', icon: '🏃',
    desc: 'Derrotar inimigos concede +8% de velocidade por 4s.' },
  { id: 'precisao', path: 'guerra', tier: 1, name: 'Precisão', icon: '🎯',
    desc: '+5% de chance de crítico.' },
  { id: 'golpe_firme', path: 'guerra', tier: 1, name: 'Golpe Firme', icon: '🗡',
    desc: 'Reduz levemente a recuperação do Ataque Pesado (Ataque 2).' },

  { id: 'carnificina', path: 'guerra', tier: 2, name: 'Carnificina', icon: '🩸',
    desc: 'Cada inimigo morto concede +2% de dano (máx. 10%) por 10s.' },
  { id: 'quebra_guarda', path: 'guerra', tier: 2, name: 'Quebra Guarda', icon: '💥',
    desc: 'O Ataque Pesado interrompe inimigos com mais facilidade.' },
  { id: 'predador', path: 'guerra', tier: 2, name: 'Predador', icon: '🦇',
    desc: 'Rouba 7% do dano causado como vida. Funciona contra todos os inimigos, inclusive Bosses.' },
  { id: 'contra_ataque', path: 'guerra', tier: 2, name: 'Contra Ataque', icon: '⚡',
    desc: 'Após uma esquiva perfeita, o próximo ataque causa +30% de dano.' },

  { id: 'avatar_guerra', path: 'guerra', tier: 3, name: 'Avatar da Guerra', icon: '👹',
    desc: 'Ao eliminar 5 inimigos consecutivos, ganha por 8s: +20% dano, +15% velocidade e Roubo de Vida em 15%.' },

  // --------------------------------------------------------------- VIGÍLIA --
  { id: 'pele_ferro', path: 'vigilia', tier: 1, name: 'Pele de Ferro', icon: '🛡',
    desc: '-8% de dano recebido.' },
  { id: 'passo_seguro', path: 'vigilia', tier: 1, name: 'Passo Seguro', icon: '👣',
    desc: 'A esquiva percorre uma distância maior.' },
  { id: 'determinacao', path: 'vigilia', tier: 1, name: 'Determinação', icon: '✦',
    desc: 'Ao concluir a fase sem morrer, recupera uma pequena quantidade de HP.' },
  { id: 'disciplina', path: 'vigilia', tier: 1, name: 'Disciplina', icon: '⏳',
    desc: 'A janela de invulnerabilidade da esquiva aumenta levemente.' },
  { id: 'folego', path: 'vigilia', tier: 1, name: 'Fôlego', icon: '💨',
    desc: 'A recuperação após sofrer dano é mais rápida.' },

  { id: 'guardiao', path: 'vigilia', tier: 2, name: 'Guardião', icon: '🔰',
    desc: 'Receber dano cria um pequeno escudo (dura 3s, recarga de 20s).' },
  { id: 'ultimo_folego', path: 'vigilia', tier: 2, name: 'Último Fôlego', icon: '🕊',
    desc: 'Sobrevive automaticamente a um golpe fatal, permanecendo com 1 HP. Uma vez por fase.' },
  { id: 'muralha', path: 'vigilia', tier: 2, name: 'Muralha', icon: '🧱',
    desc: 'Após uma esquiva perfeita, o próximo ataque causa +20% de dano.' },
  { id: 'resistencia', path: 'vigilia', tier: 2, name: 'Resistência', icon: '🦶',
    desc: 'Receber dano é seguido por um breve alívio na movimentação.' },

  { id: 'inquebravel', path: 'vigilia', tier: 3, name: 'Inquebrável', icon: '💠',
    desc: 'Ao cair abaixo de 30% de HP, torna-se brevemente mais resistente (recarga de 30s).' },

  // ---------------------------------------------------------------- CINZAS --
  { id: 'brasa', path: 'cinzas', tier: 1, name: 'Brasa', icon: '🔥',
    desc: '20% de chance de aplicar queimadura a cada acerto.' },
  { id: 'cinzas', path: 'cinzas', tier: 1, name: 'Cinzas', icon: '💨',
    desc: 'Inimigos queimando sofrem -10% de velocidade.' },
  { id: 'labareda', path: 'cinzas', tier: 1, name: 'Labareda', icon: '🔥',
    desc: 'Esquivar deixa um pequeno rastro de fogo.' },
  { id: 'fornalha', path: 'cinzas', tier: 1, name: 'Fornalha', icon: '⏱',
    desc: 'A queimadura dura mais tempo.' },
  { id: 'faisca', path: 'cinzas', tier: 1, name: 'Faísca', icon: '✨',
    desc: 'Ataques contra inimigos queimando causam +10% de dano.' },

  { id: 'incinerar', path: 'cinzas', tier: 2, name: 'Incinerar', icon: '💥',
    desc: 'Inimigos queimando explodem ao morrer.' },
  { id: 'inferno_interior', path: 'cinzas', tier: 2, name: 'Inferno Interior', icon: '❤️‍🔥',
    desc: 'Quanto menor o seu HP, maior o dano de fogo (máx. 15%).' },
  { id: 'combustao', path: 'cinzas', tier: 2, name: 'Combustão', icon: '🔥',
    desc: 'Ataques consecutivos no mesmo alvo aumentam a chance de queimadura.' },
  { id: 'explosao_infernal', path: 'cinzas', tier: 2, name: 'Explosão Infernal', icon: '☄',
    desc: 'As explosões de fogo possuem um alcance um pouco maior.' },

  { id: 'coracao_inferno', path: 'cinzas', tier: 3, name: 'Coração do Inferno', icon: '❤️‍🔥',
    desc: 'Ataques contra inimigos queimando causam pequenas explosões.' },
];

export const SKILLS_BY_ID = Object.fromEntries(SKILLS.map((s) => [s.id, s]));

export function skillsForPath(pathId) {
  return SKILLS.filter((s) => s.path === pathId);
}

export function skillsForPathTier(pathId, tier) {
  return SKILLS.filter((s) => s.path === pathId && s.tier === tier);
}

// unlockedIds: Set<string> ou Array<string>
export function canUnlock(skill, unlockedIds) {
  const unlocked = unlockedIds instanceof Set ? unlockedIds : new Set(unlockedIds || []);
  if (!skill) return false;
  if (unlocked.has(skill.id)) return false;
  if (skill.tier === 1) return true;
  const prevTier = skill.tier - 1;
  const count = SKILLS.filter((s) => s.path === skill.path && s.tier === prevTier && unlocked.has(s.id)).length;
  return count >= 2;
}

export function isUnlocked(skillId, unlockedIds) {
  const unlocked = unlockedIds instanceof Set ? unlockedIds : new Set(unlockedIds || []);
  return unlocked.has(skillId);
}
