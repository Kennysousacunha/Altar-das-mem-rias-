// Core engine for "INFERNO" - top-down action roguelite with roguelike dungeons.
// Larger world (WORLD_W x WORLD_H) rendered through a camera that follows the player.
// Dungeon is generated with rectangular rooms connected by L-shaped corridors.
// Everything outside floor tiles is lava (impassable). Rooms are decorated with braziers.
import {
  W, H, WORLD_W, WORLD_H, TILE, PHASES, BASE, LEVEL_BONUS, SPR,
  ENEMY_TYPES, BOSS, PHASE_SPAWNS, phaseScale, CLASSES,
  MONSTER_SPRITES, MONSTER_CELL, REGULAR_ENEMY_TYPES, GUARANTEED_SLIME_COUNT,
  FLASK_MAX_START, FLASK_HEAL_PCT,
  clamp, dist, angle, rand,
} from './config.js';
import { MAP_TEMPLATES } from './mapTemplates.js';
import { audio } from './AudioManager.js';
import { saveProgress, clearCurrentSave, getDeathCount, bumpDeathCount } from './Save.js';

// Camera zoom – 2 means "everything appears 2× bigger" (player fills more of the screen)
const ZOOM = 2;

// 10 infernal dungeon themes – one per floor. Each defines the pixel-art palette
// and procedural decorations drawn on floor/wall tiles.
const DUNGEON_THEMES = [
  { // 1 – Entrada do Inferno: blood-red stone
    name: 'Entrada do Inferno',
    wallColor: '#1a0808', wallMid: '#2d1010', wallAcc: '#450f0f',
    floorColor: '#1e0e0e', floorMid: '#2a1212', floorAcc: '#3d1a1a',
    lavaColor: '#8b1a00', lavaHot: '#ff4400', cracks: true, runes: false, skulls: false, chains: true,
  },
  { // 2 – Catacumbas Ossificadas: bone/ash
    name: 'Catacumbas Ossificadas',
    wallColor: '#1c1410', wallMid: '#2e2018', wallAcc: '#3d2a1a',
    floorColor: '#181210', floorMid: '#221a14', floorAcc: '#2e2018',
    lavaColor: '#7a1500', lavaHot: '#ee3300', cracks: true, runes: false, skulls: true, chains: false,
  },
  { // 3 – Forjas do Pecado: molten iron
    name: 'Forjas do Pecado',
    wallColor: '#1a1108', wallMid: '#2e1e0a', wallAcc: '#3d2808',
    floorColor: '#14100a', floorMid: '#1e1810', floorAcc: '#2a1e10',
    lavaColor: '#aa3d00', lavaHot: '#ff7700', cracks: false, runes: false, skulls: false, chains: true,
  },
  { // 4 – Câmaras do Esquecimento: deep void purple
    name: 'Câmaras do Esquecimento',
    wallColor: '#0d0814', wallMid: '#1a1022', wallAcc: '#261630',
    floorColor: '#0a070f', floorMid: '#14101e', floorAcc: '#1e1830',
    lavaColor: '#4a0060', lavaHot: '#cc00ff', cracks: false, runes: true, skulls: false, chains: false,
  },
  { // 5 – Labirinto de Espinhos: dark thorn-green
    name: 'Labirinto de Espinhos',
    wallColor: '#071408', wallMid: '#0e2010', wallAcc: '#162814',
    floorColor: '#050e06', floorMid: '#0a160a', floorAcc: '#121c10',
    lavaColor: '#1a4a00', lavaHot: '#66ff00', cracks: true, runes: false, skulls: true, chains: false,
  },
  { // 6 – Abismo de Gelo: freezing blue-black
    name: 'Abismo de Gelo',
    wallColor: '#080f18', wallMid: '#0f1e30', wallAcc: '#142840',
    floorColor: '#060c14', floorMid: '#0c1820', floorAcc: '#12222e',
    lavaColor: '#002050', lavaHot: '#0088ff', cracks: true, runes: false, skulls: false, chains: true,
  },
  { // 7 – Torre dos Demônios: charcoal + blood veins
    name: 'Torre dos Demônios',
    wallColor: '#12080a', wallMid: '#1e0e10', wallAcc: '#2a1216',
    floorColor: '#0e0608', floorMid: '#180c0e', floorAcc: '#22101a',
    lavaColor: '#700010', lavaHot: '#ff2244', cracks: false, runes: true, skulls: true, chains: true,
  },
  { // 8 – Cripta da Traição: poison gold
    name: 'Cripta da Traição',
    wallColor: '#0f1208', wallMid: '#1c1e0a', wallAcc: '#28280e',
    floorColor: '#0c0e06', floorMid: '#161808', floorAcc: '#20200c',
    lavaColor: '#3a4a00', lavaHot: '#cccc00', cracks: true, runes: true, skulls: false, chains: false,
  },
  { // 9 – Câmaras Finais: deepest crimson
    name: 'Câmaras Finais',
    wallColor: '#1a0404', wallMid: '#2e0808', wallAcc: '#440c0c',
    floorColor: '#120404', floorMid: '#200808', floorAcc: '#300a0a',
    lavaColor: '#990000', lavaHot: '#ff0000', cracks: true, runes: true, skulls: true, chains: true,
  },
  { // 10 – Arena de Belial: obsidian black + hellfire
    name: 'Arena de Belial',
    wallColor: '#0a0a0a', wallMid: '#141414', wallAcc: '#1e1e1e',
    floorColor: '#080808', floorMid: '#101010', floorAcc: '#181818',
    lavaColor: '#aa2200', lavaHot: '#ff5500', cracks: true, runes: true, skulls: true, chains: true,
  },
];

export class Engine {
  constructor(opts = {}) {
    this.onPhaseClear = opts.onPhaseClear || (() => {});
    this.onDeath = opts.onDeath || (() => {});
    this.onVictory = opts.onVictory || (() => {});
    this.onMeetNpc = opts.onMeetNpc || (() => {});
    this.onUiUpdate = opts.onUiUpdate || (() => {});
    // Configurações de Vídeo (tela de CONFIGURAÇÕES) — tremor de tela, partículas
    // e qualidade. updateSettings() é chamado sempre que o jogador muda algo.
    this.settings = { screenShake: true, particles: true, quality: 'medio', ...opts.settings };
    this.spriteImg = null;
    this.floorTexture = null;
    this.lavaTexture = null;
    this._floorPattern = null;
    this._lavaPattern = null;
    this.walls = [];
    this.monsterSprites = {}; // { blood: {idle,walk,attack}, demon: {idle,walk,attack} }
    // --- Perf caches (fixes stutter/lag) ---
    // Recolored monster spritesheets baked once per (enemyType, anim) instead of
    // running an expensive ctx.filter (hue-rotate/saturate/brightness) on every
    // enemy, every frame, which was the single biggest source of frame drops
    // once several enemies were on screen at once.
    this.bakedMonsterSprites = {};
    // Floor/lava edge overlay (erosion + glow) is fully static per dungeon layout,
    // so it's rendered once to an offscreen canvas instead of being recomputed
    // (with fresh gradients + composite-mode switches) on every single frame.
    this._floorEdgeCache = null;
    // Brazier glow used to call ctx.createRadialGradient() per brazier per frame;
    // now it's a single baked sprite that's just drawImage'd (with a size tweak
    // for the flicker), which is drastically cheaper.
    this._brazierGlowSprite = null;
    this.buildBrazierGlowSprite();
    // Vinheta de tela (escurece levemente os cantos) — dá profundidade e clima
    // de masmorra sem custar nada por frame (é um único drawImage já pronto).
    this._vignetteSprite = null;
    this.buildVignetteSprite();
    // Luz ambiente que acompanha o jogador — um brilho suave e quente que
    // "empurra" um pouco a escuridão ao redor dele, como se carregasse uma
    // fonte de luz. Também é um sprite pronto, então não custa nada extra.
    this._playerGlowSprite = null;
    this.buildPlayerGlowSprite();
    // Contador de mortes (apenas narrativo — não altera nenhuma mecânica).
    this.totalDeaths = getDeathCount();
    this.reset();
  }

  bindSprite(img) { this.spriteImg = img; }
  bindFloorTexture(img) { this.floorTexture = img; this._floorPattern = null; }
  bindLavaTexture(img) { this.lavaTexture = img; this._lavaPattern = null; }
  // NPC introdutório do andar 1: spritesheet 6 quadros (360x60, 60x60 por
  // célula) com a animação de "bebendo", virada de frente (south) — usada
  // no lugar do desenho vetorial antigo para uma aparência fluída e animada.
  bindNpcIntroSprite(img) { this.npcIntroSprite = img; }
  bindMonsterSprite(key, anim, img) {
    if (!this.monsterSprites[key]) this.monsterSprites[key] = {};
    this.monsterSprites[key][anim] = img;
  }

  updateSettings(partial) {
    this.settings = { ...this.settings, ...partial };
  }

  // Ponto único por onde toda partícula passa — respeita o toggle "Partículas" da
  // tela de Configurações sem precisar alterar as dezenas de pontos que criam efeitos.
  spawnParticle(p) {
    if (!this.settings.particles) return;
    this.particles.push(p);
  }

  // Bakes a small radial-gradient sprite once so drawBraziers() never has to call
  // ctx.createRadialGradient() (a surprisingly costly op) on every brazier, every frame.
  buildBrazierGlowSprite() {
    const size = 144;
    const c = document.createElement('canvas');
    c.width = size; c.height = size;
    const gctx = c.getContext('2d');
    const grad = gctx.createRadialGradient(size / 2, size / 2, 4, size / 2, size / 2, size / 2);
    grad.addColorStop(0, 'rgba(255, 195, 90, 0.68)');
    grad.addColorStop(0.55, 'rgba(255, 140, 40, 0.30)');
    grad.addColorStop(1, 'rgba(255, 100, 20, 0)');
    gctx.fillStyle = grad;
    gctx.fillRect(0, 0, size, size);
    this._brazierGlowSprite = c;
  }

  // Vinheta de tela: escurece suavemente os cantos/bordas pra dar profundidade
  // e clima de masmorra, sem precisar recalcular gradiente nenhum por frame.
  buildVignetteSprite() {
    const c = document.createElement('canvas');
    c.width = W; c.height = H;
    const gctx = c.getContext('2d');
    const cx = W / 2, cy = H / 2;
    const outerR = Math.hypot(cx, cy);
    const grad = gctx.createRadialGradient(cx, cy, outerR * 0.42, cx, cy, outerR);
    grad.addColorStop(0, 'rgba(0, 0, 0, 0)');
    grad.addColorStop(1, 'rgba(0, 0, 0, 0.5)');
    gctx.fillStyle = grad;
    gctx.fillRect(0, 0, W, H);
    this._vignetteSprite = c;
  }

  // Luz ambiente suave e quente ao redor do jogador (soma com o fundo via
  // "lighter"), pra dar a sensação de que ele carrega uma fonte de luz.
  buildPlayerGlowSprite() {
    const size = 220;
    const c = document.createElement('canvas');
    c.width = size; c.height = size;
    const gctx = c.getContext('2d');
    const grad = gctx.createRadialGradient(size / 2, size / 2, 8, size / 2, size / 2, size / 2);
    grad.addColorStop(0, 'rgba(255, 235, 195, 0.22)');
    grad.addColorStop(0.6, 'rgba(255, 200, 140, 0.10)');
    grad.addColorStop(1, 'rgba(255, 160, 100, 0)');
    gctx.fillStyle = grad;
    gctx.fillRect(0, 0, size, size);
    this._playerGlowSprite = c;
  }

  // Bakes a recolored copy of a monster's spritesheet (idle/walk/attack) for a given
  // enemy type once, using an offscreen canvas + ctx.filter a single time, so the
  // per-frame draw call no longer needs ctx.filter at all (canvas 2D filters are
  // expensive, especially compound ones like hue-rotate+saturate+brightness, and
  // were being applied to every visible enemy on every single frame).
  bakeMonsterFrame(e, anim, sprites) {
    const key = `${e.type}_${anim}`;
    const cached = this.bakedMonsterSprites[key];
    if (cached) return cached;
    const img = sprites[anim];
    if (!img || !img.width) return null;
    const c = document.createElement('canvas');
    c.width = img.width; c.height = img.height;
    const bctx = c.getContext('2d');
    if (e.spriteFilter) bctx.filter = e.spriteFilter;
    bctx.drawImage(img, 0, 0);
    this.bakedMonsterSprites[key] = c;
    return c;
  }

  // Renders the floor/lava erosion + glow overlay for the WHOLE current map to an
  // offscreen canvas a single time (right after the dungeon layout is generated).
  // Per-frame rendering then becomes one drawImage() call instead of hundreds of
  // arc()/gradient() calls with globalCompositeOperation switches every frame.
  // buildFloorEdgeCache is superseded by the new per-tile pixel-art renderer.
  // Kept as a no-op so call sites don't break.
  buildFloorEdgeCache() {
    this._floorEdgeCache = null; // no-op: new tile renderer draws edges inline
  }

  reset(classId = 'vampire') {
    const cls = CLASSES[classId] || CLASSES.vampire;
    const b = cls.bonuses || {};
    const hpMax = Math.round(BASE.hp * (b.hpMul || 1));

    this.player = {
      x: WORLD_W / 2, y: WORLD_H / 2, r: 16,
      facing: 0, moving: false,
      animTime: 0, animFrame: 0,
      attackAnim: 0, flipX: false,

      classId: cls.id,
      classColor: cls.color,
      className: cls.name,
      dodgeChance: b.dodgeChance || 0,
      regenPerSec: b.regenPerSec || 0,

      // Unique triggered passives (one per class, see damagePlayer/killEnemy/updatePlayer).
      resistTimer: 0,   // undead: Resistência Inabalável active duration
      resistCd: 0,      // undead: Resistência Inabalável cooldown
      frenzyTimer: 0,   // vampire: Frenesi de Sangue active duration
      etherealTimer: 0, // ghost: Passo Etéreo active duration

      hp: hpMax, hpMax,
      damage: BASE.damage * (b.damageMul || 1),
      attackSpeed: BASE.attackSpeed * (b.attackSpeedMul || 1),
      defense: BASE.defense * (b.defenseMul || 1),
      lifesteal: BASE.lifesteal + (b.lifestealAdd || 0),
      moveSpeed: BASE.moveSpeed * (b.moveSpeedMul || 1),
      attackRange: BASE.attackRange,

      attackCooldown: 0,
      attack2Cooldown: 0,
      attack2Anim: 0,
      kills: 0,
      level: 1,

      invulnTime: 0, invulnCd: 0,

      // Esquiva: dash rápido na direção do analógico (ou para trás, se o
      // analógico estiver neutro), com pequena invencibilidade embutida.
      dashTime: 0, dashCd: 0,
      dashDirX: -1, dashDirY: 0,

      // Essência Remanescente (cura): frascos consumíveis que restauram HP.
      flasks: FLASK_MAX_START,

      hurtFlash: 0,
      dead: false,

      // ---- ALTAR DAS MEMÓRIAS: estado transiente por corrida (não persiste
      // nem afeta o jogador caso nenhuma habilidade esteja desbloqueada) ----
      memAtkBonus: 0,        // bônus % aplicado ao PRÓXIMO ataque (Ímpeto/Contra Ataque/Muralha)
      memKillStreak: 0,      // Avatar da Guerra: abates consecutivos
      memAvatarTimer: 0,     // Avatar da Guerra: janela ativa
      memCarnificinaStack: 0,
      memCarnificinaTimer: 0,
      memHuntTimer: 0,       // Caçada: bônus de velocidade após abate
      memShieldHp: 0,        // Guardião: escudo atual
      memShieldTimer: 0,
      memGuardCd: 0,
      memLastBreathUsed: false, // Último Fôlego: 1x por fase
      memRegenBoostTimer: 0, // Fôlego: recuperação acelerada após dano
      memResistTimer: 0,     // Resistência: alívio de movimento após dano
      memUnbreakableTimer: 0, // Inquebrável: janela ativa
      memUnbreakableCd: 0,
      memHitStreakTarget: null, // Combustão: alvo do último acerto
      memHitStreakCount: 0,
    };

    this.enemies = [];
    this.projectiles = [];
    this.particles = [];
    this.floatTexts = [];
    this.npcs = [];
    this.portal = null; // portal narrativo para o próximo andar (surge após limpar a fase)
    this.walls = [];
    this.rooms = [];
    this.braziers = [];
    this.tileGrid = null;
    this.mapCols = 0;
    this.mapRows = 0;
    this.camera = { x: 0, y: 0 };
    this.phase = 1;
    this.phaseTime = 0;
    this.cleared = false;
    this.bossSpawned = false;
    this.bossBannerTime = 0;
    this.shake = 0;
    this.input = { up:false, down:false, left:false, right:false, attack:false, attack2:false, skill1:false, interact:false };

    // ===== ALTAR DAS MEMÓRIAS =====
    // Conjunto de ids de habilidades desbloqueadas na Altar das Memórias
    // (ver MemoryTree.js / MemorySave.js), setado de fora via setMemoryBuild()
    // e consultado pelos hooks de combate abaixo. Sem nenhuma habilidade
    // desbloqueada, o jogo se comporta EXATAMENTE como antes.
    if (!this.memory) this.memory = new Set();
    this.resetMemoryRuntimeState();

    this.startPhase(1);
    this.emitUi();
  }

  emitUi() {
    const p = this.player;
    this.onUiUpdate({
      hp: p.hp, hpMax: p.hpMax,
      damage: p.damage, attackSpeed: p.attackSpeed,
      defense: p.defense, lifesteal: p.lifesteal,
      level: p.level, kills: p.kills,
      phase: this.phase,
      classId: p.classId, classColor: p.classColor, className: p.className,
      dodgeChance: p.dodgeChance,
      invulnCd: p.invulnCd, invulnTime: p.invulnTime,
      attack2Cooldown: p.attack2Cooldown,
      dashCd: p.dashCd, dashTime: p.dashTime,
      flasks: p.flasks, flasksMax: FLASK_MAX_START,
      enemiesLeft: this.enemies.length,
      bossSpawned: this.bossSpawned,
      cleared: this.cleared,
      dead: p.dead,
      mapName: this.mapName || '',
      totalDeaths: this.totalDeaths || 0,
      portalOpen: !!this.portal,
    });
  }

  // ===== PHASE / MAP =====
  startPhase(n) {
    this.phase = n;
    this.phaseTime = 0;
    this.cleared = false;
    this.bossSpawned = false;
    this.enemies = [];
    this.projectiles = [];
    this.particles = [];
    this.floatTexts = [];
    this.npcs = [];
    this.walls = [];
    this.rooms = [];
    this.braziers = [];
    this.portal = null;
    // Reseta os efeitos "1x por fase" da Altar das Memórias (ex.: Último
    // Fôlego), sem tocar na build desbloqueada em si.
    if (this.player) this.player.memLastBreathUsed = false;
    // Andar 1: o corredor inicial não tem inimigos até o jogador falar com o
    // NPC introdutório — introLocked trava checkClear() nesse meio-tempo (senão
    // "0 inimigos" contaria como andar limpo antes mesmo dos inimigos existirem).
    this.introLocked = n === 1;
    this._pendingSpawn = null;

    // generate map
    if (n === 10) this.generateBossArena();
    else this.generateDungeon(n);

    // Place player in the first (spawn) room center
    const spawnRoom = this.rooms[0];
    if (spawnRoom) {
      this.player.x = (spawnRoom.x + spawnRoom.w / 2) * TILE;
      this.player.y = (spawnRoom.y + spawnRoom.h / 2) * TILE;
    } else {
      const sp = this.findOpenSpawn(WORLD_W * 0.5, WORLD_H * 0.5, this.player.r + 2);
      this.player.x = sp.x; this.player.y = sp.y;
    }
    this.updateCamera(true);

    if (this.introLocked) {
      // Guarda a configuração de spawn para liberar depois que o jogador
      // terminar a conversa com o NPC (ver releaseIntroEnemies()).
      this._pendingSpawn = n;
    } else {
      this.spawnPhaseEnemies(n);
    }

    // Andar 1: NPC introdutório (Sobrevivente), posicionado perto do próprio
    // personagem principal, na mesma sala de spawn (deslocado o suficiente
    // para não sobrepor o jogador, mas visível e alcançável de imediato).
    if (n === 1 && spawnRoom) {
      const offX = Math.max(1, Math.min(3, Math.floor(spawnRoom.w / 4)));
      const offY = Math.max(1, Math.min(2, Math.floor(spawnRoom.h / 4)));
      this.npcs.push({
        x: (spawnRoom.x + spawnRoom.w / 2 + offX) * TILE,
        y: (spawnRoom.y + spawnRoom.h / 2 + offY) * TILE,
        r: 18, name: 'Sobrevivente', id: 'intro', interacted: false, bobT: 0,
      });
    }
    if (n === 2 && this.rooms.length > 1) {
      const npcRoom = this.rooms[Math.min(1, this.rooms.length - 1)];
      const np = {
        x: (npcRoom.x + npcRoom.w / 2) * TILE,
        y: (npcRoom.y + npcRoom.h / 2) * TILE,
      };
      this.npcs.push({ x: np.x, y: np.y, r: 18, name: 'Alma Perdida', id: 'floor2', interacted: false, bobT: 0 });
    }

    this.emitUi();
  }

  // Executa o loop de spawn de uma fase (extraído de startPhase para poder ser
  // chamado imediatamente nas fases normais ou adiado no andar 1, ver acima).
  spawnPhaseEnemies(n) {
    const spawnCfg = PHASE_SPAWNS[n - 1];
    if (spawnCfg.boss) {
      this.spawnBoss();
      this.bossSpawned = true;
      this.bossBannerTime = 3;
      audio.play('boss');
    } else {
      const scale = phaseScale(n);
      // Always guarantee GUARANTEED_SLIME_COUNT Demon Slimes (strongest
      // archetype) per phase, then fill the rest of the phase's enemy count
      // by rotating through the other 4 archetypes for variety.
      const slimeCount = Math.min(GUARANTEED_SLIME_COUNT, spawnCfg.count);
      const restCount = spawnCfg.count - slimeCount;
      const rotationOffset = (n - 1) % REGULAR_ENEMY_TYPES.length;
      for (let i = 0; i < slimeCount; i++) this.spawnEnemy('slime', scale);
      for (let i = 0; i < restCount; i++) {
        const type = REGULAR_ENEMY_TYPES[(i + rotationOffset) % REGULAR_ENEMY_TYPES.length];
        this.spawnEnemy(type, scale);
      }
    }
  }

  // Chamado pela UI quando o jogador termina o diálogo com o NPC introdutório
  // do andar 1 — só então os demônios daquele andar realmente aparecem.
  releaseIntroEnemies() {
    if (!this.introLocked) return;
    this.introLocked = false;
    if (this._pendingSpawn != null) {
      this.spawnPhaseEnemies(this._pendingSpawn);
      this._pendingSpawn = null;
    }
    this.emitUi();
  }


  // Roguelike dungeon: place N non-overlapping rooms and connect them with L-corridors.
  // Everything that is not a floor tile is treated as lava/wall.
  // Roguelike dungeon: pick one of the 10 hand-designed infernal layouts ("models")
  // and decode it into the live tile grid. Floor N uses model N (cycling if there
  // are ever more floors than models). Everything that is not a floor tile is lava/wall.
  generateDungeon(phase) {
    const template = MAP_TEMPLATES[(phase - 1) % MAP_TEMPLATES.length];
    const rows = template.rows;
    const cols = rows[0].length;
    const grid = rows.map(row => {
      const arr = new Array(cols);
      for (let x = 0; x < cols; x++) arr[x] = row.charCodeAt(x) === 46 /* '.' */ ? 1 : 0;
      return arr;
    });

    // Clone room rects from the template and reorder so index 0 = spawn room and
    // index 1 = NPC room, matching what reset()/floor-2-NPC logic expects.
    let rooms = template.rooms.map(r => ({ ...r }));
    const spawnIdx = template.spawnRoomIdx ?? 0;
    const npcIdx = template.npcRoomIdx ?? Math.min(1, rooms.length - 1);
    const ordered = [rooms[spawnIdx]];
    if (npcIdx !== spawnIdx) ordered.push(rooms[npcIdx]);
    for (let i = 0; i < rooms.length; i++) {
      if (i !== spawnIdx && i !== npcIdx) ordered.push(rooms[i]);
    }
    rooms = ordered;

    // Build a collision "wall" list from lava tiles (merged into horizontal runs per row)
    this.walls = [];
    const used = Array.from({ length: rows.length }, () => Array(cols).fill(false));
    for (let r = 0; r < rows.length; r++) {
      for (let c = 0; c < cols; c++) {
        if (grid[r][c] === 0 && !used[r][c]) {
          let len = 1;
          while (c + len < cols && grid[r][c + len] === 0 && !used[r][c + len]) len++;
          for (let k = 0; k < len; k++) used[r][c + k] = true;
          this.walls.push({ x: c * TILE, y: r * TILE, w: len * TILE, h: TILE });
        }
      }
    }

    this.tileGrid = grid;
    this.mapCols = cols;
    this.mapRows = rows.length;
    this.rooms = rooms;
    this.mapName = template.name;
    this.theme = DUNGEON_THEMES[(phase - 1) % DUNGEON_THEMES.length];
    this._floorEdgeCache = null; // invalidate baked edge cache for new theme
    this.buildFloorEdgeCache();

    // Decorative braziers: 2-4 per room, placed on random inner floor tiles
    this.braziers = [];
    for (const room of rooms) {
      const n = 2 + Math.floor(Math.random() * 3);
      for (let i = 0; i < n; i++) {
        const bx = room.x + 1 + Math.floor(Math.random() * Math.max(1, room.w - 2));
        const by = room.y + 1 + Math.floor(Math.random() * Math.max(1, room.h - 2));
        this.braziers.push({
          x: bx * TILE + TILE / 2,
          y: by * TILE + TILE / 2,
          t: Math.random() * 10,
        });
      }
    }
  }

  generateBossArena() {
    // A single huge circular-feeling arena carved into a WORLD-sized floor.
    const cols = Math.floor(WORLD_W / TILE);
    const rows = Math.floor(WORLD_H / TILE);
    const grid = Array.from({ length: rows }, () => Array(cols).fill(0));

    const room = { x: 4, y: 3, w: cols - 8, h: rows - 6 };
    room.cx = room.x + Math.floor(room.w / 2);
    room.cy = room.y + Math.floor(room.h / 2);
    // Carve arena (skip 4 corners to give a round feel)
    for (let ry = room.y; ry < room.y + room.h; ry++) {
      for (let rx = room.x; rx < room.x + room.w; rx++) {
        const dx = rx - room.cx, dy = ry - room.cy;
        const rx2 = (dx * dx) / ((room.w / 2) * (room.w / 2));
        const ry2 = (dy * dy) / ((room.h / 2) * (room.h / 2));
        if (rx2 + ry2 <= 1) grid[ry][rx] = 1;
      }
    }
    // Merge lava tiles into walls
    this.walls = [];
    const used = Array.from({ length: rows }, () => Array(cols).fill(false));
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (grid[r][c] === 0 && !used[r][c]) {
          let len = 1;
          while (c + len < cols && grid[r][c + len] === 0 && !used[r][c + len]) len++;
          for (let k = 0; k < len; k++) used[r][c + k] = true;
          this.walls.push({ x: c * TILE, y: r * TILE, w: len * TILE, h: TILE });
        }
      }
    }
    this.tileGrid = grid;
    this.mapCols = cols;
    this.mapRows = rows;
    this.rooms = [room];
    this.mapName = 'Arena de Belial';
    this.theme = DUNGEON_THEMES[9];
    this._floorEdgeCache = null;
    this.buildFloorEdgeCache();
    // Braziers around the arena's perimeter
    this.braziers = [];
    const bN = 12;
    for (let i = 0; i < bN; i++) {
      const a = (i / bN) * Math.PI * 2;
      const bx = room.cx + Math.cos(a) * (room.w / 2 - 3);
      const by = room.cy + Math.sin(a) * (room.h / 2 - 3);
      this.braziers.push({ x: bx * TILE + TILE / 2, y: by * TILE + TILE / 2, t: Math.random() * 10 });
    }
  }

  // Find open position near (cx, cy) using spiral
  findOpenSpawn(cx, cy, r = 18) {
    if (!this.collideCircleWithWalls(cx, cy, r)) return { x: cx, y: cy };
    for (let radius = 30; radius < 900; radius += 30) {
      for (let a = 0; a < Math.PI * 2; a += Math.PI / 12) {
        const x = cx + Math.cos(a) * radius;
        const y = cy + Math.sin(a) * radius;
        if (x < 30 || x > WORLD_W - 30 || y < 30 || y > WORLD_H - 30) continue;
        if (!this.collideCircleWithWalls(x, y, r)) return { x, y };
      }
    }
    return { x: cx, y: cy };
  }

  collideCircleWithWalls(cx, cy, r) {
    for (const w of this.walls) {
      const nx = Math.max(w.x, Math.min(cx, w.x + w.w));
      const ny = Math.max(w.y, Math.min(cy, w.y + w.h));
      const dx = cx - nx, dy = cy - ny;
      if (dx * dx + dy * dy < r * r) return w;
    }
    return null;
  }

  moveWithCollision(entity, dx, dy, r) {
    entity.x += dx;
    let hit = this.collideCircleWithWalls(entity.x, entity.y, r);
    if (hit) {
      if (dx > 0) entity.x = hit.x - r - 0.5;
      else if (dx < 0) entity.x = hit.x + hit.w + r + 0.5;
    }
    entity.y += dy;
    hit = this.collideCircleWithWalls(entity.x, entity.y, r);
    if (hit) {
      if (dy > 0) entity.y = hit.y - r - 0.5;
      else if (dy < 0) entity.y = hit.y + hit.h + r + 0.5;
    }
  }

  // Camera follows player, clamped to world bounds
  updateCamera(snap = false) {
    const p = this.player;
    // With ZOOM applied, the visible area is W/ZOOM × H/ZOOM in world units,
    // so we centre the camera on the player within those reduced bounds.
    const vw = W / ZOOM, vh = H / ZOOM;
    const tx = clamp(p.x - vw / 2, 0, Math.max(0, WORLD_W - vw));
    const ty = clamp(p.y - vh / 2, 0, Math.max(0, WORLD_H - vh));
    if (snap) { this.camera.x = tx; this.camera.y = ty; }
    else {
      this.camera.x += (tx - this.camera.x) * 0.15;
      this.camera.y += (ty - this.camera.y) * 0.15;
    }
  }

  // Pick a random floor tile position in a random room, avoiding player proximity
  randomRoomPos(minDistFromPlayer = 260) {
    const p = this.player;
    for (let tries = 0; tries < 60; tries++) {
      const room = this.rooms[Math.floor(Math.random() * this.rooms.length)];
      if (!room) break;
      const rx = room.x + 1 + Math.floor(Math.random() * Math.max(1, room.w - 2));
      const ry = room.y + 1 + Math.floor(Math.random() * Math.max(1, room.h - 2));
      const x = rx * TILE + TILE / 2;
      const y = ry * TILE + TILE / 2;
      if (dist({ x, y }, p) < minDistFromPlayer) continue;
      if (this.collideCircleWithWalls(x, y, 18)) continue;
      return { x, y };
    }
    return this.findOpenSpawn(rand(60, WORLD_W - 60), rand(60, WORLD_H - 60), 18);
  }

  // ===== SPAWN =====
  spawnEnemy(typeKey, scale) {
    const t = ENEMY_TYPES[typeKey];
    const pos = this.randomRoomPos(280);
    this.enemies.push({
      type: typeKey, ...t,
      x: pos.x, y: pos.y,
      hp: Math.round(t.hp * scale.hpMul),
      hpMax: Math.round(t.hp * scale.hpMul),
      damage: t.damage * scale.dmgMul,
      defense: (t.defense || 0) * scale.defMul,
      dodgeChance: t.dodgeChance || 0,
      atkTimer: rand(0, t.attackCooldown),
      stateTimer: 0,
      stateData: {},
      animT: Math.random() * 10,
      moving: false,
      attackAnim: 0,
      facing: 1,
    });
  }

  spawnBoss() {
    const scale = phaseScale(10);
    const room = this.rooms[0] || { cx: this.mapCols / 2, cy: this.mapRows / 2 };
    const bp = this.findOpenSpawn(room.cx * TILE + 260, room.cy * TILE, BOSS.radius);
    this.enemies.push({
      type: 'boss', isBoss: true,
      name: BOSS.name,
      color: BOSS.color, eye: BOSS.eye, radius: BOSS.radius, r: BOSS.radius,
      x: bp.x, y: bp.y,
      hp: BOSS.hp * scale.hpMul, hpMax: BOSS.hp * scale.hpMul,
      damage: BOSS.damage * scale.dmgMul,
      speed: BOSS.speed,
      atkTimer: 1.5,
      patternTimer: 0,
      patternState: 'idle',
      stateData: {},
      animT: 0,
      xpReward: 50,
      behavior: 'boss',
      attackRange: 70,
      attackCooldown: 2.0,
    });
  }

  setInput(key, value) { this.input[key] = value; }

  // ===== ALTAR DAS MEMÓRIAS: integração =====================================
  // Chamado pela UI (InfernoGame.jsx) sempre que a build de habilidades muda
  // (ao entrar numa corrida e sempre que o jogador desbloqueia/redefine algo
  // na Altar das Memórias). Passar uma lista vazia restaura o comportamento
  // original do jogo.
  setMemoryBuild(ids) {
    this.memory = new Set(ids || []);
  }

  hasMem(id) { return this.memory ? this.memory.has(id) : false; }

  // Reseta os contadores/temporizadores das habilidades (não a build em si).
  // Chamado ao iniciar uma corrida e a cada nova fase (para efeitos "1x por
  // fase" como o Último Fôlego).
  resetMemoryRuntimeState() {
    const p = this.player;
    if (!p) return;
    p.memAtkBonus = 0;
    p.memKillStreak = 0;
    p.memAvatarTimer = 0;
    p.memCarnificinaStack = 0;
    p.memCarnificinaTimer = 0;
    p.memHuntTimer = 0;
    p.memShieldHp = 0;
    p.memShieldTimer = 0;
    p.memLastBreathUsed = false;
    p.memRegenBoostTimer = 0;
    p.memResistTimer = 0;
    p.memUnbreakableTimer = 0;
    p.memHitStreakTarget = null;
    p.memHitStreakCount = 0;
  }

  // Multiplicador de dano de ataque agregando os bônus temporários do Altar
  // das Memórias. Retorna 1 (neutro) se nada estiver desbloqueado/ativo.
  memAttackMultiplier() {
    const p = this.player;
    let mul = 1;
    if (p.memAtkBonus > 0) mul *= (1 + p.memAtkBonus);
    if (this.hasMem('avatar_guerra') && p.memAvatarTimer > 0) mul *= 1.20;
    if (this.hasMem('carnificina') && p.memCarnificinaStack > 0) {
      mul *= (1 + Math.min(0.10, p.memCarnificinaStack * 0.02));
    }
    if (this.hasMem('inferno_interior')) {
      const missing = clamp(1 - p.hp / p.hpMax, 0, 1);
      mul *= (1 + Math.min(0.15, missing * 0.15));
    }
    return mul;
  }

  // Bônus extra de roubo de vida (Predador / Avatar da Guerra), somado ao
  // p.lifesteal já existente (não o substitui).
  memLifestealBonus() {
    const p = this.player;
    let bonus = 0;
    if (this.hasMem('predador')) bonus += 0.07;
    if (this.hasMem('avatar_guerra') && p.memAvatarTimer > 0) bonus = Math.max(bonus, 0.15);
    return bonus;
  }

  // Multiplicador de velocidade de movimento (Caçada / Avatar da Guerra / Resistência).
  memMoveSpeedMultiplier() {
    const p = this.player;
    let mul = 1;
    if (this.hasMem('cacada') && p.memHuntTimer > 0) mul *= 1.08;
    if (this.hasMem('avatar_guerra') && p.memAvatarTimer > 0) mul *= 1.15;
    if (this.hasMem('resistencia') && p.memResistTimer > 0) mul *= 1.10;
    return mul;
  }

  // Aplica dano por-alvo específico da Altar das Memórias (Execução, Faísca)
  // e resolve crítico (Precisão) e queimadura (Brasa/Combustão). Usado pelos
  // dois ataques do jogador. `baseDmg` já inclui memAttackMultiplier().
  memRollTargetDamage(e, baseDmg) {
    let dmg = baseDmg;
    if (this.hasMem('execucao') && e.hp / e.hpMax < 0.20) dmg *= 1.20;
    if (this.hasMem('faisca') && e.burning) dmg *= 1.10;
    if (this.hasMem('precisao') && Math.random() < 0.05) {
      dmg *= 1.5;
      this.floatTexts.push({ x: e.x, y: e.y - e.radius - 20, t: 0.7, text: 'CRÍTICO', color: '#ffe070' });
    }
    return dmg;
  }

  // Tenta aplicar queimadura num alvo (Brasa / Combustão / Fornalha). Chamado
  // após um acerto de ataque do jogador que conectou.
  memTryIgnite(e) {
    if (!this.hasMem('brasa') || e.dead) return;
    if (this.hasMem('combustao')) {
      if (e === this.player.memHitStreakTarget) this.player.memHitStreakCount++;
      else { this.player.memHitStreakTarget = e; this.player.memHitStreakCount = 1; }
    }
    const streakBonus = this.hasMem('combustao') ? Math.min(0.20, (this.player.memHitStreakCount - 1) * 0.05) : 0;
    if (Math.random() < 0.20 + streakBonus) this.igniteEnemy(e);
  }

  igniteEnemy(e) {
    e.burning = true;
    e.burnDuration = this.hasMem('fornalha') ? 5 : 3;
    e.burnTimer = e.burnDuration;
    e.burnDps = Math.max(1, this.player.damage * 0.12);
  }

  // Pequena explosão de fogo (Incinerar ao morrer / Coração do Inferno ao
  // acertar). Não afeta bosses de forma desproporcional: dano fixo e baixo.
  memFireExplosion(x, y) {
    const radius = this.hasMem('explosao_infernal') ? 90 : 60;
    const dmg = Math.max(1, this.player.damage * 0.35);
    for (const e2 of this.enemies) {
      if (e2.dead) continue;
      if (dist({ x, y }, e2) <= radius + e2.radius) {
        this.damageEnemy(e2, dmg, true);
        if (this.hasMem('brasa')) this.igniteEnemy(e2);
      }
    }
    for (let i = 0; i < 10; i++) {
      this.spawnParticle({ x, y, vx: rand(-120, 120), vy: rand(-120, 120), t: 0.5, life: 0.5, color: '#ff7a1a', size: rand(2, 4) });
    }
  }

  // Atualiza temporizadores/queimaduras da Altar das Memórias. Chamado uma
  // vez por frame a partir de update().
  updateMemorySystem(dt) {
    const p = this.player;
    p.memAvatarTimer = Math.max(0, p.memAvatarTimer - dt);
    p.memHuntTimer = Math.max(0, p.memHuntTimer - dt);
    p.memShieldTimer = Math.max(0, p.memShieldTimer - dt);
    if (p.memShieldTimer <= 0) p.memShieldHp = 0;
    p.memGuardCd = Math.max(0, p.memGuardCd - dt);
    p.memRegenBoostTimer = Math.max(0, p.memRegenBoostTimer - dt);
    p.memResistTimer = Math.max(0, p.memResistTimer - dt);
    p.memUnbreakableTimer = Math.max(0, p.memUnbreakableTimer - dt);
    p.memUnbreakableCd = Math.max(0, p.memUnbreakableCd - dt);
    if (this.hasMem('folego') && p.memRegenBoostTimer > 0) {
      p.hp = Math.min(p.hpMax, p.hp + 5 * dt);
    }
    if (p.memCarnificinaTimer > 0) {
      p.memCarnificinaTimer -= dt;
      if (p.memCarnificinaTimer <= 0) p.memCarnificinaStack = 0;
    }
    // Inquebrável: gatilho automático ao cruzar 30% de HP (própria recarga).
    if (this.hasMem('inquebravel') && p.memUnbreakableCd <= 0 && p.memUnbreakableTimer <= 0
      && p.hp > 0 && p.hp / p.hpMax < 0.30) {
      p.memUnbreakableTimer = 4;
      p.memUnbreakableCd = 30;
      this.floatTexts.push({ x: p.x, y: p.y - 40, t: 1.2, text: 'INQUEBRÁVEL', color: '#a0d0ff' });
    }
    // Queimadura nos inimigos
    const cinzasSlow = this.hasMem('cinzas');
    for (const e of this.enemies) {
      if (e.dead) continue;
      if (e.burning) {
        if (e._memBaseSpeed == null) e._memBaseSpeed = e.speed;
        e.speed = cinzasSlow ? e._memBaseSpeed * 0.9 : e._memBaseSpeed;
        e.burnTimer -= dt;
        this.tickDamageEnemy(e, e.burnDps * dt);
        if (e.burnTimer <= 0) { e.burning = false; e.speed = e._memBaseSpeed; }
      } else if (e._memBaseSpeed != null) {
        e.speed = e._memBaseSpeed; // restaura velocidade original ao apagar
      }
    }
  }

  damagePlayer(amount) {
    const p = this.player;
    if (p.dead) return;
    if (p.invulnTime > 0) {
      // Esquiva perfeita (Altar das Memórias): o golpe foi anulado pela
      // janela de invencibilidade de uma esquiva ativa — recompensa o timing.
      if (p.dashTime > 0) {
        if (this.hasMem('contra_ataque')) p.memAtkBonus = Math.max(p.memAtkBonus, 0.30);
        if (this.hasMem('muralha')) p.memAtkBonus = Math.max(p.memAtkBonus, 0.20);
      }
      return;
    }
    if (p.dodgeChance > 0 && Math.random() < p.dodgeChance) {
      this.floatTexts.push({ x: p.x, y: p.y - 20, t: 0.8, text: 'ESQUIVOU', color: '#a0e0ff' });
      for (let i = 0; i < 6; i++) {
        this.spawnParticle({ x: p.x, y: p.y, vx: rand(-80, 80), vy: rand(-120, -20), t: 0.5, life: 0.5, color: '#80c0ff', size: 2 });
      }
      audio.play('dodge');
      // Ghost passive (Passo Etéreo): dodging grants a brief movement-speed burst.
      if (p.classId === 'ghost') p.etherealTimer = 2.0;
      return;
    }
    const dr = clamp(p.defense / (p.defense + 100), 0, 0.75);
    let dmg = Math.max(1, amount * (1 - dr));
    // Undead passive (Resistência Inabalável): while active, incoming damage is reduced 30%.
    if (p.classId === 'undead' && p.resistTimer > 0) dmg *= 0.70;
    // Pele de Ferro (Altar das Memórias): -8% de dano recebido.
    if (this.hasMem('pele_ferro')) dmg *= 0.92;
    // Inquebrável (Altar das Memórias): janela ativa reduz dano recebido em 25%.
    if (this.hasMem('inquebravel') && p.memUnbreakableTimer > 0) dmg *= 0.75;
    // Guardião (Altar das Memórias): escudo absorve parte/todo o dano.
    if (this.hasMem('guardiao') && p.memShieldHp > 0) {
      const absorbed = Math.min(p.memShieldHp, dmg);
      p.memShieldHp -= absorbed;
      dmg -= absorbed;
    }
    p.hp -= dmg;
    p.hurtFlash = 0.25;
    this.shake = Math.min(this.shake + 6, 14);
    if (dmg > 0) this.floatTexts.push({ x: p.x, y: p.y - 20, t: 0.8, text: `-${Math.round(dmg)}`, color: '#ff5040' });
    audio.play('hurt');
    // Undead passive trigger: crossing below 25% HP arms the 30%-less-damage
    // window for 5s, then goes on a 60s cooldown.
    if (p.classId === 'undead' && p.hp > 0 && p.resistCd <= 0 && p.resistTimer <= 0 && p.hp / p.hpMax < 0.25) {
      p.resistTimer = 5;
      p.resistCd = 60;
      this.floatTexts.push({ x: p.x, y: p.y - 40, t: 1.2, text: 'RESISTÊNCIA INABALÁVEL', color: '#7ab84a' });
    }

    // ---- ALTAR DAS MEMÓRIAS ----
    if (this.hasMem('avatar_guerra')) p.memKillStreak = 0; // combo quebrado ao tomar dano
    if (this.hasMem('folego')) p.memRegenBoostTimer = 2;
    if (this.hasMem('resistencia')) p.memResistTimer = 1;
    if (this.hasMem('guardiao') && p.memGuardCd <= 0 && p.hp > 0) {
      p.memShieldHp = Math.max(1, p.hpMax * 0.08);
      p.memShieldTimer = 3;
      p.memGuardCd = 20;
    }

    if (p.hp <= 0) {
      // Último Fôlego (Altar das Memórias): sobrevive uma vez por fase.
      if (this.hasMem('ultimo_folego') && !p.memLastBreathUsed) {
        p.memLastBreathUsed = true;
        p.hp = 1;
        this.floatTexts.push({ x: p.x, y: p.y - 40, t: 1.4, text: 'ÚLTIMO FÔLEGO', color: '#a0e0ff' });
      } else {
        p.hp = 0; p.dead = true; audio.play('death');
        clearCurrentSave();
        this.totalDeaths = bumpDeathCount();
        this.onDeath();
      }
    }
    this.emitUi();
  }

  // Continuous damage-over-time tick (used by the Force Field skill). Unlike
  // damageEnemy(), this intentionally skips the floating-damage-text, particle
  // burst and hit sound — those were previously fired via damageEnemy() on
  // EVERY frame for EVERY enemy standing inside the field (up to 60 times a
  // second, per enemy), which is what actually caused the severe stutter and
  // audio crackling players hit when using Skill 2 near a group of enemies.
  tickDamageEnemy(e, amount) {
    e.hp -= amount;
    if (e.hp <= 0) { this.killEnemy(e, true); audio.play('kill'); }
  }

  // Retorna: null se o inimigo esquivou (nenhum efeito de acerto deve ser
  // aplicado), true se o golpe matou o inimigo, false se acertou e ele
  // sobreviveu. Chamadores que ignoram o valor de retorno continuam
  // funcionando exatamente como antes.
  damageEnemy(e, amount, fromPlayer = true) {
    if (fromPlayer && e.dodgeChance > 0 && Math.random() < e.dodgeChance) {
      this.floatTexts.push({ x: e.x, y: e.y - e.radius - 6, t: 0.6, text: 'ESQUIVOU', color: '#a0e0ff' });
      for (let i = 0; i < 5; i++) {
        this.spawnParticle({ x: e.x, y: e.y, vx: rand(-80, 80), vy: rand(-120, -20), t: 0.4, life: 0.4, color: '#80c0ff', size: 2 });
      }
      audio.play('dodge');
      return null;
    }
    const dr = e.defense ? clamp(e.defense / (e.defense + 100), 0, 0.75) : 0;
    const dmg = fromPlayer ? Math.max(1, amount * (1 - dr)) : amount;
    e.hp -= dmg;
    this.floatTexts.push({ x: e.x, y: e.y - e.radius - 6, t: 0.6, text: `${Math.round(dmg)}`, color: '#ffe070' });
    for (let i = 0; i < 5; i++) {
      this.spawnParticle({ x: e.x, y: e.y, vx: rand(-80,80), vy: rand(-80,80), t: 0.5, life: 0.5, color: '#a01010', size: rand(2,4) });
    }
    if (e.hp <= 0) { this.killEnemy(e, fromPlayer); audio.play('kill'); return true; }
    if (fromPlayer) audio.play('hit');
    return false;
  }

  killEnemy(e, fromPlayer) {
    e.dead = true;
    const wasBurning = !!e.burning;
    for (let i = 0; i < 14; i++) {
      this.spawnParticle({ x: e.x, y: e.y, vx: rand(-160,160), vy: rand(-160,160), t: 0.8, life: 0.8, color: '#601010', size: rand(2,5) });
    }
    if (fromPlayer) {
      const p = this.player;
      p.kills++;
      // Vampire passive (Frenesi de Sangue): every kill (re)starts a 4s attack-speed buff.
      if (p.classId === 'vampire') p.frenzyTimer = 4.0;
      if (p.kills % 5 === 0) {
        p.level++;
        p.damage *= 1 + LEVEL_BONUS;
        p.attackSpeed *= 1 + LEVEL_BONUS;
        p.defense *= 1 + LEVEL_BONUS;
        p.hpMax = Math.round(p.hpMax * (1 + LEVEL_BONUS));
        p.hp = Math.min(p.hpMax, p.hp + p.hpMax * LEVEL_BONUS);
        this.floatTexts.push({ x: p.x, y: p.y - 40, t: 1.4, text: `LEVEL ${p.level}`, color: '#ffd060' });
        audio.play('level');
        for (let i = 0; i < 24; i++) {
          this.spawnParticle({ x: p.x, y: p.y, vx: rand(-200,200), vy: rand(-260,-60), t: 0.9, life: 0.9, color: '#ffb040', size: rand(2,4) });
        }
      }

      // ---- ALTAR DAS MEMÓRIAS ----
      if (this.hasMem('cacada')) p.memHuntTimer = 4;
      if (this.hasMem('carnificina')) {
        p.memCarnificinaStack = Math.min(5, p.memCarnificinaStack + 1);
        p.memCarnificinaTimer = 10;
      }
      if (this.hasMem('avatar_guerra')) {
        p.memKillStreak++;
        if (p.memKillStreak >= 5) {
          p.memKillStreak = 0;
          p.memAvatarTimer = 8;
          this.floatTexts.push({ x: p.x, y: p.y - 46, t: 1.3, text: 'AVATAR DA GUERRA', color: '#ff5028' });
        }
      }
      if (wasBurning && this.hasMem('incinerar')) this.memFireExplosion(e.x, e.y);
    }
  }

  // ===== SKILLS =====
  useSkill1() {
    const p = this.player;
    if (p.invulnCd > 0 || p.dead) return;
    p.invulnTime = 5; p.invulnCd = 10;
    this.floatTexts.push({ x: p.x, y: p.y - 30, t: 1, text: 'INVULNERÁVEL', color: '#80c0ff' });
    audio.play('skill1');
  }
  // ===== ESSÊNCIA REMANESCENTE (CURA) =====
  // Sistema de cura baseado em identidade: consome 1 frasco e restaura
  // 20% do HP TOTAL (hpMax) do jogador. Frascos são finitos por corrida.
  useHealFlask() {
    const p = this.player;
    if (p.dead || p.flasks <= 0) return;
    if (p.hp >= p.hpMax) return; // não desperdiça frasco com vida cheia
    p.flasks -= 1;
    const healAmount = p.hpMax * FLASK_HEAL_PCT;
    p.hp = Math.min(p.hpMax, p.hp + healAmount);
    this.floatTexts.push({ x: p.x, y: p.y - 30, t: 1, text: `+${Math.round(healAmount)} HP`, color: '#4aff6a' });
    for (let i = 0; i < 10; i++) {
      this.spawnParticle({ x: p.x, y: p.y, vx: rand(-60, 60), vy: rand(-120, -20), t: 0.7, life: 0.7, color: '#4aff6a', size: rand(2, 4) });
    }
    audio.play('heal');
    this.emitUi();
  }

  // Esquiva: dash rápido (na direção do analógico, ou para trás caso o
  // analógico esteja neutro), com uma janela curta de invencibilidade
  // embutida no próprio dash.
  dodge() {
    const p = this.player;
    if (p.dashCd > 0 || p.dead || p.dashTime > 0) return;

    // Direção do dash: segue o analógico (qualquer direção que o jogador
    // estiver segurando no momento da esquiva). Se o analógico estiver
    // neutro (sem input de movimento), mantém o comportamento antigo de
    // esquivar para trás, na direção oposta de onde o personagem está de frente.
    const inp = this.input;
    let dx = 0, dy = 0;
    if (inp.up) dy -= 1;
    if (inp.down) dy += 1;
    if (inp.left) dx -= 1;
    if (inp.right) dx += 1;
    const mag = Math.hypot(dx, dy);
    if (mag > 0) {
      p.dashDirX = dx / mag;
      p.dashDirY = dy / mag;
      p.facing = Math.atan2(p.dashDirY, p.dashDirX);
      p.flipX = p.dashDirX < 0;
    } else {
      p.dashDirX = -Math.cos(p.facing);
      p.dashDirY = -Math.sin(p.facing);
    }
    p.dashTime = 0.22;
    p.dashCd = 3;
    // Disciplina (Altar das Memórias): janela de invulnerabilidade um pouco maior.
    const invulnWindow = this.hasMem('disciplina') ? 0.30 : 0.22;
    p.invulnTime = Math.max(p.invulnTime, invulnWindow);
    this.floatTexts.push({ x: p.x, y: p.y - 30, t: 0.6, text: 'ESQUIVA', color: '#a0e0ff' });
    audio.play('dodge');

    // ---- ALTAR DAS MEMÓRIAS ----
    // Ímpeto: próximo ataque com +15% de dano.
    if (this.hasMem('impeto')) p.memAtkBonus = Math.max(p.memAtkBonus, 0.15);
    // Labareda: deixa um pequeno rastro de fogo (visual + queima leve na área).
    if (this.hasMem('labareda')) {
      const fx = p.x, fy = p.y;
      for (let i = 0; i < 6; i++) {
        this.spawnParticle({ x: fx, y: fy, vx: rand(-30, 30), vy: rand(-30, 30), t: 0.5, life: 0.5, color: '#ff7a1a', size: rand(2, 4) });
      }
      for (const e of this.enemies) {
        if (!e.dead && dist({ x: fx, y: fy }, e) < 40 + e.radius && this.hasMem('brasa')) this.igniteEnemy(e);
      }
    }
  }

  applyAttribute(key) {
    const p = this.player;
    switch (key) {
      case 'damage': p.damage *= 1.15; break;
      case 'attackSpeed': p.attackSpeed *= 1.20; break;
      case 'lifesteal': p.lifesteal += 0.10; break;
      case 'defense': p.defense *= 1.25; break;
      case 'hp': p.hpMax *= 2; p.hp = p.hpMax; break;
      default: break;
    }
    this.emitUi();
  }

  // Desfaz exatamente o efeito de applyAttribute (operação inversa), usado
  // quando o jogador troca a dádiva escolhida antes de confirmar o avanço de
  // fase. Assim não existe trava permanente no atributo clicado.
  revertAttribute(key) {
    const p = this.player;
    switch (key) {
      case 'damage': p.damage /= 1.15; break;
      case 'attackSpeed': p.attackSpeed /= 1.20; break;
      case 'lifesteal': p.lifesteal -= 0.10; break;
      case 'defense': p.defense /= 1.25; break;
      case 'hp': p.hpMax /= 2; p.hp = Math.min(p.hp, p.hpMax); break;
      default: break;
    }
    this.emitUi();
  }

  applyNpcBuff() {
    const p = this.player;
    p.hp = p.hpMax;
    p.lifesteal += 0.03;
    this.floatTexts.push({ x: p.x, y: p.y - 30, t: 2, text: 'ALMA TE ABENÇOOU', color: '#a0e0ff' });
    this.emitUi();
  }

  nextPhase() { if (this.phase < PHASES) this.startPhase(this.phase + 1); }

  tryInteract() {
    const p = this.player;
    if (this.portal && dist(this.portal, p) < 70) { this.enterPortal(); return; }
    if (!this.npcs.length) return;
    for (const npc of this.npcs) {
      if (dist(npc, p) < 60) { this.onMeetNpc(npc); return; }
    }
  }

  // ===== UPDATE =====
  update(dt) {
    this._gameTime = (this._gameTime || 0) + dt;
    if (this.player.dead) {
      this.updateParticles(dt);
      this.updateFloatTexts(dt);
      this.updateCamera();
      return;
    }
    this.phaseTime += dt;
    if (this.shake > 0) this.shake = Math.max(0, this.shake - dt * 24);
    if (this.bossBannerTime > 0) this.bossBannerTime -= dt;

    this.updatePlayer(dt);
    this.updateEnemies(dt);
    this.updateProjectiles(dt);
    this.updateMemorySystem(dt);
    this.updateParticles(dt);
    this.updateFloatTexts(dt);
    this.updateCamera();
    // Brazier flicker time
    for (const b of this.braziers) b.t += dt;
    if (this.portal) this.portal.t += dt;
    this.checkClear();
    this._uiT = (this._uiT || 0) + dt;
    if (this._uiT > 0.1) { this._uiT = 0; this.emitUi(); }
  }

  updatePlayer(dt) {
    const p = this.player;
    const inp = this.input;
    let dx = 0, dy = 0;
    if (inp.up) dy -= 1;
    if (inp.down) dy += 1;
    if (inp.left) dx -= 1;
    if (inp.right) dx += 1;
    const mag = Math.hypot(dx, dy);
    p.moving = mag > 0;

    if (p.dashTime > 0) {
      // Esquiva em andamento: dash para trás sobrepõe o controle normal.
      // Passo Seguro (Altar das Memórias): dash percorre uma distância maior.
      const dashDistMul = this.hasMem('passo_seguro') ? 1.25 : 1;
      const dashSpeed = p.moveSpeed * 2.6 * dashDistMul;
      this.moveWithCollision(p, p.dashDirX * dashSpeed * dt, p.dashDirY * dashSpeed * dt, p.r);
      p.dashTime = Math.max(0, p.dashTime - dt);
      p.moving = false;
    } else if (p.moving) {
      dx /= mag; dy /= mag;
      // Ghost passive (Passo Etéreo): +20% move speed for 2s after dodging a hit.
      const moveMul = (p.etherealTimer > 0 ? 1.20 : 1) * this.memMoveSpeedMultiplier();
      this.moveWithCollision(p, dx * p.moveSpeed * moveMul * dt, dy * p.moveSpeed * moveMul * dt, p.r);
      p.facing = Math.atan2(dy, dx);
      if (Math.abs(dx) > 0.01) p.flipX = dx < 0;
      p.animTime += dt;
      if (p.animTime > 0.12) { p.animTime = 0; p.animFrame = (p.animFrame + 1) % SPR.walk.length; }
    } else {
      p.animTime += dt;
      if (p.animTime > 0.4) { p.animTime = 0; p.animFrame = (p.animFrame + 1) % SPR.idle.length; }
    }

    p.attackCooldown = Math.max(0, p.attackCooldown - dt);
    p.attack2Cooldown = Math.max(0, p.attack2Cooldown - dt);
    p.invulnCd = Math.max(0, p.invulnCd - dt);
    p.dashCd = Math.max(0, p.dashCd - dt);
    p.invulnTime = Math.max(0, p.invulnTime - dt);
    p.attackAnim = Math.max(0, p.attackAnim - dt);
    p.attack2Anim = Math.max(0, p.attack2Anim - dt);
    p.hurtFlash = Math.max(0, p.hurtFlash - dt);

    // Unique passive timers
    p.resistTimer = Math.max(0, p.resistTimer - dt);
    p.resistCd = Math.max(0, p.resistCd - dt);
    p.frenzyTimer = Math.max(0, p.frenzyTimer - dt);
    p.etherealTimer = Math.max(0, p.etherealTimer - dt);

    // Passive HP regen (undead)
    if (p.regenPerSec > 0 && p.hp < p.hpMax) {
      p.hp = Math.min(p.hpMax, p.hp + p.regenPerSec * dt);
    }

    if (p.dashTime <= 0) {
      if (inp.attack && p.attackCooldown <= 0) this.playerAttack();
      if (inp.attack2 && p.attack2Cooldown <= 0) this.playerAttack2();
    }
  }

  playerAttack() {
    const p = this.player;
    // Vampire passive (Frenesi de Sangue): +10% attack speed for 4s after a kill.
    const atkSpeedMul = p.frenzyTimer > 0 ? 1.10 : 1;
    p.attackCooldown = 1 / (p.attackSpeed * atkSpeedMul);
    p.attackAnim = 0.25;
    audio.play('attack');

    // Altar das Memórias: multiplicador agregado da esta investida + roubo de
    // vida extra. Consumidos uma única vez por golpe (não por alvo).
    const memMul = this.memAttackMultiplier();
    const lifestealTotal = p.lifesteal + this.memLifestealBonus();
    p.memAtkBonus = 0;

    let target = null; let best = Infinity;
    for (const e of this.enemies) {
      if (e.dead) continue;
      const d = dist(p, e);
      if (d < p.attackRange + e.radius && d < best) { best = d; target = e; }
    }
    if (target) {
      p.facing = angle(p, target);
      p.flipX = Math.cos(p.facing) < 0;
    }
    const arc = Math.PI / 2;
    for (const e of this.enemies) {
      if (e.dead) continue;
      const d = dist(p, e);
      if (d > p.attackRange + e.radius) continue;
      const ang = angle(p, e);
      const diff = Math.abs(((ang - p.facing) + Math.PI * 3) % (Math.PI * 2) - Math.PI);
      if (diff < arc) {
        const dmg = this.memRollTargetDamage(e, p.damage * memMul);
        const result = this.damageEnemy(e, dmg, true);
        if (result !== null) {
          p.hp = Math.min(p.hpMax, p.hp + dmg * lifestealTotal);
          this.memTryIgnite(e);
          if (this.hasMem('coracao_inferno') && e.burning) this.memFireExplosion(e.x, e.y);
        }
      }
    }
    const r = p.attackRange;
    for (let i = 0; i < 8; i++) {
      const a = p.facing + rand(-arc, arc);
      const d = rand(20, r);
      this.spawnParticle({ x: p.x + Math.cos(a) * d, y: p.y + Math.sin(a) * d, vx: 0, vy: 0, t: 0.15, life: 0.15, color: '#fff0c0', size: rand(2, 4) });
    }
  }

  // Ataque 2: golpe mais pesado e um pouco mais lento que o Ataque 1, com
  // mais dano e alcance, porém arco de acerto mais estreito (um golpe
  // mais "de precisão" em vez de um corte amplo).
  // Golpe Firme (Altar das Memórias): este é oficialmente o "Ataque Pesado" —
  // nenhum ataque novo foi criado, apenas sua recuperação foi reduzida.
  playerAttack2() {
    const p = this.player;
    const atkSpeedMul = p.frenzyTimer > 0 ? 1.10 : 1;
    const cdMul = this.hasMem('golpe_firme') ? 0.85 : 1;
    p.attack2Cooldown = 1.35 * cdMul / (p.attackSpeed * atkSpeedMul);
    p.attack2Anim = 0.32;
    audio.play('attack');

    const memMul = this.memAttackMultiplier();
    const lifestealTotal = p.lifesteal + this.memLifestealBonus();
    p.memAtkBonus = 0;

    let target = null; let best = Infinity;
    const range2 = p.attackRange * 1.15;
    for (const e of this.enemies) {
      if (e.dead) continue;
      const d = dist(p, e);
      if (d < range2 + e.radius && d < best) { best = d; target = e; }
    }
    if (target) {
      p.facing = angle(p, target);
      p.flipX = Math.cos(p.facing) < 0;
    }
    const arc = Math.PI / 3.2;
    for (const e of this.enemies) {
      if (e.dead) continue;
      const d = dist(p, e);
      if (d > range2 + e.radius) continue;
      const ang = angle(p, e);
      const diff = Math.abs(((ang - p.facing) + Math.PI * 3) % (Math.PI * 2) - Math.PI);
      if (diff < arc) {
        const dmg = this.memRollTargetDamage(e, p.damage * 1.6 * memMul);
        const result = this.damageEnemy(e, dmg, true);
        if (result !== null) {
          p.hp = Math.min(p.hpMax, p.hp + dmg * lifestealTotal);
          this.memTryIgnite(e);
          if (this.hasMem('coracao_inferno') && e.burning) this.memFireExplosion(e.x, e.y);
          // Quebra Guarda: o Ataque Pesado atrasa o próximo ataque do inimigo,
          // simulando maior capacidade de interromper.
          if (this.hasMem('quebra_guarda') && !e.dead) e.atkTimer = Math.max(e.atkTimer, 0.6);
        }
      }
    }
    for (let i = 0; i < 10; i++) {
      const a = p.facing + rand(-arc, arc);
      const d = rand(20, range2);
      this.spawnParticle({ x: p.x + Math.cos(a) * d, y: p.y + Math.sin(a) * d, vx: 0, vy: 0, t: 0.18, life: 0.18, color: '#ffd0a0', size: rand(2, 5) });
    }
  }

  updateEnemies(dt) {
    const p = this.player;
    for (const e of this.enemies) {
      if (e.dead) continue;
      e.animT += dt; e.atkTimer -= dt;
      if (e.attackAnim > 0) e.attackAnim -= dt;
      if (e.behavior === 'boss') { this.updateBoss(e, dt); continue; }
      const d = dist(e, p);
      if (p.x !== e.x) e.facing = p.x >= e.x ? 1 : -1;
      e.moving = false;

      if (e.behavior === 'chase') {
        const a = angle(e, p);
        if (d > e.attackRange + e.radius - 4) {
          this.moveWithCollision(e, Math.cos(a) * e.speed * dt, Math.sin(a) * e.speed * dt, e.radius);
          e.moving = true;
        }
        if (d < e.attackRange + e.radius && e.atkTimer <= 0) {
          this.damagePlayer(e.damage);
          e.atkTimer = e.attackCooldown;
          e.attackAnim = 0.3;
        }
      } else if (e.behavior === 'teleport') {
        e.stateTimer -= dt;
        if (e.stateTimer <= 0) {
          let placed = false;
          for (let tries = 0; tries < 12; tries++) {
            const tA = Math.random() * Math.PI * 2;
            const tD = rand(110, 200);
            const tx = clamp(p.x + Math.cos(tA) * tD, 30, WORLD_W - 30);
            const ty = clamp(p.y + Math.sin(tA) * tD, 30, WORLD_H - 30);
            if (!this.collideCircleWithWalls(tx, ty, e.radius)) { e.x = tx; e.y = ty; placed = true; break; }
          }
          if (!placed) {
            const sp = this.findOpenSpawn(p.x + 140, p.y, e.radius);
            e.x = sp.x; e.y = sp.y;
          }
          e.stateTimer = rand(2, 3.5);
          for (let i = 0; i < 10; i++)
            this.spawnParticle({ x: e.x, y: e.y, vx: rand(-100,100), vy: rand(-100,100), t: 0.4, life: 0.4, color: '#a040ff', size: 3 });
        }
        const a = angle(e, p);
        this.moveWithCollision(e, Math.cos(a) * e.speed * 0.4 * dt, Math.sin(a) * e.speed * 0.4 * dt, e.radius);
        e.moving = true;
        if (d < e.attackRange + e.radius && e.atkTimer <= 0) {
          this.damagePlayer(e.damage); e.atkTimer = e.attackCooldown; e.attackAnim = 0.3;
        }
      } else if (e.behavior === 'charge') {
        if (e.stateData.charging) {
          const px = e.x, py = e.y;
          this.moveWithCollision(e, e.stateData.cx * e.speed * 1.8 * dt, e.stateData.cy * e.speed * 1.8 * dt, e.radius);
          e.moving = true;
          e.stateTimer -= dt;
          if (e.stateTimer <= 0 || d < e.attackRange ||
              (Math.abs(e.x - px) < 0.2 && Math.abs(e.y - py) < 0.2)) {
            e.stateData.charging = false; e.stateTimer = rand(1.0, 1.6);
          }
          if (d < e.attackRange + e.radius && e.atkTimer <= 0) {
            this.damagePlayer(e.damage * 1.5);
            e.atkTimer = e.attackCooldown;
            e.attackAnim = 0.3;
            e.stateData.charging = false; e.stateTimer = 1.2;
          }
        } else {
          e.stateTimer -= dt;
          if (e.stateTimer <= 0) {
            const a = angle(e, p);
            e.stateData.cx = Math.cos(a); e.stateData.cy = Math.sin(a);
            e.stateData.charging = true; e.stateTimer = 1.5;
          }
        }
      } else if (e.behavior === 'ranged') {
        const a = angle(e, p);
        const desired = 240;
        if (d < desired - 20) { this.moveWithCollision(e, -Math.cos(a) * e.speed * dt, -Math.sin(a) * e.speed * dt, e.radius); e.moving = true; }
        else if (d > desired + 20) { this.moveWithCollision(e, Math.cos(a) * e.speed * dt, Math.sin(a) * e.speed * dt, e.radius); e.moving = true; }
        if (e.atkTimer <= 0 && d < e.attackRange) {
          this.projectiles.push({ x: e.x, y: e.y, vx: Math.cos(a) * 260, vy: Math.sin(a) * 260, r: 7, damage: e.damage, life: 2.0, t: 2.0, from: 'enemy', color: '#ff60c0' });
          e.atkTimer = e.attackCooldown;
          e.attackAnim = 0.3;
        }
      }
    }
    this.enemies = this.enemies.filter(e => !e.dead);
  }

  updateBoss(e, dt) {
    const p = this.player;
    e.patternTimer -= dt;
    const d = dist(e, p);
    const a = angle(e, p);
    if (e.patternState === 'idle') {
      if (d > 200) this.moveWithCollision(e, Math.cos(a) * e.speed * dt, Math.sin(a) * e.speed * dt, e.radius);
      else if (d < 130) this.moveWithCollision(e, -Math.cos(a) * e.speed * 0.4 * dt, -Math.sin(a) * e.speed * 0.4 * dt, e.radius);
      if (e.patternTimer <= 0) {
        const choices = ['claw', 'breath', 'orbs', 'summon', 'slam'];
        e.patternState = choices[Math.floor(Math.random() * choices.length)];
        e.patternTimer = 1.0;
        e.stateData = {};
      }
    } else if (e.patternState === 'claw') {
      if (e.patternTimer < 0.4 && !e.stateData.hit) {
        if (d < 110 + e.radius) this.damagePlayer(e.damage * 1.2);
        e.stateData.hit = true;
      }
      if (e.patternTimer <= 0) { e.patternState = 'idle'; e.patternTimer = rand(0.8, 1.4); e.stateData = {}; }
    } else if (e.patternState === 'breath') {
      if (!e.stateData.t) { e.stateData.t = 1.5; e.stateData.dir = a; }
      e.stateData.t -= dt;
      const conAng = e.stateData.dir;
      const arc = Math.PI / 4;
      const reach = 320;
      for (let i = 0; i < 4; i++) {
        const aa = conAng + rand(-arc, arc);
        const dd = rand(0, reach);
        this.spawnParticle({ x: e.x + Math.cos(aa) * dd, y: e.y + Math.sin(aa) * dd, vx: 0, vy: 0, t: 0.3, life: 0.3, color: '#ff5020', size: rand(3,6) });
      }
      if (d < reach) {
        const aP = angle(e, p);
        const diff = Math.abs(((aP - conAng) + Math.PI * 3) % (Math.PI * 2) - Math.PI);
        if (diff < arc) this.damagePlayer(e.damage * 0.4 * dt * 4);
      }
      if (e.stateData.t <= 0) { e.patternState = 'idle'; e.patternTimer = rand(1.2, 1.8); e.stateData = {}; }
    } else if (e.patternState === 'orbs') {
      if (!e.stateData.fired) {
        const N = 10;
        for (let i = 0; i < N; i++) {
          const aa = (i / N) * Math.PI * 2 + rand(-0.1, 0.1);
          this.projectiles.push({ x: e.x, y: e.y, vx: Math.cos(aa) * 200, vy: Math.sin(aa) * 200, r: 10, damage: e.damage * 0.7, life: 3, t: 3, from: 'enemy', color: '#a040ff' });
        }
        e.stateData.fired = true;
      }
      if (e.patternTimer <= 0) { e.patternState = 'idle'; e.patternTimer = rand(1.0, 1.5); e.stateData = {}; }
    } else if (e.patternState === 'summon') {
      if (!e.stateData.fired) {
        const scale = phaseScale(10);
        for (let i = 0; i < 3; i++) this.spawnEnemy('blood', scale);
        e.stateData.fired = true;
        this.floatTexts.push({ x: e.x, y: e.y - e.radius - 20, t: 1.4, text: 'INVOCA SERVOS!', color: '#ff6020' });
      }
      if (e.patternTimer <= 0) { e.patternState = 'idle'; e.patternTimer = rand(1.5, 2.5); e.stateData = {}; }
    } else if (e.patternState === 'slam') {
      if (!e.stateData.done && e.patternTimer < 0.3) {
        this.shake = Math.min(20, this.shake + 14);
        const radius = 200;
        if (d < radius + e.radius) this.damagePlayer(e.damage * 1.4);
        for (let i = 0; i < 24; i++) {
          const aa = Math.random() * Math.PI * 2;
          const dd = rand(40, radius);
          this.spawnParticle({ x: e.x + Math.cos(aa)*dd, y: e.y + Math.sin(aa)*dd, vx:0, vy:0, t:0.5, life:0.5, color:'#ff3010', size: rand(3,6) });
        }
        e.stateData.done = true;
      }
      if (e.patternTimer <= 0) { e.patternState = 'idle'; e.patternTimer = rand(1.5, 2.2); e.stateData = {}; }
    }
  }

  updateProjectiles(dt) {
    const p = this.player;
    for (const pr of this.projectiles) {
      if (pr.dead) continue;
      pr.x += pr.vx * dt; pr.y += pr.vy * dt;
      pr.t -= dt;
      if (pr.t <= 0) { pr.dead = true; continue; }
      if (pr.x < -20 || pr.x > WORLD_W + 20 || pr.y < -20 || pr.y > WORLD_H + 20) { pr.dead = true; continue; }
      if (this.collideCircleWithWalls(pr.x, pr.y, pr.r)) {
        pr.dead = true;
        for (let i = 0; i < 4; i++)
          this.spawnParticle({ x: pr.x, y: pr.y, vx: rand(-60,60), vy: rand(-60,60), t: 0.25, life: 0.25, color: pr.color, size: 2 });
        continue;
      }
      if (pr.from === 'player') {
        for (const e of this.enemies) {
          if (e.dead) continue;
          if (dist(pr, e) < pr.r + e.radius) {
            this.damageEnemy(e, pr.damage, true);
            p.hp = Math.min(p.hpMax, p.hp + pr.damage * p.lifesteal);
            pr.dead = true; break;
          }
        }
      } else {
        if (dist(pr, p) < pr.r + p.r) { this.damagePlayer(pr.damage); pr.dead = true; }
      }
    }
    this.projectiles = this.projectiles.filter(p => !p.dead);
  }

  updateParticles(dt) {
    for (const pa of this.particles) { pa.x += (pa.vx || 0) * dt; pa.y += (pa.vy || 0) * dt; pa.t -= dt; }
    this.particles = this.particles.filter(p => p.t > 0);
    // Safety cap: several VFX bursts overlapping (boss patterns + field DOT + hits)
    // could otherwise pile up thousands of particles and tank the framerate.
    const PARTICLE_CAP = this.settings.quality === 'baixo' ? 120 : this.settings.quality === 'alto' ? 500 : 400;
    if (this.particles.length > PARTICLE_CAP) {
      this.particles = this.particles.slice(this.particles.length - PARTICLE_CAP);
    }
  }

  updateFloatTexts(dt) {
    for (const ft of this.floatTexts) { ft.y -= 30 * dt; ft.t -= dt; }
    this.floatTexts = this.floatTexts.filter(f => f.t > 0);
    const FLOATTEXT_CAP = 60;
    if (this.floatTexts.length > FLOATTEXT_CAP) {
      this.floatTexts = this.floatTexts.slice(this.floatTexts.length - FLOATTEXT_CAP);
    }
  }

  checkClear() {
    if (this.cleared) return;
    if (this.introLocked) return; // andar 1 ainda não liberou os inimigos (NPC introdutório)
    if (this.enemies.length === 0) {
      this.cleared = true;
      this.persistSnapshot();
      if (this.phase >= PHASES) {
        audio.play('victory');
        clearCurrentSave();
        this.onVictory();
      } else {
        // Ao limpar a fase, um portal narrativo surge no mapa. O jogador
        // precisa se aproximar e interagir (botão "ENTRAR") — só então a
        // transição de fase (Altar das Memórias / atributo) é disparada.
        audio.play('level');
        // Determinação (Altar das Memórias): concluir a fase sem morrer
        // recupera uma pequena quantidade de HP. Como a corrida termina em
        // caso de morte, chegar aqui já satisfaz "sem morrer".
        if (this.hasMem('determinacao')) {
          const p = this.player;
          p.hp = Math.min(p.hpMax, p.hp + p.hpMax * 0.10);
        }
        this.spawnPortal();
      }
    }
  }

  // Abre um portal narrativo assim que a fase é limpa. O jogador precisa se
  // aproximar e interagir (botão "ENTRAR") para de fato avançar de andar —
  // a transição (onPhaseClear, que hoje abre o Altar das Memórias) só é
  // disparada nesse momento.
  spawnPortal() {
    const room = this.rooms[this.rooms.length - 1] || this.rooms[Math.floor(this.rooms.length / 2)] || this.rooms[0];
    let x, y;
    if (room) {
      x = (room.x + room.w / 2) * TILE;
      y = (room.y + room.h / 2) * TILE;
    } else {
      x = this.player.x; y = this.player.y;
    }
    this.portal = { x, y, r: 34, t: 0 };
  }

  enterPortal() {
    if (!this.portal) return;
    this.portal = null;
    this.onPhaseClear(this.phase);
  }

  snapshot() {
    const p = this.player;
    return {
      phase: this.phase + 1,
      kills: p.kills,
      level: p.level,
      classId: p.classId,
      damage: p.damage,
      attackSpeed: p.attackSpeed,
      defense: p.defense,
      lifesteal: p.lifesteal,
      moveSpeed: p.moveSpeed,
      hp: p.hp,
      hpMax: p.hpMax,
      attackRange: p.attackRange,
      dodgeChance: p.dodgeChance,
      regenPerSec: p.regenPerSec,
      className: p.className,
      classColor: p.classColor,
      flasks: p.flasks,
    };
  }

  persistSnapshot() {
    try { saveProgress(this.snapshot()); } catch (_e) { /* ignore */ }
  }

  loadFromSave(snap) {
    const p = this.player;
    p.classId = snap.classId || p.classId;
    p.className = snap.className || p.className;
    p.classColor = snap.classColor || p.classColor;
    p.kills = snap.kills || 0;
    p.level = snap.level || 1;
    p.damage = snap.damage || p.damage;
    p.attackSpeed = snap.attackSpeed || p.attackSpeed;
    p.defense = snap.defense || p.defense;
    p.lifesteal = snap.lifesteal != null ? snap.lifesteal : p.lifesteal;
    p.moveSpeed = snap.moveSpeed || p.moveSpeed;
    p.hpMax = snap.hpMax || p.hpMax;
    p.hp = snap.hp || p.hpMax;
    p.attackRange = snap.attackRange || p.attackRange;
    p.dodgeChance = snap.dodgeChance != null ? snap.dodgeChance : p.dodgeChance;
    p.regenPerSec = snap.regenPerSec != null ? snap.regenPerSec : p.regenPerSec;
    p.flasks = snap.flasks != null ? snap.flasks : p.flasks;
    const phase = Math.max(1, Math.min(PHASES, snap.phase || 1));
    this.startPhase(phase);
    this.emitUi();
  }

  // ===== RENDER =====
  render(ctx) {
    ctx.save();
    // Screen shake (screen space, before zoom) — desativável em Configurações
    if (this.settings.screenShake && this.shake > 0) ctx.translate(rand(-this.shake, this.shake), rand(-this.shake, this.shake));
    // Zoom in: everything is drawn ZOOM× larger
    ctx.scale(ZOOM, ZOOM);
    // Camera translate (world -> screen), accounting for zoom
    ctx.translate(-Math.round(this.camera.x), -Math.round(this.camera.y));

    this.drawLavaBackground(ctx);
    this.drawFloorTiles(ctx);
    this.drawFloorEdges(ctx);
    this.drawBraziers(ctx);
    for (const npc of this.npcs) this.drawNpc(ctx, npc);
    if (this.portal) this.drawPortal(ctx, this.portal);
    for (const e of this.enemies) this.drawEnemy(ctx, e);
    this.drawPlayer(ctx);
    for (const pr of this.projectiles) this.drawProjectile(ctx, pr);
    for (const pa of this.particles) {
      const alpha = clamp(pa.t / pa.life, 0, 1);
      ctx.globalAlpha = alpha;
      ctx.fillStyle = pa.color;
      ctx.fillRect(pa.x - pa.size / 2, pa.y - pa.size / 2, pa.size, pa.size);
    }
    ctx.globalAlpha = 1;
    ctx.font = "bold 18px 'VT323', monospace";
    ctx.textAlign = 'center';
    for (const ft of this.floatTexts) {
      ctx.globalAlpha = clamp(ft.t, 0, 1);
      ctx.fillStyle = '#000'; ctx.fillText(ft.text, ft.x + 1, ft.y + 1);
      ctx.fillStyle = ft.color; ctx.fillText(ft.text, ft.x, ft.y);
    }
    ctx.globalAlpha = 1;
    ctx.restore();

    // Vinheta (espaço de tela, sem câmera/zoom) — escurece as bordas pra dar
    // profundidade e clima. Desenhada por último, por cima de tudo do mundo,
    // mas embaixo do HUD (que vive fora do canvas, em HTML).
    if (this._vignetteSprite) ctx.drawImage(this._vignetteSprite, 0, 0, W, H);

    // Screen-space overlays (boss HP bar) go here (drawn after restore, no camera)
    this.drawBossHpOverlay(ctx);
  }

  // Compute visible tile bounds for culling (accounts for ZOOM)
  visibleTileBounds() {
    const vw = W / ZOOM, vh = H / ZOOM;
    const c0 = Math.max(0, Math.floor(this.camera.x / TILE) - 1);
    const r0 = Math.max(0, Math.floor(this.camera.y / TILE) - 1);
    const c1 = Math.min(this.mapCols, Math.ceil((this.camera.x + vw) / TILE) + 1);
    const r1 = Math.min(this.mapRows, Math.ceil((this.camera.y + vh) / TILE) + 1);
    return { c0, r0, c1, r1 };
  }

  drawLavaBackground(ctx) {
    const th = this.theme || DUNGEON_THEMES[0];
    const { c0, r0, c1, r1 } = this.visibleTileBounds();
    const t = this._gameTime || 0; // animated offset

    for (let r = r0; r < r1; r++) {
      for (let c = c0; c < c1; c++) {
        if (this.isFloor(c, r)) continue;
        const x = c * TILE, y = r * TILE;
        const h1 = ((c * 73856093) ^ (r * 19349663)) >>> 0;
        const h2 = ((c * 83492791) ^ (r * 58943609)) >>> 0;

        // Base lava fill
        ctx.fillStyle = th.lavaColor;
        ctx.fillRect(x, y, TILE, TILE);

        // Animated lava pulses (2px pixel blocks for chunky pixel art look)
        const pulse = 0.5 + 0.5 * Math.sin(t * 1.5 + (h1 & 0xf) * 0.4);
        if ((h1 & 0x7) < 3) {
          ctx.fillStyle = th.lavaHot;
          ctx.globalAlpha = 0.3 + 0.25 * pulse;
          const bx = x + (h1 & 0x1f), by = y + ((h1 >> 5) & 0x1f);
          ctx.fillRect(bx, by, 4, 2);
          ctx.fillRect(bx + 2, by + 2, 2, 4);
          ctx.globalAlpha = 1;
        }
        // Dark cracks (static pixel art lines)
        if ((h2 & 0xf) < 5) {
          ctx.fillStyle = 'rgba(0,0,0,0.7)';
          const cx2 = x + 4 + (h2 & 0xf) * 2;
          const cy2 = y + 4 + ((h2 >> 4) & 0xf) * 2;
          ctx.fillRect(cx2, cy2, 2, 6 + (h2 & 3) * 2);
          ctx.fillRect(cx2 - 2, cy2 + 4, 6, 2);
        }
        // Hot glow near floor edges
        if (this.isFloor(c, r - 1) || this.isFloor(c, r + 1) || this.isFloor(c - 1, r) || this.isFloor(c + 1, r)) {
          ctx.fillStyle = th.lavaHot;
          ctx.globalAlpha = 0.18 + 0.12 * pulse;
          ctx.fillRect(x, y, TILE, TILE);
          ctx.globalAlpha = 1;
        }
      }
    }
  }

  isFloor(c, r) {
    if (!this.tileGrid) return false;
    if (r < 0 || r >= this.mapRows || c < 0 || c >= this.mapCols) return false;
    return this.tileGrid[r][c] === 1;
  }

  drawFloorTiles(ctx) {
    if (!this.tileGrid) return;
    const th = this.theme || DUNGEON_THEMES[0];
    const { c0, r0, c1, r1 } = this.visibleTileBounds();

    for (let r = r0; r < r1; r++) {
      for (let c = c0; c < c1; c++) {
        if (this.tileGrid[r][c] !== 1) continue;
        const x = c * TILE, y = r * TILE;
        const h1 = ((c * 73856093) ^ (r * 19349663)) >>> 0;
        const h2 = ((c * 83492791) ^ (r * 58943609)) >>> 0;

        // === FLOOR PIXEL-ART ===
        // Base stone slab
        ctx.fillStyle = th.floorColor;
        ctx.fillRect(x, y, TILE, TILE);

        // Stone slab grid (pixel art 20×20 blocks per tile)
        const slabX = (c + r) % 2;
        ctx.fillStyle = slabX ? th.floorMid : th.floorAcc;
        ctx.fillRect(x + 1, y + 1, TILE - 2, TILE - 2);

        // Mortar lines (dark pixel lines separating slabs)
        ctx.fillStyle = 'rgba(0,0,0,0.5)';
        ctx.fillRect(x, y, TILE, 1);        // top edge
        ctx.fillRect(x, y, 1, TILE);        // left edge

        // Light highlight (top-left corner, 1px pixel look)
        ctx.fillStyle = 'rgba(255,255,255,0.05)';
        ctx.fillRect(x + 1, y + 1, TILE - 2, 1);
        ctx.fillRect(x + 1, y + 1, 1, TILE - 2);

        // Random cracks / detail pixels
        if (th.cracks && (h1 & 0xf) === 0) {
          ctx.fillStyle = 'rgba(0,0,0,0.45)';
          const cx2 = x + 4 + (h1 >> 4 & 0x1f);
          const cy2 = y + 4 + (h2 & 0x1f);
          ctx.fillRect(cx2, cy2, 1, 4 + (h2 >> 4 & 3));
          ctx.fillRect(cx2 + 1, cy2 + 2, 3, 1);
        }

        // === WALL TOP (north edge: draws a raised wall face on tiles that border lava north) ===
        if (!this.isFloor(c, r - 1)) {
          // Wall face – chunky pixel art stone blocks
          ctx.fillStyle = th.wallColor;
          ctx.fillRect(x, y, TILE, 8);
          ctx.fillStyle = th.wallMid;
          ctx.fillRect(x + 1, y + 1, TILE - 2, 6);
          ctx.fillStyle = th.wallAcc;
          ctx.fillRect(x + 2, y + 2, TILE - 4, 2);
          // Wall top highlight
          ctx.fillStyle = 'rgba(255,255,255,0.07)';
          ctx.fillRect(x, y, TILE, 1);
          // Wall shadow at bottom of wall face
          ctx.fillStyle = 'rgba(0,0,0,0.6)';
          ctx.fillRect(x, y + 7, TILE, 2);
          // Stone texture pixels on wall face
          for (let bk = 0; bk < 3; bk++) {
            const hb = ((c * 131 + bk * 37) ^ r * 97) & 0xff;
            if (hb < 40) {
              ctx.fillStyle = 'rgba(0,0,0,0.35)';
              ctx.fillRect(x + 4 + (hb & 0xf) * 2, y + 2 + (hb >> 4 & 1) * 2, 4, 2);
            }
          }
          // Rune on wall
          if (th.runes && ((h1 & 0x1f) === 0)) {
            ctx.fillStyle = th.lavaHot;
            ctx.globalAlpha = 0.6;
            ctx.fillRect(x + 16, y + 2, 2, 5);
            ctx.fillRect(x + 13, y + 4, 8, 1);
            ctx.globalAlpha = 1;
          }
          // Skull on wall
          if (th.skulls && ((h2 & 0x1f) === 0)) {
            ctx.fillStyle = '#c8c0b0';
            ctx.fillRect(x + 17, y + 1, 6, 5);
            ctx.fillStyle = '#0a0a0a';
            ctx.fillRect(x + 18, y + 2, 2, 2);
            ctx.fillRect(x + 21, y + 2, 2, 2);
            ctx.fillStyle = '#c8c0b0';
            ctx.fillRect(x + 19, y + 5, 4, 2);
          }
          // Chain draping from wall
          if (th.chains && ((h1 & 0x3f) < 5)) {
            ctx.fillStyle = '#4a3c28';
            ctx.fillRect(x + 10, y + 6, 2, 4);
            ctx.fillRect(x + 9, y + 8, 4, 2);
            ctx.fillRect(x + 11, y + 10, 2, 3);
          }
        }
      }
    }
  }

  // Draw an organic, natural-looking transition between floor and lava:
  // 1) "erode" small irregular bites out of the floor tile edges so the lava
  //    peeks in unevenly (breaks the straight grid line look)
  // 2) a soft warm glow straddling the boundary (replaces the old hard dashed line)
  //
  // This overlay is fully static for the lifetime of a dungeon layout, so it's
  // baked once (buildFloorEdgeCache, called right after the layout is generated)
  // and just blitted here — previously this ran the full erosion+glow computation
  // (arcs, gradients, composite-mode switches) for every visible tile, every
  // single frame, which was the main cause of the reported stutter/lag.
  drawFloorEdges(ctx) {
    // Simple pixel-art shadow: dark strip on south/east edges of floor tiles that border lava
    if (!this.tileGrid) return;
    const { c0, r0, c1, r1 } = this.visibleTileBounds();
    ctx.fillStyle = 'rgba(0,0,0,0.55)';
    for (let r = r0; r < r1; r++) {
      for (let c = c0; c < c1; c++) {
        if (!this.isFloor(c, r)) continue;
        const x = c * TILE, y = r * TILE;
        if (!this.isFloor(c, r + 1)) ctx.fillRect(x, y + TILE - 3, TILE, 3);
        if (!this.isFloor(c + 1, r)) ctx.fillRect(x + TILE - 3, y, 3, TILE);
      }
    }
  }

  // Actual erosion+glow painter, parameterized over a tile range so it can be used
  // both to build the full-map cache and (as a fallback) to paint on-the-fly.
  paintFloorEdges(ctx, c0, r0, c1, r1) {
    ctx.save();

    // Pass 1: organic erosion (destination-out carves holes revealing the lava beneath)
    ctx.globalCompositeOperation = 'destination-out';
    ctx.fillStyle = '#000';
    for (let r = r0; r < r1; r++) {
      for (let c = c0; c < c1; c++) {
        if (this.tileGrid[r][c] !== 1) continue;
        if (!this.isFloor(c, r - 1)) this.erodeEdge(ctx, c, r, 'top');
        if (!this.isFloor(c, r + 1)) this.erodeEdge(ctx, c, r, 'bottom');
        if (!this.isFloor(c - 1, r)) this.erodeEdge(ctx, c, r, 'left');
        if (!this.isFloor(c + 1, r)) this.erodeEdge(ctx, c, r, 'right');
      }
    }

    // Pass 2: soft warm glow bleeding across the boundary on both sides
    ctx.globalCompositeOperation = 'lighter';
    for (let r = r0; r < r1; r++) {
      for (let c = c0; c < c1; c++) {
        if (this.tileGrid[r][c] !== 1) continue;
        const x = c * TILE, y = r * TILE;
        if (!this.isFloor(c, r - 1)) this.glowEdge(ctx, x, y, TILE, 0, 0, -1);
        if (!this.isFloor(c, r + 1)) this.glowEdge(ctx, x, y + TILE, TILE, 0, 0, 1);
        if (!this.isFloor(c - 1, r)) this.glowEdge(ctx, x, y, 0, TILE, -1, 0);
        if (!this.isFloor(c + 1, r)) this.glowEdge(ctx, x + TILE, y, 0, TILE, 1, 0);
      }
    }
    ctx.globalCompositeOperation = 'source-over';
    ctx.restore();
  }

  // Carve a few pseudo-random circular bites out of one edge of a floor tile,
  // deterministic per tile+direction so it stays stable frame to frame.
  erodeEdge(ctx, c, r, dir) {
    const x = c * TILE, y = r * TILE;
    let x0, y0, x1, y1, nx, ny;
    if (dir === 'top') { x0 = x; y0 = y; x1 = x + TILE; y1 = y; nx = 0; ny = -1; }
    else if (dir === 'bottom') { x0 = x; y0 = y + TILE; x1 = x + TILE; y1 = y + TILE; nx = 0; ny = 1; }
    else if (dir === 'left') { x0 = x; y0 = y; x1 = x; y1 = y + TILE; nx = -1; ny = 0; }
    else { x0 = x + TILE; y0 = y; x1 = x + TILE; y1 = y + TILE; nx = 1; ny = 0; }
    const dirSalt = dir.charCodeAt(0) * 7 + dir.charCodeAt(1) * 3;
    const bites = 3;
    for (let i = 0; i < bites; i++) {
      const h = (c * 911 + r * 577 + i * 131 + dirSalt) & 0xff;
      const t = (i + 0.5) / bites + ((h % 17) - 8) / 220;
      const px = x0 + (x1 - x0) * t;
      const py = y0 + (y1 - y0) * t;
      const rad = 4 + (h % 7);
      ctx.beginPath();
      ctx.arc(px + nx * rad * 0.35, py + ny * rad * 0.35, rad, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // Soft glow gradient straddling a border segment (x,y,w,h define the segment;
  // nx,ny point outward from the floor tile into the lava).
  glowEdge(ctx, x, y, w, h, nx, ny) {
    const glowSize = 22;
    let grad;
    if (nx !== 0) grad = ctx.createLinearGradient(x - nx * glowSize, y, x + nx * glowSize, y);
    else grad = ctx.createLinearGradient(x, y - ny * glowSize, x, y + ny * glowSize);
    grad.addColorStop(0, 'rgba(255,120,30,0)');
    grad.addColorStop(0.5, 'rgba(255,140,40,0.55)');
    grad.addColorStop(1, 'rgba(255,120,30,0)');
    ctx.fillStyle = grad;
    if (nx !== 0) ctx.fillRect(x - glowSize, y, glowSize * 2, h);
    else ctx.fillRect(x, y - glowSize, w, glowSize * 2);
  }

  drawBraziers(ctx) {
    const camX = this.camera.x, camY = this.camera.y;
    for (const b of this.braziers) {
      if (b.x < camX - 40 || b.x > camX + W + 40 || b.y < camY - 40 || b.y > camY + H + 40) continue;
      const flick = 1 + Math.sin(b.t * 8) * 0.15 + Math.sin(b.t * 15.3) * 0.08;
      // Warm floor glow (baked sprite, scaled for flicker — avoids per-frame gradient creation)
      if (this._brazierGlowSprite) {
        const gs = 148 * flick;
        ctx.drawImage(this._brazierGlowSprite, b.x - gs / 2, b.y - gs / 2, gs, gs);
      } else {
        const grad = ctx.createRadialGradient(b.x, b.y, 4, b.x, b.y, 60 * flick);
        grad.addColorStop(0, 'rgba(255, 195, 90, 0.68)');
        grad.addColorStop(1, 'rgba(255, 100, 20, 0)');
        ctx.fillStyle = grad;
        ctx.fillRect(b.x - 60, b.y - 60, 120, 120);
      }
      // Brazier base
      ctx.fillStyle = '#3a1a0a';
      ctx.fillRect(b.x - 8, b.y - 2, 16, 10);
      ctx.fillStyle = '#5a2a10';
      ctx.fillRect(b.x - 10, b.y - 6, 20, 4);
      // Flame
      ctx.fillStyle = '#ff8020';
      ctx.beginPath();
      ctx.moveTo(b.x - 6, b.y - 6);
      ctx.quadraticCurveTo(b.x, b.y - 22 * flick, b.x + 6, b.y - 6);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#ffd060';
      ctx.beginPath();
      ctx.moveTo(b.x - 3, b.y - 6);
      ctx.quadraticCurveTo(b.x, b.y - 14 * flick, b.x + 3, b.y - 6);
      ctx.closePath();
      ctx.fill();
    }
  }

  drawPlayer(ctx) {
    const p = this.player;
    if (p.dead) return;

    // Luz ambiente que acompanha o jogador (soma aditiva, não substitui nada
    // embaixo) — dá a sensação de que ele carrega uma fonte de luz própria
    // pela masmorra escura.
    if (this._playerGlowSprite) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      const gs = 220;
      ctx.drawImage(this._playerGlowSprite, p.x - gs / 2, p.y - gs / 2, gs, gs);
      ctx.restore();
    }

    ctx.fillStyle = 'rgba(0,0,0,0.4)';
    ctx.beginPath(); ctx.ellipse(p.x, p.y + 2, 11, 4, 0, 0, Math.PI * 2); ctx.fill();

    if (p.invulnTime > 0) {
      const t = (Date.now() / 100) % (Math.PI * 2);
      ctx.strokeStyle = '#80c0ff'; ctx.lineWidth = 2; ctx.globalAlpha = 0.7;
      ctx.beginPath(); ctx.arc(p.x, p.y, 26 + Math.sin(t) * 3, 0, Math.PI * 2); ctx.stroke();
      ctx.globalAlpha = 1;
    }

    let frame;
    if (p.dashTime > 0) {
      const idx = Math.min(SPR.dash.length - 1, Math.floor((1 - p.dashTime / 0.22) * SPR.dash.length));
      frame = SPR.dash[idx];
    } else if (p.attack2Anim > 0) {
      const idx = Math.min(SPR.attack2.length - 1, Math.floor((1 - p.attack2Anim / 0.32) * SPR.attack2.length));
      frame = SPR.attack2[idx];
    } else if (p.attackAnim > 0) {
      const idx = Math.min(SPR.attack1.length - 1, Math.floor((1 - p.attackAnim / 0.25) * SPR.attack1.length));
      frame = SPR.attack1[idx];
    } else if (p.moving) frame = SPR.walk[p.animFrame % SPR.walk.length];
    else frame = SPR.idle[p.animFrame % SPR.idle.length];

    // Renderiza sempre em 48px de altura (tamanho fixo pedido), largura
    // escalada proporcionalmente para nunca esticar/achatar o sprite.
    // Ancorado pelo pivô fixo (centro do corpo / pés), não pelo centro da
    // célula — isso é o que mantém o personagem parado sobre a própria
    // sombra e evita o salto ao espelhar (virar de direção).
    const scale = SPR.renderSize / SPR.cellH;
    const renderW = SPR.cellW * scale;
    const renderH = SPR.cellH * scale;
    const pivotX = SPR.pivotX * scale;
    const pivotY = SPR.pivotY * scale;
    const sx = frame.x * SPR.cellW;
    const sy = frame.y * SPR.cellH;

    ctx.save();
    ctx.translate(p.x, p.y);
    if (p.flipX) ctx.scale(-1, 1);
    if (p.dashTime > 0) {
      ctx.globalAlpha = 0.85;
    }
    if (p.hurtFlash > 0) {
      ctx.filter = 'brightness(2) sepia(1) hue-rotate(-30deg) saturate(5)';
    } else if (p.classId === 'undead') {
      ctx.filter = 'hue-rotate(33deg) saturate(1.3)';
    } else if (p.classId === 'vampire') {
      ctx.filter = 'hue-rotate(-87deg) saturate(1.5) brightness(1.05)';
    } else if (p.classId === 'ghost') {
      ctx.filter = 'hue-rotate(164deg) saturate(1.25) brightness(1.15)';
      ctx.globalAlpha = 0.7;
    }
    if (this.spriteImg) {
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(this.spriteImg, sx, sy, SPR.cellW, SPR.cellH, -pivotX, -pivotY, renderW, renderH);
    } else {
      ctx.fillStyle = p.classColor || '#c01818';
      ctx.fillRect(-12, -20, 24, 32);
    }
    ctx.restore();

    if (p.attackAnim > 0) {
      const t = 1 - p.attackAnim / 0.25;
      ctx.save();
      ctx.translate(p.x, p.y); ctx.rotate(p.facing);
      ctx.strokeStyle = '#fff0c0'; ctx.lineWidth = 4;
      ctx.globalAlpha = (1 - t) * 0.9;
      ctx.beginPath();
      const arc = Math.PI / 2;
      ctx.arc(0, 0, p.attackRange, -arc + t * arc, arc - t * arc); ctx.stroke();
      ctx.lineWidth = 2; ctx.globalAlpha *= 0.6;
      ctx.beginPath();
      ctx.arc(0, 0, p.attackRange - 10, -arc + t * arc, arc - t * arc); ctx.stroke();
      ctx.restore();
    }

    if (p.attack2Anim > 0) {
      const t = 1 - p.attack2Anim / 0.32;
      const range2 = p.attackRange * 1.15;
      ctx.save();
      ctx.translate(p.x, p.y); ctx.rotate(p.facing);
      ctx.strokeStyle = '#ffd0a0'; ctx.lineWidth = 5;
      ctx.globalAlpha = (1 - t) * 0.95;
      ctx.beginPath();
      const arc = Math.PI / 3.2;
      ctx.arc(0, 0, range2, -arc + t * arc, arc - t * arc); ctx.stroke();
      ctx.lineWidth = 2; ctx.globalAlpha *= 0.6;
      ctx.beginPath();
      ctx.arc(0, 0, range2 - 12, -arc + t * arc, arc - t * arc); ctx.stroke();
      ctx.restore();
    }
  }

  drawEnemy(ctx, e) {
    ctx.fillStyle = 'rgba(0,0,0,0.4)';
    ctx.beginPath();
    ctx.ellipse(e.x, e.y + e.radius - 2, e.radius * 0.8, e.radius * 0.25, 0, 0, Math.PI * 2);
    ctx.fill();

    if (e.isBoss) { this.drawBoss(ctx, e); return; }

    const sprites = this.monsterSprites[e.sprite];
    if (sprites && sprites.idle && sprites.walk && sprites.attack) {
      this.drawEnemySprite(ctx, e, sprites);
    } else {
      this.drawEnemyFallback(ctx, e);
    }

    if (e.hp < e.hpMax) {
      const w = e.radius * 2;
      ctx.fillStyle = '#1a0303';
      ctx.fillRect(e.x - w/2, e.y - e.radius - 12, w, 4);
      ctx.fillStyle = '#ff3030';
      ctx.fillRect(e.x - w/2, e.y - e.radius - 12, w * (e.hp / e.hpMax), 4);
    }
  }

  // Draws a monster using its animated spritesheet (idle/walk/attack), recolored
  // per-archetype via a canvas filter so the two base creature packs read as 5 distinct enemies.
  drawEnemySprite(ctx, e, sprites) {
    const bob = Math.sin(e.animT * 5) * 1.5;
    const cfg = MONSTER_SPRITES[e.sprite];
    let animName, frames, fps;
    if (e.attackAnim > 0) { animName = 'attack'; frames = cfg.attack.frames; fps = frames / 0.3; }
    else if (e.moving) { animName = 'walk'; frames = cfg.walk.frames; fps = 8; }
    else { animName = 'idle'; frames = cfg.idle.frames; fps = 5; }
    if (!sprites[animName]) { this.drawEnemyFallback(ctx, e); return; }

    // Use the pre-recolored (baked) spritesheet instead of applying ctx.filter
    // every frame — this was the biggest single cost in the render loop once
    // several enemies were visible at once.
    const img = this.bakeMonsterFrame(e, animName, sprites) || sprites[animName];

    const frame = Math.floor(e.animT * fps) % frames;
    const cell = MONSTER_CELL;
    const size = e.radius * (e.spriteScale || 3.4);

    ctx.save();
    ctx.translate(e.x, e.y + bob);
    ctx.scale(e.facing || 1, 1);
    ctx.drawImage(img, frame * cell, 0, cell, cell, -size / 2, -size + e.radius * 0.5, size, size);
    ctx.restore();
  }

  drawEnemyFallback(ctx, e) {
    const bob = Math.sin(e.animT * 5) * 2;
    ctx.save();
    ctx.translate(e.x, e.y + bob);
    const r = e.radius;
    ctx.fillStyle = '#1a0202';
    ctx.beginPath();
    ctx.moveTo(-r * 0.4, -r * 0.9); ctx.lineTo(-r * 0.7, -r * 1.5); ctx.lineTo(-r * 0.2, -r * 1.0); ctx.closePath(); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(r * 0.4, -r * 0.9); ctx.lineTo(r * 0.7, -r * 1.5); ctx.lineTo(r * 0.2, -r * 1.0); ctx.closePath(); ctx.fill();
    ctx.fillStyle = e.color;
    ctx.beginPath();
    ctx.moveTo(-r, r); ctx.lineTo(-r * 0.6, -r * 0.6); ctx.lineTo(0, -r);
    ctx.lineTo(r * 0.6, -r * 0.6); ctx.lineTo(r, r);
    ctx.lineTo(r * 0.7, r * 1.1); ctx.lineTo(-r * 0.7, r * 1.1); ctx.closePath(); ctx.fill();
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    ctx.beginPath();
    ctx.ellipse(0, -r * 0.3, r * 0.55, r * 0.45, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = e.eye;
    ctx.shadowColor = e.eye; ctx.shadowBlur = 6;
    ctx.fillRect(-r * 0.35, -r * 0.35, 4, 4);
    ctx.fillRect(r * 0.2, -r * 0.35, 4, 4);
    ctx.shadowBlur = 0;
    if (e.type === 'orc' || e.type === 'demon' || e.type === 'slime') {
      ctx.fillStyle = '#fff0c0';
      for (let i = -2; i <= 2; i++) ctx.fillRect(i * 3 - 1, 0, 2, 4);
    }
    ctx.restore();
  }

  drawBoss(ctx, e) {
    const r = e.radius;
    const bob = Math.sin(e.animT * 2) * 3;
    ctx.save();
    ctx.translate(e.x, e.y + bob);
    ctx.fillStyle = '#0a0000';
    ctx.beginPath();
    ctx.moveTo(-r * 0.6, -r * 0.7); ctx.lineTo(-r * 1.1, -r * 1.8); ctx.lineTo(-r * 0.3, -r * 1.0); ctx.closePath(); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(r * 0.6, -r * 0.7); ctx.lineTo(r * 1.1, -r * 1.8); ctx.lineTo(r * 0.3, -r * 1.0); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#180202';
    ctx.beginPath();
    ctx.moveTo(-r * 0.5, -r * 0.2); ctx.lineTo(-r * 2.2, -r * 0.6); ctx.lineTo(-r * 2.0, r * 0.6); ctx.lineTo(-r * 0.5, r * 0.4); ctx.closePath(); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(r * 0.5, -r * 0.2); ctx.lineTo(r * 2.2, -r * 0.6); ctx.lineTo(r * 2.0, r * 0.6); ctx.lineTo(r * 0.5, r * 0.4); ctx.closePath(); ctx.fill();
    const grad = ctx.createRadialGradient(0, 0, r * 0.2, 0, 0, r * 1.2);
    grad.addColorStop(0, '#5a0606'); grad.addColorStop(1, '#1a0202');
    ctx.fillStyle = grad;
    ctx.beginPath(); ctx.ellipse(0, 0, r * 1.0, r * 1.2, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#ff2000'; ctx.shadowColor = '#ff4000'; ctx.shadowBlur = 20;
    ctx.fillRect(-r * 0.4, -r * 0.25, 10, 10);
    ctx.fillRect(r * 0.3, -r * 0.25, 10, 10);
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#fff0c0';
    for (let i = -3; i <= 3; i++) ctx.fillRect(i * 8 - 2, r * 0.25, 5, 9);
    ctx.restore();
  }

  // Boss HP bar is drawn in screen space so it stays fixed at top
  drawBossHpOverlay(ctx) {
    const boss = this.enemies.find(e => e.isBoss);
    if (!boss) return;
    const w = Math.min(W * 0.6, 800);
    const x = W / 2 - w / 2;
    const y = 60;
    ctx.save();
    ctx.fillStyle = '#1a0303'; ctx.fillRect(x - 2, y - 2, w + 4, 22);
    ctx.fillStyle = '#3a0606'; ctx.fillRect(x, y, w, 18);
    ctx.fillStyle = '#c01010'; ctx.fillRect(x, y, w * (boss.hp / boss.hpMax), 18);
    ctx.font = "bold 20px 'Cinzel', serif"; ctx.textAlign = 'center';
    ctx.fillStyle = '#ffd9a3';
    ctx.fillText(boss.name.toUpperCase(), W / 2, y - 8);
    ctx.restore();
  }

  // Cada NPC tem uma silhueta/cor própria, para que nenhum se pareça com o
  // outro (puramente visual — não altera hitbox, IA nem qualquer mecânica).
  drawNpc(ctx, npc) {
    npc.bobT += 0.016;
    const bob = Math.sin(npc.bobT * 2) * 3;
    ctx.save();
    ctx.translate(npc.x, npc.y + bob);

    if (npc.id === 'intro' && this.npcIntroSprite) {
      // Garota fofa (franja branca): spritesheet 6 quadros, loop fluído da
      // animação "bebendo", sempre virada de frente (south) para o jogador.
      npc.animT = (npc.animT || 0) + 0.016;
      const cell = 60;
      const frameCount = 6;
      const fps = 8;
      const frame = Math.floor(npc.animT * fps) % frameCount;
      const renderH = 64;
      const renderW = renderH; // célula quadrada, sem distorção
      ctx.fillStyle = 'rgba(0,0,0,0.35)';
      ctx.beginPath(); ctx.ellipse(0, 20, 16, 6, 0, 0, Math.PI * 2); ctx.fill();
      ctx.drawImage(
        this.npcIntroSprite,
        frame * cell, 0, cell, cell,
        -renderW / 2, -renderH + 14, renderW, renderH,
      );
    } else if (npc.id === 'intro') {
      // Sobrevivente: figura encapuzada, curvada, tons de cinza-esverdeado —
      // alguém desgastado, quase sem forma.
      ctx.fillStyle = 'rgba(140,160,120,0.18)';
      ctx.beginPath(); ctx.arc(0, 2, 28, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#6f7a5c'; ctx.globalAlpha = 0.9;
      ctx.beginPath();
      ctx.moveTo(-12, 16); ctx.lineTo(-16, -4);
      ctx.quadraticCurveTo(-6, -20, 4, -18);
      ctx.quadraticCurveTo(14, -14, 12, 2);
      ctx.lineTo(10, 16); ctx.lineTo(0, 12); ctx.lineTo(-6, 16);
      ctx.closePath(); ctx.fill();
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#050805';
      ctx.beginPath(); ctx.ellipse(-2, -6, 6, 4, 0.3, 0, Math.PI * 2); ctx.fill();
    } else {
      // Alma Perdida (padrão): silhueta espectral azul-clara, mais alta e reta.
      ctx.fillStyle = 'rgba(120,180,255,0.2)';
      ctx.beginPath(); ctx.arc(0, 0, 30, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#a0c8ff'; ctx.globalAlpha = 0.85;
      ctx.beginPath();
      ctx.moveTo(-14, 14); ctx.lineTo(-14, -8);
      ctx.quadraticCurveTo(0, -22, 14, -8);
      ctx.lineTo(14, 14); ctx.lineTo(8, 10); ctx.lineTo(0, 14);
      ctx.lineTo(-8, 10); ctx.closePath(); ctx.fill();
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#000';
      ctx.fillRect(-6, -8, 3, 4); ctx.fillRect(3, -8, 3, 4);
    }
    ctx.restore();

    const p = this.player;
    if (dist(p, npc) < 70) {
      ctx.font = "16px 'VT323', monospace"; ctx.textAlign = 'center';
      ctx.fillStyle = '#fff';
      ctx.fillText('[ E ] FALAR', npc.x, npc.y - 32);
    }
    ctx.font = "14px 'Cinzel', serif"; ctx.textAlign = 'center';
    ctx.fillStyle = npc.id === 'intro' ? '#bfe0ff' : '#a0c8ff';
    ctx.fillText(npc.name, npc.x, npc.y - 22);
  }

  // Portal que surge após a fase ser limpa — o jogador precisa se aproximar e
  // interagir para avançar de andar (a transição / Altar só ocorre aí).
  drawPortal(ctx, portal) {
    ctx.save();
    ctx.translate(portal.x, portal.y);
    const spin = portal.t * 1.4;
    const pulse = 0.85 + Math.sin(portal.t * 3) * 0.15;

    ctx.fillStyle = 'rgba(160, 40, 255, 0.16)';
    ctx.beginPath(); ctx.arc(0, 0, 60 * pulse, 0, Math.PI * 2); ctx.fill();

    for (let ring = 0; ring < 3; ring++) {
      ctx.save();
      ctx.rotate(spin + ring * (Math.PI / 3));
      ctx.strokeStyle = ring % 2 === 0 ? '#c060ff' : '#6020a0';
      ctx.globalAlpha = 0.7 - ring * 0.15;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.ellipse(0, 0, (26 - ring * 4) * pulse, (34 - ring * 5) * pulse, 0, 0, Math.PI * 1.5);
      ctx.stroke();
      ctx.restore();
    }
    ctx.globalAlpha = 1;
    ctx.fillStyle = '#1a0330';
    ctx.beginPath(); ctx.arc(0, 0, 14, 0, Math.PI * 2); ctx.fill();

    ctx.restore();

    const p = this.player;
    ctx.font = "14px 'Cinzel', serif"; ctx.textAlign = 'center';
    ctx.fillStyle = '#c99bff';
    ctx.fillText('???', portal.x, portal.y - 46);
    if (dist(p, portal) < 70) {
      ctx.font = "16px 'VT323', monospace";
      ctx.fillStyle = '#fff';
      ctx.fillText('[ E ] ENTRAR', portal.x, portal.y - 62);
    }
  }

  drawProjectile(ctx, pr) {
    ctx.save();
    ctx.fillStyle = pr.color; ctx.shadowColor = pr.color; ctx.shadowBlur = 10;
    ctx.beginPath(); ctx.arc(pr.x, pr.y, pr.r, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }
}
