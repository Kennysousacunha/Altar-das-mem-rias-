import React, { useMemo, useState } from 'react';
import {
  SKILLS, PATHS, ORIGIN_NODE, FRAGMENT_COST,
  skillsForPathTier, canUnlock,
} from '@/game/MemoryTree';

// ============================================================================
// ALTAR DAS MEMÓRIAS — constelação
// ----------------------------------------------------------------------------
// Renderizada em SVG puro (leve, sem efeitos pesados, compatível com
// celulares). Cada habilidade é um nó ligado por linhas que mostram a
// progressão dos 3 caminhos (Guerra, Vigília, Cinzas), cada um com Tier I →
// II → III. Toda a REGRA de desbloqueio vive em MemoryTree.js; este
// componente só apresenta e delega cliques para o pai (InfernoGame.jsx).
// ============================================================================

const VIEW_W = 1200;
const VIEW_H = 600;
const COL_X = { guerra: 190, vigilia: 600, cinzas: 1010 };
const ROW = { origin: 30, branch: 96, tier1: 180, anchor12: 246, tier2: 320, anchor23: 384, tier3 : 460 };
const TIER1_OFFSETS = [-130, -65, 0, 65, 130];
const TIER2_OFFSETS = [-95, -32, 32, 95];

function buildLayout() {
  const nodes = {};
  for (const pathId of Object.keys(PATHS)) {
    const colX = COL_X[pathId];
    skillsForPathTier(pathId, 1).forEach((s, i) => {
      nodes[s.id] = { ...s, x: colX + TIER1_OFFSETS[i], y: ROW.tier1 };
    });
    skillsForPathTier(pathId, 2).forEach((s, i) => {
      nodes[s.id] = { ...s, x: colX + TIER2_OFFSETS[i], y: ROW.tier2 };
    });
    skillsForPathTier(pathId, 3).forEach((s) => {
      nodes[s.id] = { ...s, x: colX, y: ROW.tier3 };
    });
  }
  return nodes;
}

export default function ConstellationScreen({ fragments, unlocked, onUnlock, onReset, onBack }) {
  const layout = useMemo(buildLayout, []);
  const unlockedSet = useMemo(() => new Set(unlocked || []), [unlocked]);
  const [selectedId, setSelectedId] = useState(null);
  const selected = selectedId ? layout[selectedId] : null;

  const isUnlocked = (id) => unlockedSet.has(id);
  const isAvailable = (skill) => canUnlock(skill, unlockedSet);

  const handleUnlockClick = () => {
    if (!selected) return;
    if (isUnlocked(selected.id)) return;
    if (fragments < FRAGMENT_COST) return;
    if (!isAvailable(selected)) return;
    onUnlock(selected.id);
  };

  // Segmentos: origem -> ponto de ramificação -> Tier I -> âncora -> Tier II -> âncora -> Tier III
  const segments = [];
  for (const pathId of Object.keys(PATHS)) {
    const colX = COL_X[pathId];
    segments.push({ key: `${pathId}-origin`, x1: VIEW_W / 2, y1: ROW.origin, x2: colX, y2: ROW.branch, lit: true });
    for (const s of skillsForPathTier(pathId, 1)) {
      segments.push({ key: `${s.id}-branch`, x1: colX, y1: ROW.branch, x2: layout[s.id].x, y2: ROW.tier1, lit: isUnlocked(s.id) });
      segments.push({ key: `${s.id}-anchor12`, x1: layout[s.id].x, y1: ROW.tier1, x2: colX, y2: ROW.anchor12, lit: isUnlocked(s.id) });
    }
    for (const s of skillsForPathTier(pathId, 2)) {
      segments.push({ key: `${s.id}-anchor12b`, x1: colX, y1: ROW.anchor12, x2: layout[s.id].x, y2: ROW.tier2, lit: isUnlocked(s.id) });
      segments.push({ key: `${s.id}-anchor23`, x1: layout[s.id].x, y1: ROW.tier2, x2: colX, y2: ROW.anchor23, lit: isUnlocked(s.id) });
    }
    for (const s of skillsForPathTier(pathId, 3)) {
      segments.push({ key: `${s.id}-anchor23b`, x1: colX, y1: ROW.anchor23, x2: layout[s.id].x, y2: ROW.tier3, lit: isUnlocked(s.id) });
    }
  }

  return (
    <div className="screen constellation-screen" data-testid="constellation-screen">
      <h2 className="title" style={{ fontSize: 40 }}>ALTAR DAS MEMÓRIAS</h2>
      <div className="subtitle constellation-fragments" data-testid="constellation-fragments">
        <span className="altar-fragment-icon">◆</span> Fragmentos: <strong>{fragments}</strong>
      </div>

      <div className="constellation-body">
        <div className="constellation-wrap">
          <svg
            className="constellation-svg"
            viewBox={`0 0 ${VIEW_W} ${VIEW_H}`}
            preserveAspectRatio="xMidYMin meet"
            role="img"
            aria-label="Altar das Memórias"
          >
            {segments.map((seg) => (
              <line
                key={seg.key}
                x1={seg.x1} y1={seg.y1} x2={seg.x2} y2={seg.y2}
                className={`const-line ${seg.lit ? 'lit' : ''}`}
              />
            ))}

            {/* Nó de origem — decorativo, sempre "aceso" */}
            <g className="const-node origin">
              <circle cx={VIEW_W / 2} cy={ROW.origin} r={20} />
              <text x={VIEW_W / 2} y={ROW.origin + 7} textAnchor="middle" className="const-icon">{ORIGIN_NODE.symbol}</text>
            </g>

            {Object.entries(PATHS).map(([pathId, meta]) => (
              <g key={pathId} className="const-path-header">
                <text x={COL_X[pathId]} y={ROW.branch - 30} textAnchor="middle" className="const-path-symbol">{meta.symbol}</text>
                <text x={COL_X[pathId]} y={ROW.branch - 12} textAnchor="middle" className="const-path-name">{meta.name}</text>
              </g>
            ))}

            {SKILLS.map((s) => {
              const pos = layout[s.id];
              const unlockedNode = isUnlocked(s.id);
              const available = !unlockedNode && isAvailable(s);
              const r = s.tier === 3 ? 34 : s.tier === 2 ? 29 : 26;
              const cls = [
                'const-node',
                unlockedNode ? 'unlocked' : 'locked',
                available ? 'available' : '',
                selectedId === s.id ? 'selected' : '',
                `path-${s.path}`,
              ].join(' ').trim();
              return (
                <g
                  key={s.id}
                  className={cls}
                  transform={`translate(${pos.x}, ${pos.y})`}
                  onClick={() => setSelectedId((cur) => (cur === s.id ? null : s.id))}
                  data-testid={`memory-node-${s.id}`}
                >
                  <circle r={r} />
                  <text y={r * 0.32} textAnchor="middle" className="const-icon">{s.icon}</text>
                </g>
              );
            })}
          </svg>
        </div>

        {selected && (
          <div className="constellation-panel" data-testid="constellation-panel">
            <div className="constellation-panel-title">
              <span className="const-icon-inline">{selected.icon}</span> {selected.name}
              <span className="constellation-tier-tag">Tier {selected.tier} • {PATHS[selected.path].name}</span>
            </div>
            <div className="constellation-panel-desc">{selected.desc}</div>
            {isUnlocked(selected.id) ? (
              <div className="constellation-status unlocked-tag">Desbloqueada</div>
            ) : (
              <>
                {!isAvailable(selected) && (
                  <div className="constellation-status locked-tag">
                    Requer 2 habilidades desbloqueadas no Tier {selected.tier - 1} de {PATHS[selected.path].name}.
                  </div>
                )}
                <button
                  className="menu-btn"
                  disabled={!isAvailable(selected) || fragments < FRAGMENT_COST}
                  onClick={handleUnlockClick}
                  data-testid="unlock-skill-btn"
                >
                  DESBLOQUEAR ({FRAGMENT_COST} Fragmento)
                </button>
              </>
            )}
          </div>
        )}
      </div>

      <div className="constellation-footer">
        <button className="menu-btn danger" onClick={onReset} data-testid="reset-memory-btn">
          REDEFINIR MEMÓRIAS
        </button>
        <button className="menu-btn" onClick={onBack} data-testid="constellation-back-btn">
          VOLTAR
        </button>
      </div>
    </div>
  );
}
