import React from 'react';

// ============================================================================
// ALTAR DAS MEMÓRIAS
// ----------------------------------------------------------------------------
// Nova tela de transição entre fases, no lugar do antigo portal. Puramente de
// apresentação: toda a lógica (fragmentos, build, avanço de fase) vive em
// InfernoGame.jsx / Engine.js / MemorySave.js.
// ============================================================================
export default function AltarScreen({ fragments, onOpenTree, onContinue }) {
  return (
    <div className="screen altar-screen" data-testid="altar-screen">
      <div className="altar-glow" aria-hidden="true" />
      <h2 className="title altar-title">O ALTAR DAS MEMÓRIAS</h2>
      <div className="subtitle altar-subtitle">Uma lembrança desperta.</div>

      <div className="altar-fragments" data-testid="altar-fragments">
        <span className="altar-fragment-icon">◆</span>
        Fragmentos disponíveis: <strong>{fragments}</strong>
      </div>

      <div className="altar-buttons">
        <button className="menu-btn" onClick={onOpenTree} data-testid="altar-memories-btn">
          MEMÓRIAS
        </button>
        <button className="menu-btn" onClick={onContinue} data-testid="altar-continue-btn">
          CONTINUAR
        </button>
      </div>
    </div>
  );
}
