import "@/App.css";
import { useEffect,useState } from "react";
import InfernoGame from "@/game/InfernoGame";
import { ErrorBoundary } from "@/ErrorBoundary";

function App() {
 const [landscape,setLandscape]=useState(window.innerWidth>window.innerHeight);
 useEffect(()=>{
 const upd=()=>{
  setLandscape(window.innerWidth>window.innerHeight);
  if(document.fullscreenElement && screen.orientation?.lock){
    screen.orientation.lock("landscape").catch(()=>{});
  }
 };
 window.addEventListener("resize",upd);
 window.addEventListener("orientationchange",upd);
 upd();
 return ()=>{window.removeEventListener("resize",upd);window.removeEventListener("orientationchange",upd);}
 },[]);
 // IMPORTANTE: o InfernoGame permanece SEMPRE montado (nunca é desmontado
 // por causa de orientação). Antes, quando !landscape, o componente inteiro
 // era substituído pelo aviso de rotação — isso destruía e recriava TODO o
 // estado do jogo (tela atual, engine, loop de animação) a cada soluço
 // passageiro de "innerWidth vs innerHeight" (comum no Chrome Android ao
 // mostrar/esconder a barra de endereço, teclado virtual, etc.), podendo
 // deixar o jogo aparentemente travado. Agora só SOBREPOMOS o aviso por cima
 // (.rotate-overlay já é position:fixed + z-index altíssimo, cobre tudo).
 return (
  <div className="App">
   <ErrorBoundary>
    <InfernoGame/>
   </ErrorBoundary>
   {!landscape && (
    <div className="rotate-overlay">
     <div><div className="rotate-icon">📱↻</div><h1>Gire o dispositivo</h1><p>Este jogo funciona apenas no modo horizontal.</p></div>
    </div>
   )}
  </div>
 );
}
export default App;
