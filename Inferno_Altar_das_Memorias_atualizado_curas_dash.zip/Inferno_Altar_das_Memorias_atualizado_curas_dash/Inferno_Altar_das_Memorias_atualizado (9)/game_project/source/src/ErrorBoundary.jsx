import React from 'react';

// ============================================================================
// Rede de segurança contra erros de RENDER (React) não tratados.
// ----------------------------------------------------------------------------
// Sem isso, um erro lançado durante o render de qualquer componente (incluindo
// o InfernoGame inteiro) derruba a árvore React inteira e, dependendo do
// momento, pode deixar o jogador numa tela em branco ou com um estado
// inconsistente/preso, sem qualquer forma de se recuperar a não ser recarregar
// manualmente a página (o que muitos jogadores não tentam fazer sozinhos).
// Com este boundary, qualquer erro assim vira uma tela de recuperação simples
// com um botão "RECARREGAR", em vez de um travamento silencioso.
// ============================================================================
export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error, info) {
    // eslint-disable-next-line no-console
    console.error('[ErrorBoundary] erro de render capturado:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="rotate-overlay">
          <div>
            <div className="rotate-icon">⚠</div>
            <h1>Algo deu errado</h1>
            <p>Toque no botão abaixo para recarregar o jogo. Seu progresso salvo (XP, nível, Fragmentos e habilidades do Altar) não é afetado.</p>
            <button
              className="menu-btn"
              style={{ marginTop: 16 }}
              onClick={() => window.location.reload()}
            >
              RECARREGAR
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default ErrorBoundary;
