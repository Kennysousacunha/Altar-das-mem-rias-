# 🩸 INFERNO — O Caçador Desce

Jogo de ação top-down em estilo masmorra demoníaca, escrito em React 19 + Canvas 2D + Web Audio API.

> **Sem nome. Sem rosto. Sem emoções.** Uma entidade firmada num pacto antigo que persegue os demônios até o último eco. Belial aguarda, dez andares abaixo.

---

## ✨ Novidades desta atualização

- **10 modelos de masmorra desenhados à mão** — no lugar do cenário anterior (sempre gerado do zero de forma aleatória), agora existem **10 layouts fixos e diferentes** (`game/mapTemplates.js`), cada um com sua própria "personalidade": Cruz Sagrada Profanada, Anel do Fogo, Espinha Dorsal, Câmaras Gêmeas, Labirinto Sinuoso, Diamante Partido, Fornalha Central, Corredores Paralelos, Catedral Profana e Ruínas Fragmentadas. Cada um dos 9 primeiros andares usa um modelo diferente (o 10º andar continua sendo a Arena do Belial, o chefe final); o 10º modelo fica de reserva caso o jogo ganhe mais andares no futuro.
- **Monstros com sprite de verdade** — os 5 tipos de inimigo (Imp, Brute, Shade, Hellhound, Warlock) agora usam as spritesheets de demônio enviadas (`Demon_A` e `Blood Monster_A`), animadas (parado/andando/atacando) e recoloridas por tipo para continuarem visualmente distintas.
- **UI cinza com cor principal** — os painéis, botões e telas que eram quase pretos agora usam uma paleta cinza (`App.css`), mantendo o laranja-fogo (`#ff5028`) só como cor de destaque, deixando o jogo bem mais legível.
- **Tela de título recriada** — logo do INFERNO com leve tremulação, fundo animado (efeito lento de zoom/drift) exibido **só no menu inicial**, e trilha própria para o menu: mantém o clima "dark ambient" do resto do jogo mas com um toque psicodélico (phaser lento no filtro + delay com feedback nos sinos). Botões reorganizados: **INICIAR CAÇADA**, **CONTINUAR** (quando há uma run salva) e **CONFIGURAÇÕES**.
- **Tela de Configurações** (nova) — Áudio (sliders de Música e Efeitos), Vídeo (Tremor da Tela, Partículas, Qualidade Baixo/Médio/Alto — afeta o limite de partículas simultâneas), Controles (Tamanho do Joystick e dos Botões, 60%–150%) e Apagar Progresso (com confirmação). Tudo persistido no `localStorage` (`game/Settings.js`).
- **Revelação da raça + introdução narrativa** — ao confirmar a raça, "Que forma sua alma assumiu?" dá lugar a uma tela de 2s com o nome escolhido e sua frase (ex.: VAMPIRO — "A sede nunca termina."), seguida de uma pequena introdução (~12s, avança sozinha ou com um toque na tela) antes de escurecer e começar o andar 1.
- **Primeiro corredor sem inimigos** — o andar 1 agora começa vazio: o jogador anda um pouco e encontra um NPC (Sobrevivente) que planta a dúvida sobre quem criou o Pesadelo, sem revelar nada ainda. Os demônios daquele andar só aparecem depois que essa conversa termina.
- **Correção da barra do navegador cobrindo o jogo** — trocado `100vh` por `100dvh` (com fallback via `--vh` em JS), que é a abordagem padrão usada hoje para telas que preenchem a tela toda em navegadores mobile.
- **Botão de tela cheia real (⤢, ao lado do botão de mute)** — em navegadores embutidos de apps como Quick Edit ou Code Studio, a barra de navegação do app continua visível mesmo com o `100dvh` (porque ela não é a barra do navegador do sistema, é parte da própria janela do webview). A solução mais usada para isso é a **Fullscreen API**: o jogo agora tenta entrar em tela cheia automaticamente no primeiro toque na tela e também expõe um botão manual (⤢/⤡) no canto superior direito para entrar/sair da tela cheia a qualquer momento. Também foram adicionadas meta tags (`mobile-web-app-capable`, `apple-mobile-web-app-capable`) que fazem o jogo abrir sem nenhuma barra quando adicionado à tela inicial do celular.
- **Remoção de scripts de terceiros que causavam lentidão** — o `public/index.html` original carregava um script de terceiro (toolbar da plataforma onde o app foi montado) e um script de analytics com gravação de sessão, ambos meio pesados no loop de 60fps do jogo. Foram removidos.

---

## 📦 Conteúdo do pacote

```
Inferno/
├── build/         ← Versão pronta para jogar (build estático, sem precisar instalar nada)
│   ├── index.html
│   ├── App.js, App.css, index.js, index.css
│   ├── game/              ← Engine.js, InfernoGame.js, config.js, AudioManager.js, Save.js, Settings.js
│   └── assets/             ← sprites do herói, monstros e texturas
├── source/        ← Código-fonte completo (React + JSX), para quem quiser editar/rebuildar
│   ├── src/
│   ├── public/
│   ├── package.json
│   └── ...configs
└── README.md      ← este arquivo
```

---

## 🎮 Como jogar (rápido)

### Opção A — Abrir o build pronto

Devido à política de segurança dos navegadores, **não é possível** simplesmente dar duplo-clique em `build/index.html` (Chrome bloqueia o carregamento de módulos JS via `file://`). Você precisa servir os arquivos por um servidor local — os scripts `play.sh` (Mac/Linux) e `play.bat` (Windows) na raiz do pacote fazem isso automaticamente.

> ℹ️ O build carrega o React pronto (via CDN) na primeira vez que a página abre, então é necessário estar **conectado à internet** ao abrir o jogo (as fontes também vêm do Google Fonts). Depois de carregado, o jogo em si roda todo localmente — sem chamadas de rede durante a partida.

**Em qualquer sistema** (com Python instalado):
```bash
cd Inferno/build
python3 -m http.server 8080
```
Depois abra: **http://localhost:8080**

**Com Node** (sem instalar nada extra usando npx):
```bash
cd Inferno/build
npx serve .
```

**Windows** (sem terminal): instale [Servez](https://greggman.github.io/servez/), aponte para a pasta `build` e clique em START.

### Opção B — Rodar o código-fonte (modo desenvolvedor)

```bash
cd Inferno/source
yarn install        # (ou npm install)
yarn start
```
Abre em http://localhost:3000

---

## 🎯 Controles

### Desktop (teclado + mouse)
| Tecla | Ação |
|-------|------|
| `W A S D` ou `↑ ← ↓ →` | Movimento (8 direções) |
| `Espaço` / `J` / Clique | Atacar |
| `Q` | Invulnerabilidade (5s, cd 10s) |
| `R` | Campo de Força (3s, cd 10s) |
| `F` | Disparo Arcano radial (cd 10s) |
| `E` | Falar com NPC |
| `M` | Mutar/Desmutar áudio |

### Mobile / Touch
- **Joystick virtual** (canto inferior esquerdo) — movimento
- **Botão grande à direita** — ataque
- **3 botões pequenos** — habilidades
- **Botão azul "FALAR"** — aparece perto do NPC

---

## 🩸 Mecânicas

### Sistema de Classes
Escolhido antes de cada nova descida — cada classe traz passivas únicas:

| Classe | Passivas |
|--------|----------|
| **MORTO-VIVO** | +40% HP máx, +30% defesa, regenera 1.5 HP/s, -8% velocidade |
| **VAMPIRO** | +5% roubo de vida (10% total), +10% dano, -8% HP |
| **FANTASMA** | 25% chance de esquivar, +18% velocidade, +10% velocidade de ataque, -15% HP, -20% defesa |

### Progressão
- **10 andares**, cada um com um **modelo de masmorra fixo e diferente** (veja a lista de mapas abaixo)
- A cada **5 abates** → level-up automático: +5% em todos os atributos
- Ao final de cada andar → escolha 1 dádiva sombria:
  - **Fúria** +15% dano
  - **Frenesi** +20% velocidade de ataque
  - **Vampirismo** +10% roubo de vida
  - **Carne dura** +25% defesa
  - **Vitalidade** +100% HP máximo

### Mapas (um por andar, andares 1–9)
1. Cruz Sagrada Profanada — sala central + 4 braços
2. Anel do Fogo — 8 câmaras em anel ao redor de um vazio central
3. Espinha Dorsal — corrente linear de salas com capelas laterais
4. Câmaras Gêmeas — dois salões grandes ligados por uma ponte
5. Labirinto Sinuoso — 20 salinhas conectadas em corredores sinuosos
6. Diamante Partido — salão em losango com 4 cantos
7. Fornalha Central — hub circular com 6 corredores radiais
8. Corredores Paralelos — grade estilo quartel (4×3 salas)
9. Catedral Profana — nave longa com capelas e câmara traseira
10. *(Reserva — "Ruínas Fragmentadas", não usado nos 10 andares padrão pois o andar 10 é a Arena do Belial)*

### Inimigos
- **Imp** — assédio rápido em melee
- **Brute** — alto HP e dano corpo-a-corpo
- **Shade** — teleporta-se em volta do jogador
- **Hellhound** — cargas em linha reta
- **Warlock** — mantém distância e dispara projéteis

### Boss final (Andar 10) — Belial, o Arquidemônio
5 ataques rotativos: garra pesada, sopro de fogo em cone, orbes radiais, invocação de servos, e onda de choque massiva.

### NPC — Sobrevivente (Andar 1, corredor inicial)
Encontro introdutório, sem inimigos ao redor. Planta a dúvida sobre quem criou o Pesadelo, sem revelar nada — só depois dessa conversa os demônios do andar 1 aparecem.

### NPC — Alma Perdida (Andar 2)
Diálogo + bênção opcional (+3% vampirismo permanente e cura total).

---

## 💾 Save / Continuar

O progresso é salvo automaticamente no **localStorage do navegador** ao final de cada andar.

- **CONTINUAR** aparece no menu se houver uma run em andamento
- **NOVA DESCIDA** sempre começa do zero
- **APAGAR SAVE** limpa todos os dados salvos
- Morrer **apaga o save atual** (mas mantém o registro do melhor andar atingido)

> ⚠️ O save fica vinculado ao navegador/domínio. Trocar de navegador ou limpar dados do site apaga o progresso.

---

## 🎵 Áudio

A trilha sonora e os SFX são **gerados proceduralmente** pela Web Audio API — nenhum arquivo de áudio externo é usado. Isso significa:

- Funciona 100% offline depois de carregado (com exceção da imagem de fundo animada do menu inicial, que é carregada de um link externo — se estiver offline, o menu simplesmente aparece sem o fundo animado, sem afetar o resto do jogo)
- Trilha do **menu** é dark ambient com um toque psicodélico (phaser lento + eco); muda para dungeon ao jogar, e para uma trilha mais tensa quando o boss aparece
- Volumes de música e efeitos ajustáveis em CONFIGURAÇÕES
- Botão de mute (♫/♪) no canto superior direito
- Áudio inicia apenas depois do primeiro clique (política dos navegadores)

---

## 🧱 Stack & arquitetura

- **React 19** (CRA + craco) — wrapper de UI/screens
- **Canvas 2D API** — renderização do jogo
- **Web Audio API** — música procedural + SFX
- **localStorage** — persistência

Estrutura de pastas relevantes:
```
src/
├── App.js, App.css, index.js, index.css
└── game/
    ├── InfernoGame.jsx   — componente React, telas, input, HUD, touch
    ├── Engine.js          — motor: update loop, IA, render, colisão
    ├── config.js          — constantes, classes, inimigos, fases
    ├── mapTemplates.js    — os 10 modelos fixos de masmorra
    ├── AudioManager.js    — música procedural + SFX
    ├── Settings.js        — configurações de áudio/vídeo/controles (localStorage)
    └── Save.js            — sistema de save/load via localStorage
public/
└── assets/
    ├── character.png              — spritesheet 32x32 do Caçador
    ├── demon_idle/walk/attack.png — spritesheet do Demon_A (Brute, Warlock)
    ├── blood_idle/walk/attack.png — spritesheet do Blood Monster_A (Imp, Shade, Hellhound)
    ├── floor_texture.png, lava_texture.png
```

---

## 🛠️ Solução de problemas

**A página não carrega ao dar duplo-clique no index.html**
→ Os navegadores bloqueiam arquivos via `file://`. Use um servidor local (instruções no topo).

**O áudio não toca**
→ Clique em qualquer lugar da página primeiro (política de autoplay). O botão ♫ no canto superior alterna o mudo.

**As fontes ficam estranhas**
→ As fontes vêm do Google Fonts. Sem internet na primeira execução, o navegador cairá para a fonte padrão — o jogo continua funcionando perfeitamente.

**Não consigo passar de uma sala estreita**
→ Ataques (`F`/`R`) atravessam paredes? Não — projéteis colidem com paredes. Procure rotas alternativas no labirinto.

---

## 📜 Lore

> Antes do tempo, quando o véu entre os mundos ainda era pele, um homem — ou o que um dia foi homem — firmou um pacto com algo mais antigo que os deuses.
>
> Cedeu o **nome**, para que nenhum demônio pudesse invocá-lo.
> Cedeu o **rosto**, para que nenhum espelho o reconhecesse.
> Cedeu as **emoções**, para que medo, dor ou piedade nunca atrasassem o golpe.
>
> O que sobrou já não é humano. Já não está vivo. Mas também nunca morreu.
> É apenas uma função. Um recipiente. Ódio infinito destilado num único propósito.
>
> Hoje, o rastro o trouxe ao próprio Inferno.

---

Boa caçada. **Desça.**
